### **&emsp;&emsp;相信有很多朋友尤其是强迫症的朋友都有一个痛点，那就是微信小程序的自定义底部tabbar切换闪烁的问题。**
### **&emsp;&emsp;虽说微信官方开放了自定义tabbar的api，但是还是不能像微信原生的tabbar那样流畅，自定义的在切换页面的时候会有那么一瞬间闪烁，尤其在页面组件多的时候尤为明显。**
### **&emsp;&emsp;我作为一个初学者，尝试了一下使用include加载页面布局，目前效果还不错！**

- ## 效果图(图片有点大)
![Demonstration.gif][1]

- ## **方法**
### **&emsp;&emsp;其实方法很简单，如上图底部tabbar为5个，通常需要创建5个页面，现在的方法是，只创建一个页面作为载体，然后通过include分别按需载入其他几个wxml页面文件，比如点击首页，则include首页的wxml文件，这样做到了切换的效果，又可以避免底部tabbar切换时闪烁的问题了。**

- ## **弊端**
### **&emsp;&emsp;这么做虽说解决了底部tabbar闪烁的问题，但是css的样式只能写在创建的页面载体的wxss文件里或者单独创建一个wxss文件，然后载体页面wxss再import。**

### **&emsp;&emsp;js代码也只能写在载体页面的js文件里或者单独创建js文件再引入，本人菜鸟目前还在摸索阶段，如果大家有更好的解决办法，请留言给我哈！！！**

- ## **鸣谢**
### **&emsp;&emsp;源码界面中使用到了最好看的小程序UI之一的ColorUI，欢迎大家去看看！！！**
### **&emsp;&emsp;github:[https://github.com/weilanwl/ColorUI][3]**
### **&emsp;&emsp;官网:[https://www.color-ui.com][4]**


  [1]: https://blog.tpengyun.com/usr/uploads/2019/03/3224981123.gif
  [2]: https://dev.tencent.com/u/LoveEmpathy/p/custom-tabbar/git
  [3]: https://github.com/weilanwl/ColorUI
  [4]: https://www.color-ui.com