//index.js
//获取应用实例
const app = getApp()

Page({

  data: {
    height: wx.getSystemInfoSync().height,
    menu: {
      id: 0,
      color: 'gray',
      selectColor: 'green',
      tabItem: [{
        class: 'icon-homefill',
        name: '首页',
      }, {
        class: 'icon-similar',
          name: '分类',
      }, {
          class: 'cu-btn icon-add bg-green shadow',
          name: '发布',
          action: 'add-action',
      }, {
          class: 'icon-cart',
          name: '购物车',
      }, {
          class: 'icon-my',
          name: '我的',
      }]
    },
  },

  onLoad: function () {

  },

  selectTab: function (e) {
    var id = e.currentTarget.dataset.id
    var menu = 'menu.id'
    this.setData({
      [menu]:id
    })
    console.log('id:'+id)
  }
})
