const app = getApp(), allData = app.globalData, api = require('../../utils/api.js'),
  utils = require('../../utils/util.js'), UI = require('../../utils/Interface.js')
var isChoice, name, phoneNum;
/**
 * 计算顶部实际占界面的高度
 */
function setTopHeight(that) {
  var query = wx.createSelectorQuery()//单位px；
  query.select('#top').boundingClientRect(function (rect) {
    that.setData({ TopHeight: rect.height })
  }).exec();
}
Page({

  data: { },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    isChoice = false
    setTopHeight(this)
    app.setTitleWidth(this)
  },

  onShow: function (res) {
    var t = this
    t.setData({
      iconUrl: allData.iconUrl,
      userName: allData.name,
      phoneNum: allData.phoneNum
    })
  },

  /**
   * 选择图片
   */
  choice_img() {
    var t = this
    wx.chooseImage({
      count: 1,
      success: function (res) {
        isChoice = true
        t.setData({
          iconUrl: res.tempFilePaths[0]
        })
      }
    })
  },

  /**
   * input的value改变
   * @param {*} e 
   */
  changeInput(e) {
    var key = e.target.dataset.name, value = e.detail.value
    switch (key) {
      case 'name':
        name = value
        break;
      case 'phone':
        phoneNum = value
        break;
    }
  },

  /**
   * 更新头像
   */
  updataUserInfo() {
    var t = this
    UI.showLoading('提交中...')
    //如果头像没有被更改，则不执行上传返回，否则先上传头像后再执行更新资料方法
    !isChoice ? t.updateData() : utils.UpLoadFile('upload', function (res) {
      res.status == 0 ?
        t.updateData(res.data.fileUrl) :
        UI.showToast('上传头像失败，请稍候重试！')
    }, t.data.iconUrl)
  },

  /**
   * 更新资料
   */
  updateData(e) {
    utils.PUT('userInfo', {
      "Portrait": isChoice ? e : allData.iconUrl,
      "UserName": name ? name : allData.name,
      "Telephone": phoneNum ? phoneNum : allData.phoneNum
    }, (res) => {
        const data = res.data
        console.log(data)
      res.status == 0 ?
        (allData.iconUrl = data.portrait, allData.name = data.name, allData.phoneNum = data.phoneNum) & allData.that.onLoad() & UI.showToast('保存成功')
        : UI.showToast('保存失败')
      },1)
  }
})