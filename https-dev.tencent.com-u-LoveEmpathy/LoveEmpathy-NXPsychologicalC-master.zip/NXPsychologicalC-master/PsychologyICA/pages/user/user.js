const app = getApp(),
  allData = app.globalData,
  utils = require('../../utils/util.js'),
  UI = require('../../utils/Interface.js')

Page({
  /**
   * 页面的初始数据
   */
  data: {
    user_info: wx.getStorageSync("userInfo"),
  },
  onLoad: function(options) {
    app.setTitleWidth(this);
    !wx.getStorageSync('wave') ? UI.showLoading('加载中') &
      UI.seveImage(this, 'wave.gif', 'wave') :
      this.setData({
        userName: allData.name,
        iconUrl: allData.iconUrl,
        wave: wx.getStorageSync('wave')
      }) & wx.hideLoading()
  },
  /**
   * 跳转页面
   * @param {*} e 
   */
  toPage(e) {
    const page = UI.page[[e.currentTarget.dataset.page]]
    allData.that = this
    wx.navigateTo({
      url: page
    })
  }

})