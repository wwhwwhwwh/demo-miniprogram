const app = getApp(),
  allData = app.globalData,
  api = require('../../utils/api.js'),
  utils = require('../../utils/util.js'),
  ui = require('../../utils/Interface.js')

var community, expert, users, banner, infoClass, nav
/**
* 计算scroll-view实际占界面的高度
*/
function setHeight(that) {
  const query = wx.createSelectorQuery();// 单位px；
  query.select('#nav').boundingClientRect(function (rect) {
    that.setData({
      contenHeight: rect.height,
      swiperHeight: allData.windowHeight
    })
  }).exec();
}
Component({
  data: {
    nav: ['社区管理', '专家管理', '用户管理', 'Banner管理', '资讯分类', '导航管理'],
    TabCur: 0
  },
  pageLifetimes: {
    show() {
      if (typeof this.getTabBar === 'function' &&
        this.getTabBar()) {
        this.getTabBar().setData({
          selected: 1
        })
      }
    }
  },
  methods: {
    onLoad: function () {
      app.setTitleWidth(this, '管理'), setHeight(this), Init(this)
    },
    /**
     * 顶部分类Tab被单击事件
     * @param {*} e 
     */
    tabSelect(e) {
      var index = e.currentTarget.dataset.id
      this.setData({ TabCur: index, scrollLeft: (index - 1) * 60 })
    },
    /**
     * 
     * @param {*} e 
     */
    swiperChange(e) {
      var index = e.detail.current
      this.setData({ TabCur: index, scrollLeft: (index - 1) * 60 })
    }
  }
})
function Init(that) {
  //初始化
  community = that.selectComponent("#community")
  expert = that.selectComponent("#expert")
  users = that.selectComponent("#users")
  banner = that.selectComponent("#banner")
  infoClass = that.selectComponent("#infoClass")
  nav = that.selectComponent("#nav")

  //页面执行初始化
  community.Initialization()
}