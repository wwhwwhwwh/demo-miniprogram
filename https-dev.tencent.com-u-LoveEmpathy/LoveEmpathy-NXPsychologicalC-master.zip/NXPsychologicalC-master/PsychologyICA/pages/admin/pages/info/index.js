const app = getApp(),

  utils = require('../../../../utils/util.js'),
  allData = getApp().globalData,
  api = require('../../../../utils/api.js'),
  ui = require('../../../../utils/Interface.js')
var doubleClick = 0
Page({
  data: {
    loadingImg: api.loadingImgUrl + 'loading-1.gif',
    ViewHeight: wx.getSystemInfoSync().screenHeight,
    user_id: wx.getStorageSync('user_id')
  },
  onLoad: function (options) {
    app.setTitle1Width(this, '详情')
    allData.CommunityInfo = options.id
    this.getCommunityInfo()
  },
  getCommunityInfo() {
    var t = this, CommunityInfo
    utils.GET('CommunityInfo', function (res) {
      CommunityInfo = res.data
      res.status == 0 ? t.setData({ CommunityInfo })
        : t.setData({
          CommunityInfo: 'ErrorNetwork',
          indexTitle: '请求错误'
        }) & UI.showToast('错误:' + res.msg, 1)
    }, { offset: 0 })
  },
  //顶部标题被双击返回顶部
  doubleClick(e) {
    doubleClick++
    if (doubleClick == 2) {
      doubleClick = 0
      this.setData({ scrollTop: 0 })
    } else {
      setTimeout(() => {
        doubleClick = 0
      }, 450);
    }
  },
  /**
   * 菜单操作
   * @param {*} e 
   */
  menu(e) {
    const index = e.currentTarget.dataset.index, type = e.currentTarget.dataset.type, message_list = this.data.CommunityInfo.message_list[index]
    allData.CommunityReple = message_list.id //将要被操作的回复id存起来
    switch (type) {
      case 'delete':
        Delete(this)
        break;
    }
  },
})

/**
 * 删除回复内容
 * @param {*} that 
 */
function Delete(that) {
  utils.DELETE('CommunityUpdataDelete', {}, (res) => {
    res.status == 0 ? ui.showToast('删除成功')
      & that.getCommunityInfo()//重新获取帖子详情，刷新数据
      : ui.showToast('错误:' + res.msg, 1)
  })
}