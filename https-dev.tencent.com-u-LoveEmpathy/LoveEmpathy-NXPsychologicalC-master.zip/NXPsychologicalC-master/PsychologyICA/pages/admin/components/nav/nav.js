Component({
  options: {
    addGlobalClass: true,
  },
  /**
   * 组件的属性列表
   */
  properties: {
    hidden: Boolean
  },

  observers: {
  },
  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    /**
    * 下拉开始的回调函数
    */
    onPulling() { },
    /**
     * 正在刷新:下拉完成的回调函数
     */
    onRefresh() {
      console.log("123132")
    },
  }
})
