const app = getApp(),
  allData = app.globalData,
  path = '../../../../',
  utils = require(path + 'utils/util.js'),
  ui = require(path + 'utils/Interface.js')
import { $stopWuxRefresher } from '../../../../dist/index'
var item,ClassName,ClassId
Component({
  options: {
    addGlobalClass: true,
  },
  /**
   * 组件的属性列表
   */
  properties: {
    hidden: Boolean
  },

  observers: {
  },
  /**
   * 组件的初始数据
   */
  data: {
    TabCur: 0,
    color_index: 0,
    color: [
      {
        name: 'red',
        title: '嫣红'
      },
      {
        name: 'orange',
        title: '桔橙'
      },
      {
        name: 'yellow',
        title: '明黄'
      },
      {
        name: 'olive',
        title: '橄榄'
      },
      {
        name: 'green',
        title: '森绿'
      },
      {
        name: 'cyan',
        title: '天青'
      },
      {
        name: 'blue',
        title: '海蓝'
      },
      {
        name: 'purple',
        title: '姹紫'
      },
      {
        name: 'mauve',
        title: '木槿'
      },
      {
        name: 'pink',
        title: '桃粉'
      },
      {
        name: 'brown',
        title: '棕褐'
      },
      {
        name: 'grey',
        title: '玄灰'
      },
      {
        name: 'black',
        title: '墨黑'
      }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /**
    * 下拉开始的回调函数
    */
    onPulling() { },
    /**
     * 正在刷新:下拉完成的回调函数
     */
    onRefresh() {
      var t = this
      /**
       * 下拉刷新时触发初始化获取资讯
       * tip:采用延时操作纯属为了UI好看
       */
      setTimeout(() => {
        t.Initialization(true)
      }, 1000)
    },
    /**
     * 初始化 
     */
    Initialization(isStopRefresher) {
      const that = this
      //判断是否是下拉刷新触发的，如果是则关闭刷新动画
      if (!isStopRefresher) ui.showLoading('加载中')
      utils.GET('getCommunity_class', (res) => {
        res.status == 0 ? that.setData({
          sp_list: res.data
        }) : that.setData({
          sp_list: 'ErrorNetwork'
        }) &
          ui.showToast('错误:' + res.msg)
        that.getCommunity(isStopRefresher)
      })
    },
    /**
    * 获取帖子列表
    */
    getCommunity(isStopRefresher) {
      const that = this
      if (isStopRefresher) $stopWuxRefresher('refresher', this)
      else ui.showLoading('加载中')
      utils.GET('Community', (e) => {
        e.status == 0 ? that.setData({
          new_list: e.data
        }) : that.setData({
          new_list: 'ErrorNetwork'
        }) &
          UI.showToast('错误:' + e.msg)
      }, {
          sortby: 'time',
          order: 'desc'
        })
    },
    //导航栏被点击
    tabSelect(e) {
      this.setData({
        TabCur: e.currentTarget.dataset.id,
      })
    },
    /**
     * 菜单显示/隐藏
     */
    Menu(e) {
      if (!this.data.ModalShow) {
        item = e.currentTarget.dataset.item
        allData.CommunityInfo = item.id
      }
      ModalShow(this, 0)
    },

    delete() {
      const that = this
      utils.DELETE('CommunityInfo', null, (res) => {
        ModalShow(that, 0)
        res.status == 0 ? ui.showToast('删除成功')
          & that.getCommunity()//重新获取帖子列表，刷新数据
          : ui.showToast('错误:' + res.msg, 1)
      })
    },
    ClassMenu(e) {
      if (!this.data.ClassModalShow) {
        item = e.currentTarget.dataset.item
        allData.Class = item.id
        console.log(item)
      }
      ModalShow(this, 2)
    },
    ClassMenuShow(e) {
      if (!this.data.ClassMenuShow) {
        item = e.currentTarget.dataset.item
        allData.CommunityInfo = item.id
      }
      ModalShow(this, 1)
    },

    ClassModify() {
      const that = this
      ModalShow(that, 1)
    },

    PickerChange(e) {
      this.setData({ color_index: e.detail.value })
    }

  }
})

function ModalShow(that, type) {
  switch (type) {
    case 0:
      that.setData({ ModalShow: !that.data.ModalShow })
      break;
    case 1:
      that.setData({ ClassMenuShow: !that.data.ClassMenuShow })
      break;
    case 2:
      that.setData({ ClassModalShow: !that.data.ClassModalShow })
      break
    default:
      break;
  }

}
