Component({
  options: {
    addGlobalClass: true,
    multipleSlots: true // 在组件定义时的选项中启用多slot支
  },
  /**
   * 组件的属性列表
   */
  properties: {
    hidden: Boolean
  },

  /**
   * 组件的初始数据
   */
  data: {

  },
  pageLifetimes: {
    
  },
  /**
   * 组件的方法列表
   */
  methods: {
    onShow(){
      console.log(123)
    },
    onload(){
      console.log(456)
    }
  }
})
