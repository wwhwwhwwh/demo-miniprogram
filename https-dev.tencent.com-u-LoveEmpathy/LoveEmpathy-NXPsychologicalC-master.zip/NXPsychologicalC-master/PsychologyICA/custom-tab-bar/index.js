const app = getApp(),IMG_SRC = '/images/tabBar/'
Component({
  options: {
    addGlobalClass: true,
  },
  data: {
    selected: 0,
    color: "#47505b",
    selectedColor: "#0081ff",
    backgroundColor: "#FFF",
    borderStyle: "white",
    list: [{
        iconPath: IMG_SRC+"zixun.png",
        selectedIconPath: IMG_SRC+"zixun_i.png",
        pagePath: "/pages/index/index",
        text: "资讯"
      },
      {
        iconPath: IMG_SRC+"wenda.png",
        selectedIconPath: IMG_SRC+"wenda_i.png",
        pagePath: "/pages/admin/admin",
        text: "管理"
      },
      {
        iconPath: IMG_SRC +"apply.png",
        selectedIconPath: IMG_SRC +"apply_i.png",
        pagePath: "/pages/apply/index",
        text: "审核"
      }
    ],
  },
  methods: {
    switchTab(e) {
      const data = e.currentTarget.dataset
      const url = data.path
      wx.switchTab({
        url
      })
      this.setData({
        selected: data.index,
      })
    },
    _animation(e) {
      var anmiaton = e.currentTarget.dataset.class;
      var that = this;
      that.setData({
        animation: anmiaton
      })
      setTimeout(function() {
        that.setData({
          animation: ''
        })
      }, 1000)
    },
  }
})