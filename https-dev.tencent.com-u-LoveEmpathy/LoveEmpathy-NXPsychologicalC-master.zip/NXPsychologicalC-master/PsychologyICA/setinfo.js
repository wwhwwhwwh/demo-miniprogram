const RootUrl = 'https://nxxlzx.tpengyun.com/',
      MiniProgramAppid = 'wx737c3211676c7ff5'//跳转小程序appid

module.exports = { RootUrl, MiniProgramAppid }