var id = 微擎应用唯一id
module.exports = {
    name: "",
    uniacid: id,
    acid: id,
    multiid: "0",
    version: "5.9.1",
  	siteroot: "https://catering.tpengyun.com/app/index.php",
    design_method: "3"
};