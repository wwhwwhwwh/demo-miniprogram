Page({
    data: {},
    onLoad: function(n) {
        app.getUrl(this), app.getSystem(this);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});