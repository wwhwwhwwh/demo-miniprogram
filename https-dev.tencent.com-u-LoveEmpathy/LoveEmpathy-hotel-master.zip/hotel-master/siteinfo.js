module.exports = {
    name: "",
    uniacid: "uniacid",
    acid: "acid",
    multiid: "0",
    version: "8.3.3",
    siteroot: "https://hotel.tpengyun.com/app/index.php",
    design_method: "3"
};