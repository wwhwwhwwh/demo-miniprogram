module.exports = {
  name: "志汇同城",
  uniacid: "585",
  acid: "585",
  multiid: "0",
  version: "1.0",
  siteroot: "https://tpengyun.com/app/index.php",
  design_method: "3"
};