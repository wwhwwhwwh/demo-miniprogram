exports.app_key = "914e2186012c189a3675704f65e8a989", exports.is_sendEvent = !0, 
exports.is_Location = !0, exports.is_getUserinfo = !0, exports.filterFunc = [], 
exports.pageHomeBack = "/pages/index/index";