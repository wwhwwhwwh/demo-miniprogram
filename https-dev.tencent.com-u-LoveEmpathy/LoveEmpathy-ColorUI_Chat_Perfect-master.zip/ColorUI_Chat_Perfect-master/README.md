## 直接上效果图
![uet38-anjuk.gif][1]

## BUG：顶部会在唤醒软键盘的时候被顶出视图
  [1]: https://blog.tpengyun.com/usr/uploads/2019/04/276304139.gif