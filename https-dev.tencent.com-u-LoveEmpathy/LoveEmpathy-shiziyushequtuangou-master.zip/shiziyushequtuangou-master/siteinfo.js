module.exports = {
    name: "淘宝独爱我设计",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "6.7.0",
    siteroot: "https://你的域名/app/index.php",
    design_method: "3"
};