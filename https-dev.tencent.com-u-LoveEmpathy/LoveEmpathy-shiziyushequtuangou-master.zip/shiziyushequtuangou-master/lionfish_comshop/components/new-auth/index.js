var util = require("../../utils/util.js"), location = require("../../utils/Location.js"), app = getApp();

Component({
    properties: {
        needAuth: {
            type: Boolean,
            value: !1
        },
        needPosition: {
            type: Boolean,
            value: !0
        },
        navBackUrl: {
            type: String,
            value: "",
            observer: function(t) {
                t && (app.globalData.navBackUrl = t);
            }
        }
    },
    data: {
        btnLoading: !1,
        canIUse: wx.canIUse("button.open-type.getUserInfo")
    },
    methods: {
        close: function() {
            this.triggerEvent("cancel");
        },
        bindGetUserInfo: function(t) {
            var e = this;
            if (!this.data.btnLoading) {
                var n = t.detail;
                this.setData({
                    btnLoading: !0
                }), "getUserInfo:ok" === n.errMsg ? util.login_prosime(e.data.needPosition).then(function() {
                    console.log("授权成功"), e.setData({
                        btnLoading: !1
                    }), wx.showToast({
                        title: "登录成功",
                        icon: "success",
                        duration: 2e3
                    }), e.triggerEvent("authSuccess"), app.globalData.changedCommunity = !0, e.data.needPosition && location.getGps();
                }).catch(function() {
                    this.triggerEvent("cancel"), console.log("授权失败");
                }) : (wx.showToast({
                    title: "授权失败，为了完整体验，获取更多优惠活动，需要您的授权。",
                    icon: "none"
                }), this.triggerEvent("cancel"), this.setData({
                    btnLoading: !1
                }));
            }
        }
    }
});