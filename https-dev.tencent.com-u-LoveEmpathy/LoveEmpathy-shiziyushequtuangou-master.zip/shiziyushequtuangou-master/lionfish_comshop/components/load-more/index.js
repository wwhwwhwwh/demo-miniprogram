Component({
    properties: {
        loading: {
            type: Boolean,
            value: !0
        },
        tip: {
            type: String,
            value: ""
        }
    }
});