Component({
    options: {
        multipleSlots: !0
    },
    externalClasses: [ "i-class", "i-card-header", "i-card-body", "i-card-footer" ]
});