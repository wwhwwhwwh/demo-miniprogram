Component({
    properties: {
        comment: {
            type: String
        }
    }
});