var app = getApp();

Component({
    properties: {},
    data: {
        disabled: !1,
        list: []
    },
    attached: function() {
        this.getData();
    },
    methods: {
        getData: function() {
            var t = wx.getStorageSync("token"), e = this, a = wx.getStorageSync("community");
            app.util.request({
                url: "entry/wxapp/index",
                data: {
                    controller: "index.load_gps_goodslist",
                    token: t,
                    pageNum: 1,
                    is_random: 1,
                    head_id: a.communityId
                },
                dataType: "json",
                success: function(t) {
                    if (0 == t.data.code) {
                        var a = e.data.list.concat(t.data.list);
                        e.setData({
                            list: a
                        });
                    } else e.setData({
                        noMore: !0
                    });
                }
            });
        },
        openSku: function(t) {
            var a = t.currentTarget.dataset.idx;
            this.setData({
                disabled: !1
            });
            var e = this.data.list[a];
            this.triggerEvent("openSku", {
                actId: e.actId,
                skuList: e.skuList,
                promotionDTO: e.promotionDTO || "",
                allData: {
                    spuName: e.spuName,
                    skuImage: e.skuImage,
                    actPrice: e.actPrice,
                    canBuyNum: e.spuCanBuyNum,
                    stock: e.spuCanBuyNum,
                    marketPrice: e.marketPrice
                }
            });
        }
    }
});