var _extends = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var i = arguments[a];
        for (var e in i) Object.prototype.hasOwnProperty.call(i, e) && (t[e] = i[e]);
    }
    return t;
}, app = getApp(), util = require("../../utils/util.js"), WxParse = require("../../wxParse/wxParse.js");

Page({
    data: {
        status: 0,
        type: 1,
        items: [ {
            name: "1",
            value: "余额",
            show: !0,
            checked: !1
        }, {
            name: "2",
            value: "微信零钱",
            show: !0,
            checked: !1
        }, {
            name: "3",
            value: "支付宝",
            show: !0,
            checked: !1
        }, {
            name: "4",
            value: "银行卡",
            show: !0,
            checked: !1
        } ],
        info: [],
        tixian_money: "",
        final_money: 0
    },
    onLoad: function(t) {
        util.check_login() ? this.getData() : this.setData({
            needAuth: !0
        });
    },
    canTixian: !0,
    authSuccess: function() {
        var t = this;
        this.setData({
            needAuth: !1
        }, function() {
            t.getData();
        });
    },
    getData: function() {
        wx.showLoading();
        var t = wx.getStorageSync("token"), s = this;
        app.util.request({
            url: "entry/wxapp/user",
            data: {
                controller: "distribution.get_commission_info",
                token: t
            },
            dataType: "json",
            success: function(t) {
                if (wx.hideLoading(), 0 == t.data.code) {
                    var a = t.data.data.commiss_tixian_publish;
                    WxParse.wxParse("article", "html", a, s, 15, app.globalData.systemInfo);
                    var i = s.data.items, e = t.data.data;
                    0 == e.commiss_tixianway_yuer && (i[0].show = !1), 0 == e.commiss_tixianway_weixin && (i[1].show = !1), 
                    0 == e.commiss_tixianway_alipay && (i[2].show = !1), 0 == e.commiss_tixianway_bank && (i[3].show = !1);
                    for (var n = s.data.type, o = 0; o < i.length; o++) if (i[o].show) {
                        i[o].checked = !0, n = i[o].name;
                        break;
                    }
                    s.setData({
                        info: t.data.data,
                        items: i,
                        type: n
                    });
                } else wx.showModal({
                    title: "提示",
                    content: t.data.msg,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && (console.log("用户点击确定"), wx.reLaunch({
                            url: "/lionfish_comshop/pages/user/me"
                        }));
                    }
                });
            }
        });
    },
    formSubmit: function(t) {
        var a = t.detail.value, i = 0;
        for (var e in a) {
            if (a[e] = a[e].replace(/(^\s*)|(\s*$)/g, ""), !a[e]) {
                wx.showToast({
                    title: "请输入正确的表单内容",
                    icon: "none"
                }), i = 1;
                break;
            }
            if ("money" == e && 1 * a[e] <= 0) return void wx.showToast({
                title: "请输入正确的金额",
                icon: "none"
            });
        }
        if (1 != i) {
            a.type = this.data.type, console.log(a);
            var n = this.data, o = parseFloat(n.tixian_money), s = n.info.total_money, c = parseFloat(n.info.commiss_min_tixian_money);
            if ("" == o || o < c) return wx.showToast({
                title: "最小提现" + c + "元",
                icon: "none"
            }), !1;
            if (s < o) {
                wx.showToast({
                    title: "本次最大可提现" + s + "元",
                    icon: "none"
                });
                var r = (s * (100 - n.info.commiss_tixian_bili) / 100).toFixed(2);
                return this.setData({
                    tixian_money: s,
                    final_money: r
                }), !1;
            }
            if (this.canTixian) {
                this.canTixian = !1, wx.showLoading();
                var l = wx.getStorageSync("token"), u = this;
                app.util.request({
                    url: "entry/wxapp/user",
                    data: _extends({
                        controller: "distribution.tixian_sub",
                        token: l
                    }, a),
                    dataType: "json",
                    success: function(t) {
                        wx.hideLoading(), 0 == t.data.code ? u.setData({
                            status: 1
                        }) : (console.log(t), wx.showToast({
                            title: t.data.msg ? t.data.msg : "提交失败，请重试",
                            icon: "none"
                        }));
                    }
                });
            }
        }
    },
    bindIptFocus: function() {
        this.setData({
            onFocus: !0
        });
    },
    bindIptBlur: function() {
        this.setData({
            onFocus: !1
        });
    },
    radioChange: function(t) {
        this.setData({
            type: t.detail.value
        });
    },
    bindTixianMoneyInput: function(t) {
        var a = this.data.info.total_money, i = t.detail.value;
        a < i && wx.showToast({
            title: "本次最大可提现" + a + "元",
            icon: "none"
        });
        var e = (i * (100 - this.data.info.commiss_tixian_bili) / 100).toFixed(2), n = !1;
        return n = !!i, this.setData({
            tixian_money: 1 * i,
            final_money: e,
            canPay: n
        }), i;
    },
    getAll: function() {
        var t = this.data, a = 1 * t.info.total_money, i = (a * (100 - t.info.commiss_tixian_bili) / 100).toFixed(2), e = !1;
        e = !!a, this.setData({
            tixian_money: a,
            final_money: i,
            canPay: e
        });
    }
});