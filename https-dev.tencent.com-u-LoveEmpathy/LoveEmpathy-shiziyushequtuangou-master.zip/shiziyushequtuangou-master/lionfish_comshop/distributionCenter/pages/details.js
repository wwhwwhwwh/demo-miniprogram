Page({
    data: {
        list: [ {}, {} ],
        isHideLoadMore: !0,
        tip: "正在加载"
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});