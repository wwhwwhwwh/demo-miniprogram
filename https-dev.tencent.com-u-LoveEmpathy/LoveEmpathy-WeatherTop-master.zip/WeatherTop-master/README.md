- ## **微信小程序纯css下雨下雪效果**
### **&emsp;&emsp;闲来无事，弄了个微信小程序的下雨和下雪的动画，是我从网上扒下来的html代码，做了精简和简单的修改，纯css的哦！**
### **&emsp;&emsp;关于天气部分的，是使用百度的api，有需要的请自行申请ak，自己写了一点的，其他的以后再说吧！**
### **&emsp;&emsp;雨滴和雪花是重新做的图片，想自己做的很简单，在网上找找PS的笔刷，然后就可以了，恩~~~~~就这样吧**

- ## 效果图(23MB！！！！)
![Demonstration.gif][1]

- ## **源码**
#### **&emsp;&emsp;代码和用到的素材一起打包了，也包含了我花了几十大洋在某宝上买的字体，切勿商用，仅供学习参考！**
### **&emsp;&emsp;腾讯代码托管：[https://dev.tencent.com/u/LoveEmpathy/p/WeatherTop/git][2]**

  [1]: https://blog.tpengyun.com/usr/uploads/2019/03/15991885.gif
  [2]: https://dev.tencent.com/u/LoveEmpathy/p/WeatherTop/git