package controllers

import (
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"mime/multipart"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/httplib"
	"github.com/astaxie/beego/utils"
	jwt "github.com/dgrijalva/jwt-go"
)

// BaseController API基类
type BaseController struct {
	beego.Controller
}

// ReturnMsg 格式化接口返回信息
func (c *BaseController) ReturnMsg(status int, data interface{}, msg string) {
	if msg == "" {
		msg = "success"
	}

	c.Data["json"] = map[string]interface{}{"status": status, "data": data, "msg": msg}
	c.ServeJSON()
	c.StopRun()
}

// CreateToken 创建令牌
func (c *BaseController) CreateToken(userID int64) string {
	type UserInfo map[string]interface{}

	t := time.Now()
	key := beego.AppConfig.String("tokenkey")
	userInfo := make(UserInfo)

	userInfo["exp"] = strconv.FormatInt(t.UTC().UnixNano(), 10)
	userInfo["iat"] = "0"
	userInfo["aud"] = strconv.FormatInt(userID, 10)

	token := jwt.New(jwt.SigningMethodHS256)
	claims := make(jwt.MapClaims)

	for index, val := range userInfo {
		claims[index] = val
	}
	token.Claims = claims
	tokenString, _ := token.SignedString([]byte(key))
	return tokenString
}

// ParseToken 检查令牌并返回用户的ID
func (c *BaseController) ParseToken(tokenString string) string {
	// 开发时指定的超级token
	if tokenString == "hehe" {
		return "82"
	}

	if tokenString == "" {
		c.ReturnMsg(-1, nil, "access_token为空！")
	}

	t := time.Now()
	key := beego.AppConfig.String("tokenkey")
	// 设置token生存时间为3天，单位为纳秒
	var expTime int64 = 259200000000000
	var userID int64 = -1

	token, _ := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(key), nil
	})
	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		oldT, _ := strconv.ParseInt(claims["exp"].(string), 10, 64)
		userID, _ = strconv.ParseInt(claims["aud"].(string), 10, 64)
		ct := t.UTC().UnixNano()
		diff := ct - oldT
		if diff > expTime {
			// token已过期
			beego.Error("token已过期，当前系统时间:" + strconv.FormatInt(ct, 10) + ",token的过期时间：" + strconv.FormatInt(oldT, 10) + ",时间差：" + strconv.FormatInt(diff, 10) + ",token生存时间：" + strconv.FormatInt(expTime, 10))
			c.ReturnMsg(-1, nil, "token已过期")
		}
	} else {
		// token非法
		beego.Error("token非法，接口返回错误")
		c.ReturnMsg(-1, nil, "token非法")
	}
	// token正常
	return strconv.FormatInt(userID, 10)
}

// SendMailAuth 发送邮件验证码
func (c *BaseController) SendMailAuth(email string, activCode string) error {
	// 邮件发送
	htmlText := fmt.Sprintf(`<html><head></head><body><div>你的激活码为： %s</div></body></html>`, activCode)
	temail := utils.NewEMail(beego.AppConfig.String("mailconfig"))
	temail.To = []string{email}                      // 指定收件人邮箱地址
	temail.From = beego.AppConfig.String("sendname") // 指定发件人的邮箱地址
	temail.Subject = "cosplay作品分享平台"                 // 指定邮件的标题
	temail.HTML = htmlText                           // 指定邮件正文

	err := temail.Send()
	if err != nil {
		return errors.New("邮件发送失败：" + err.Error())
	}
	return nil
}

// CreateRandStr 生成随机字符串
// 参数 len：随机字符串的长度
// 参数 level：0、生成纯数字随机字符串，1、生成纯字母随机字符串
func (c *BaseController) CreateRandStr(strLen int, level int) (randStr string) {
	switch level {
	case 0:
		randStr = strconv.FormatInt(int64(rand.New(rand.NewSource(time.Now().UnixNano())).Int31n(int32(c.Pow(10, strLen)))), 10)
	case 1:
		str := "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
		bytes := []byte(str)
		result := []byte{}
		r := rand.New(rand.NewSource(time.Now().UnixNano()))
		for i := 0; i < strLen; i++ {
			result = append(result, bytes[r.Intn(len(bytes))])
		}
		randStr = string(result)
	default:
		return ""
	}
	return randStr
}

// Pow 求x的n次幂
func (c *BaseController) Pow(x int, n int) int {
	ret := 1
	for n != 0 {
		if n%2 != 0 {
			ret = ret * x
		}
		n /= 2
		x = x * x
	}
	return ret
}

// GetNowTime 获取当前的北京时间，格式：2019-02-07 23:39:10
func (c *BaseController) GetNowTime() time.Time {
	// +28800是因为默认获取到的是UTC时间，需要+8个小时来土法转北京时间
	return time.Unix(time.Now().Unix()+28800, 0)
}

// GetWXopenid 获取微信小程序用户的openid及session
func (c *BaseController) GetWXopenid(userCode string) (openid string, session string, err error) {
	wxAPIURL := fmt.Sprintf("https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code",
		beego.AppConfig.String("appid"),
		beego.AppConfig.String("appsecret"),
		userCode,
	)
	req := httplib.Get(wxAPIURL)
	str, err := req.Bytes()
	if err != nil {
		return "", "", err
	}

	// 微信返回的数据是json格式的，需要从里面提取有用数据
	wxReq := make(map[string]interface{})
	json.Unmarshal(str, &wxReq)
	fmt.Println(userCode + "3")
	fmt.Println(wxReq)

	for k, v := range wxReq {
		if k == "openid" {
			openid, _ = v.(string)
		} else if k == "session_key" {
			session, _ = v.(string)
		} else if k == "errcode" {
			err, _ := v.(string)
			return "", "", errors.New(err)
		}
	}

	return openid, session, nil
}

// UploadFile 上传文件，注：仅mp4格式的视频
func (c *BaseController) UploadFile(fileInfo *multipart.FileHeader, fileStream string) (filePath string, fileType string, err error) {
	fmt.Println(fileInfo.Filename)
	fileExtenTmp := strings.Split(fileInfo.Filename, ".")
	fileExten := fileExtenTmp[len(fileExtenTmp)-1]
	if fileExten == "jpg" || fileExten == "png" || fileExten == "jpeg" || fileExten == "JPEG" || fileExten == "PNG" || fileExten == "JPG" {
		fileType = "image"
	} else if fileExten == "mp4" || fileExten == "MP4" {
		fileType = "video"
	} else {
		beego.Error("文件格式不受支持，格式为：" + fileExten)
		return "", "", errors.New("文件格式不受支持")
	}
	filePathHead := fmt.Sprintf("static/upload/%s/%d/%d/%d/",
		fileType,
		time.Now().Year(),
		time.Now().Month(),
		time.Now().Day(),
	)
	fileName := fmt.Sprintf("%s.%s",
		c.CreateRandStr(10, 1),
		fileExten,
	)

	if _, err := os.Stat(filePathHead); err != nil {
		if err = os.MkdirAll(filePathHead, 0755); err != nil {
			beego.Error("文件上传失败：" + err.Error())
			return "", "", errors.New("文件上传失败：" + err.Error())
		}
	}
	filePath = filePathHead + fileName
	beego.Debug("保存的文件名：\n" + filePath)
	if err = c.SaveToFile(fileStream, filePath); err != nil {
		beego.Error("文件上传失败：" + err.Error())
		return "", "", errors.New("文件上传失败：" + err.Error())
	}
	return filePath, fileType, nil
}
