var app = getApp();

Page({
    data: {
        imgs1: [],
        title: "",
        imagelist: [],
        uploadimagelist: [ "", "", "", "", "", "" ],
        true1: !0,
        true2: !0,
        true3: !0,
        true4: !0,
        true5: !0,
        true6: !0,
        isuser: !0,
        isagree: 0,
        videourl: "",
        notevideo: []
    },
    onLoad: function(e) {
        var a = this;
        a.setData({
            housetype: a.data.housetype,
            show: "none",
            isvideo: "none"
        }), wx.setNavigationBarTitle({
            title: "颜值简历-" + wx.getStorageSync("companyinfo").name
        });
        var t = wx.getStorageSync("userInfo");
        console.log(t), t ? (a.data.isuser = !0, a.oldhouseinit(), a.setData({
            userinfo: t
        })) : a.data.isuser = !1, a.setData({
            isuser: a.data.isuser
        }), a.setData({
            isuser: a.data.isuser,
            companyinfo: wx.getStorageSync("companyinfo")
        });
    },
    oldhouseinit: function(e) {
        var a = this, t = wx.getStorageSync("userInfo");
        app.util.request({
            url: "entry/wxapp/Myvideonote",
            data: {
                sessionid: t.sessionid,
                uid: t.memberInfo.uid
            },
            success: function(e) {
                e.data.message.errno || (e.data.data.intro.maincolor || (e.data.data.intro.maincolor = "#3274e5"), 
                wx.setNavigationBarColor({
                    frontColor: wx.getStorageSync('textcolor'),
                    backgroundColor: e.data.data.intro.maincolor,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                }), e.data.data.notevideo && (a.data.notevideo = e.data.data.notevideo, a.setData({
                    notevideo: a.data.notevideo,
                    isvideo: "block",
                    src: a.data.notevideo.videourl,
                    imgs1: e.data.data.imagelist,
                    show: "block"
                }), a.data.videourl = a.data.notevideo.videourl, a.data.imagelist = e.data.data.imagelist));
            }
        });
    },
    chooseImg: function(e) {
        var s = this;
        wx.chooseImage({
            count: 3,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var a = e.tempFilePaths, t = s.data.imgs1;
                t = [], s.data.imagelist = [];
                for (var o = 0; o < a.length; o++) 9 <= t.length ? s.setData({
                    imgs1: t
                }) : t.push(a[o]);
                s.setData({
                    imgs1: t,
                    show: "block"
                }), s.setData({
                    picture1: []
                });
                a = s.data.imgs1;
                for (var i = 0; i < a.length; i++) console.log(a[i]), s.uploadimg(a[i]);
            },
            fail: function(e) {},
            complete: function(e) {}
        });
    },
    chooseVideo: function() {
        var a = this;
        wx.chooseVideo({
            sourceType: [ "album", "camera" ],
            maxDuration: 60,
            camera: "back",
            success: function(e) {
                a.uploadvideo(e.tempFilePath), a.setData({
                    src: e.tempFilePath,
                    isvideo: "block"
                });
            }
        });
    },
    uploadvideo: function(e) {
        console.log(e);
        var a = app.util.geturl({
            url: "entry/wxapp/uploadvideo"
        });
        wx.showToast({
            icon: "loading",
            title: "正在上传"
        });
        var o = this;
        wx.uploadFile({
            url: a,
            filePath: e,
            name: "file",
            header: {
                "Content-Type": "multipart/form-data"
            },
            formData: {
                session_token: wx.getStorageSync("session_token")
            },
            success: function(e) {
                var a = JSON.parse(e.data);
                if (console.log(e), 200 == e.statusCode) {
                    var t = a.data.path;
                    console.log(t), o.data.videourl = t;
                } else wx.showModal({
                    title: "提示",
                    content: "上传失败",
                    showCancel: !1
                });
            },
            fail: function(e) {
                wx.showModal({
                    title: "提示",
                    content: "上传失败",
                    showCancel: !1
                });
            },
            complete: function() {
                wx.hideToast();
            }
        });
    },
    bindGetUserInfo: function(e) {
        var a = this;
        app.util.getUserInfo(function(e) {
            console.log(e), a.data.isuser = !0, a.setData({
                userinfo: e,
                isuser: a.data.isuser
            }), a.oldhouseinit();
        }, e.detail);
    },
    upload: function(e) {
        e = e;
        this.doupload(e);
    },
    doupload: function(e) {
        var t, o, i, s, n, r, u = this, d = parseInt(e.currentTarget.dataset.id);
        switch (d) {
          case 1:
            if (0 == u.data.true1) return;
            break;

          case 2:
            if (0 == u.data.true2) return;
            break;

          case 3:
            if (0 == u.data.true3) return;
            break;

          case 4:
            if (0 == u.data.true4) return;
            break;

          case 5:
            if (0 == u.data.true5) return;
            break;

          case 6:
            if (0 == u.data.true6) return;
        }
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var a = e.tempFilePaths;
                switch (d) {
                  case 1:
                    if (t = a, console.log(u.data.true1), 0 == u.data.true1) return;
                    u.data.true1 = !1;
                    break;

                  case 2:
                    o = a, u.data.true2 = !1;
                    break;

                  case 3:
                    i = a, u.data.true3 = !1;
                    break;

                  case 4:
                    s = a, u.data.true4 = !1;
                    break;

                  case 5:
                    n = a, u.data.true5 = !1;
                    break;

                  case 6:
                    r = a, u.data.true6 = !1;
                }
                u.setData({
                    imgurl1: t,
                    imgurl2: o,
                    imgurl3: i,
                    imgurl4: s,
                    imgurl5: n,
                    imgurl6: r,
                    true1: u.data.true1,
                    true2: u.data.true2,
                    true3: u.data.true3,
                    true4: u.data.true4,
                    true5: u.data.true5,
                    true6: u.data.true6
                }), u.data.imagelist.push(a), u.uploadimg(a, d);
            }
        });
    },
    savepubinfo: function(e) {
        var a = this, t = wx.getStorageSync("userInfo");
        if ("" != a.data.videourl) if (0 != a.data.imagelist.length) {
            console.log(a.data.imagelist);
            var o = a.data.imagelist.join("@"), i = e.detail.value.content, s = a.data.videourl;
            if ("" != i) {
                var n = {
                    sessionid: t.sessionid,
                    uid: t.memberInfo.uid,
                    videourl: s,
                    imgstr: o,
                    content: i
                };
                app.util.request({
                    url: "entry/wxapp/savenotevideo",
                    data: n,
                    success: function(e) {
                        if (0 != e.data.errno) return wx.hideLoading(), void wx.showModal({
                            title: "失败",
                            content: e.data.data.msg,
                            showCancel: !1
                        });
                        wx.showToast({
                            title: "提交成功",
                            icon: "success",
                            duration: 2e3,
                            success: function(e) {
                                console.log(e), wx.navigateTo({
                                    url: "/weixinmao_zp/pages/myvideonote/index"
                                });
                            }
                        });
                    }
                });
            } else wx.showModal({
                title: "提示",
                content: "请输入填写个人介绍",
                showCancel: !1
            });
        } else wx.showModal({
            title: "提示",
            content: "请先上传形象照片",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "请先上传视频",
            showCancel: !1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    uploadimg: function(e) {
        var a = app.util.geturl({
            url: "entry/wxapp/upload"
        });
        wx.showToast({
            icon: "loading",
            title: "正在上传"
        });
        var o = this;
        wx.uploadFile({
            url: a,
            filePath: e,
            name: "file",
            header: {
                "Content-Type": "multipart/form-data"
            },
            formData: {
                session_token: wx.getStorageSync("session_token")
            },
            success: function(e) {
                var a = JSON.parse(e.data);
                if (200 == e.statusCode) {
                    var t = a.data.path;
                    o.data.imagelist.push(t);
                } else wx.showModal({
                    title: "提示",
                    content: "上传失败",
                    showCancel: !1
                });
            },
            fail: function(e) {
                wx.showModal({
                    title: "提示",
                    content: "上传失败",
                    showCancel: !1
                });
            },
            complete: function() {
                wx.hideToast();
            }
        });
    },
    checkboxChange: function(e) {
        var a = e.detail.value;
        this.data.special = a.join(",");
    },
    checkboxChangehouse: function(e) {
        var a = e.detail.value;
        this.data.houselabel = a.join(",");
    },
    checkuser: function(a) {
        var t = this, e = (a = a, wx.getStorageSync("userInfo"));
        return console.log(e), e ? e.memberInfo.uid ? void app.util.request({
            url: "entry/wxapp/checkuserinfo",
            data: {
                sessionid: e.sessionid,
                uid: e.memberInfo.uid
            },
            success: function(e) {
                console.log("payyyy"), 0 == e.data.data.error ? a.doServices() : 2 == e.data.data.error && a.doElseServices();
            }
        }) : (app.util.getUserInfo(), !1) : (app.util.getUserInfo(function(e) {
            t.getlethousedetail();
        }), !1);
    }
});