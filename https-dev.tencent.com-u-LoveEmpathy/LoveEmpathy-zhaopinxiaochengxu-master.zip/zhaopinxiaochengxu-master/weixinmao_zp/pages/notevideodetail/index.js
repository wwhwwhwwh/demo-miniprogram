var _data, _Page;

function _defineProperty(a, e, t) {
    return e in a ? Object.defineProperty(a, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[e] = t, a;
}

var R_htmlToWxml = require("../../resource/js/htmlToWxml.js"), imageUtil = require("../../resource/js/images.js"), app = getApp();

Page((_defineProperty(_Page = {
    data: (_data = {
        images: {},
        autoplay: !0,
        interval: 3e3,
        duration: 1e3,
        title: "",
        address: "",
        lat: 0,
        lng: 0,
        id: 0
    }, _defineProperty(_data, "title", ""), _defineProperty(_data, "showcontact", !0), 
    _defineProperty(_data, "isuser", !0), _defineProperty(_data, "truetel", ""), _data),
    imageLoad: function(a) {
        var e = imageUtil.imageUtil(a);
        this.setData({
            imagewidth: e.imageWidth,
            imageheight: e.imageHeight
        });
    },
    onLoad: function(a) {
        this.noteVideo = wx.createVideoContext("noteVideo"), wx.setNavigationBarTitle({
            title: wx.getStorageSync("companyinfo").name
        });
        var e = wx.getStorageSync("companyid");
        e || (e = 0);
        var t = this;
        if (0 < this.data.id) var o = this.data.id; else {
            o = a.id;
            this.data.id = a.id;
        }
        app.util.request({
            url: "entry/wxapp/Getnotevideodetail",
            data: {
                id: o,
                companyid: e
            },
            success: function(a) {
                a.data.message.errno || (t.data.title = a.data.data.workerdetail.name, a.data.data.intro.maincolor || (a.data.data.intro.maincolor = "#3274e5"), 
                wx.setNavigationBarColor({
                    frontColor: wx.getStorageSync('textcolor'),
                    backgroundColor: a.data.data.intro.maincolor,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                }), t.data.truetel = a.data.data.workerdetail.tel2, wx.setNavigationBarTitle({
                    title: t.data.title + "-" + wx.getStorageSync("companyinfo").name
                }), t.setData({
                    data: a.data.data.workerdetail,
                    showcontact: a.data.data.showcontact,
                    tab_image: "block"
                }));
            },
            complete: function() {
                wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
            }
        });
    },
    toSelectlook: function() {
        this.setData({
            isuser: !1
        });
    },
    toLookUser: function() {
        var e = this, a = wx.getStorageSync("userInfo");
        app.util.request({
            url: "entry/wxapp/CheckLookuserrecord",
            data: {
                id: e.data.id,
                sessionid: a.sessionid,
                uid: a.memberInfo.uid
            },
            success: function(a) {
                a.data.message.errno || (1 == a.data.data.status && wx.showModal({
                    title: "系统提示",
                    content: "您的查看简历次数达到了上限,请到用户套餐购买！",
                    showCancel: !1,
                    success: function() {
                        wx.navigateTo({
                            url: "/weixinmao_zp/pages/lookrole/index"
                        });
                    }
                }), e.setData({
                    isuser: !0
                }), wx.makePhoneCall({
                    phoneNumber: e.data.truetel,
                    success: function() {
                        console.log("拨打电话成功！");
                    },
                    fail: function() {
                        console.log("拨打电话失败！");
                    }
                }));
            }
        });
    },
    toLookContact: function(a) {
        var e = this, t = wx.getStorageSync("companyid");
        t ? app.util.request({
            url: "entry/wxapp/CheckLookrecord",
            data: {
                id: e.data.id,
                companyid: t
            },
            success: function(a) {
                a.data.message.errno || (1 == a.data.data.status && wx.showModal({
                    title: "系统提示",
                    content: "您的查看简历次数达到了上限,请到企业中心购买！",
                    showCancel: !1
                }), e.setData({
                    showcontact: a.data.data.showcontact,
                    isuser: !0
                }));
            }
        }) : wx.navigateTo({
            url: "/weixinmao_zp/pages/message/index"
        });
    },
    showplay: function(a) {
        this.setData({
            tab_image: "none"
        }), this.noteVideo.play();
    },
    toMessage: function(a) {
        a.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/weixinmao_zp/pages/message/index"
        });
    }
}, "toLookContact", function(a) {
    var e = this, t = wx.getStorageSync("companyid");
    t ? app.util.request({
        url: "entry/wxapp/CheckLookrecord",
        data: {
            id: e.data.id,
            companyid: t
        },
        success: function(a) {
            a.data.message.errno || (1 == a.data.data.status && wx.showModal({
                title: "系统提示",
                content: "您的查看简历次数达到了上限,请到企业中心购买！",
                showCancel: !1
            }), e.setData({
                showcontact: a.data.data.showcontact
            }));
        }
    }) : wx.navigateTo({
        url: "/weixinmao_zp/pages/message/index"
    });
}), _defineProperty(_Page, "doSendmsg", function(a) {
    var o = this, n = (a.currentTarget.dataset.tel, a.detail.formId);
    wx.showModal({
        title: "邀请面试",
        content: "确认邀请面试？",
        success: function(a) {
            if (a.confirm) {
                var e = wx.getStorageSync("companyid"), t = o.data.id;
                console.log("a" + t), console.log("b" + e), console.log("c" + n), app.util.request({
                    url: "entry/wxapp/Sendinvatejob",
                    data: {
                        id: t,
                        companyid: e,
                        form_id: n
                    },
                    success: function(a) {
                        a.data.message.errno;
                    }
                });
            }
        }
    });
}), _defineProperty(_Page, "goMap", function(a) {
    var e = this;
    console.log(e.data.lat), console.log(e.data.lng), wx.openLocation({
        latitude: e.data.lat,
        longitude: e.data.lng,
        scale: 28,
        name: e.data.title,
        address: e.data.address
    });
}), _defineProperty(_Page, "doCall", function(a) {
    console.log(a.currentTarget);
    var e = a.currentTarget.dataset.tel;
    wx.makePhoneCall({
        phoneNumber: e,
        success: function() {
            console.log("拨打电话成功！");
        },
        fail: function() {
            console.log("拨打电话失败！");
        }
    });
}), _defineProperty(_Page, "onReady", function() {}), _defineProperty(_Page, "onShow", function() {}), 
_defineProperty(_Page, "onHide", function() {}), _defineProperty(_Page, "onUnload", function() {}), 
_defineProperty(_Page, "onPullDownRefresh", function() {
    wx.showNavigationBarLoading(), this.onLoad();
}), _defineProperty(_Page, "onReachBottom", function() {}), _defineProperty(_Page, "onShareAppMessage", function() {}), 
_defineProperty(_Page, "onShareAppMessage", function() {
    return console.log(this.data.id), {
        title: this.data.title + "-" + wx.getStorageSync("companyinfo").name,
        path: "/weixinmao_zp/pages/workerdetail/index?id=" + this.data.id
    };
}), _Page));