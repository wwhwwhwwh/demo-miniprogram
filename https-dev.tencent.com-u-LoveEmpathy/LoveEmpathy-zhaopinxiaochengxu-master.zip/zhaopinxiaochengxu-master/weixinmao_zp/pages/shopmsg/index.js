var R_htmlToWxml = require("../../resource/js/htmlToWxml.js"), imageUtil = require("../../resource/js/images.js"), app = getApp();

Page({
    data: {
        showmsg: !0
    },
    onLoad: function(o) {
        wx.setNavigationBarTitle({
            title: "接收消息设置"
        }), app.util.request({
            url: "entry/wxapp/GetSysInit",
            data: {},
            success: function(o) {
                o.data.message.errno || (o.data.data.intro.maincolor || (o.data.data.intro.maincolor = "#3274e5"), 
                wx.setNavigationBarColor({
                    frontColor: wx.getStorageSync('textcolor'),
                    backgroundColor: o.data.data.intro.maincolor,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                }));
            },
            complete: function() {
                wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var t = this, o = wx.getStorageSync("companyid");
        app.util.request({
            url: "entry/wxapp/getshopmsg",
            data: {
                companyid: o
            },
            success: function(o) {
                o.data.message.errno || t.setData({
                    msgcount: o.data.data.msgcount
                });
            }
        });
    },
    bindMsg: function(o) {
        var t = this, e = wx.getStorageSync("userInfo");
        (t = this).data.showmsg = !0;
        var a = o.detail.formId, s = (e = wx.getStorageSync("userInfo"), wx.getStorageSync("companyid"));
        app.util.request({
            url: "entry/wxapp/saveshopmsg",
            data: {
                form_id: a,
                sessionid: e.sessionid,
                uid: e.memberInfo.uid,
                companyid: s
            },
            success: function(o) {
                if (0 != o.data.errno) return wx.hideLoading(), void wx.showModal({
                    title: "失败",
                    content: o.data.msg,
                    showCancel: !1
                });
                wx.showToast({
                    title: "操作成功",
                    icon: "success",
                    duration: 2e3
                }), t.setData({
                    msgcount: o.data.data.msgcount
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    binduserinfo: function(o) {
        var t = this;
        t.data.showmsg = !1;
        var e = wx.getStorageSync("userInfo"), a = wx.getStorageSync("companyid");
        app.util.request({
            url: "entry/wxapp/getuserinfo",
            data: {
                companyid: a,
                sessionid: e.sessionid,
                uid: e.memberInfo.uid
            },
            success: function(o) {
                t.setData({
                    user: o.data.data,
                    showmsg: t.data.showmsg
                });
            }
        });
    },
    saveuserinfo: function(o) {
        var t = this, e = o.detail.value.name, a = o.detail.value.tel;
        t.data.showmsg = !0;
        var s = wx.getStorageSync("userInfo"), n = wx.getStorageSync("companyid");
        "" != e ? "" != a ? app.util.request({
            url: "entry/wxapp/saveshopuserinfo",
            data: {
                companyid: n,
                sessionid: s.sessionid,
                uid: s.memberInfo.uid,
                name: e,
                tel: a
            },
            success: function(o) {
                if (0 != o.data.errno) return wx.hideLoading(), void wx.showModal({
                    title: "失败",
                    content: o.data.msg,
                    showCancel: !1
                });
                wx.showToast({
                    title: "操作成功",
                    icon: "success",
                    duration: 2e3
                }), t.setData({
                    showmsg: t.data.showmsg
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "请填写您的手机号",
            showCancel: !1
        }) : wx.showModal({
            title: "提示",
            content: "请填写您的姓名",
            showCancel: !1
        });
    },
    closemsg: function(o) {
        this.data.showmsg = !0, this.setData({
            showmsg: this.data.showmsg
        });
    },
    onReachBottom: function() {},
    toMycouponlist: function(o) {
        wx.navigateTo({
            url: "/weixinmao_ktv/pages/couponlist/index"
        });
    },
    toShoporderlist: function(o) {
        wx.navigateTo({
            url: "/weixinmao_ktv/pages/shoproomorderlist/index"
        });
    },
    Puboldhouse: function(o) {
        wx.navigateTo({
            url: "/weixinmao_ktv/pages/pub/index"
        });
    },
    onShareAppMessage: function() {},
    checkuser: function(t) {
        var e = this, o = (t = t, wx.getStorageSync("userInfo"));
        return o ? o.memberInfo.uid ? void app.util.request({
            url: "entry/wxapp/checkuserinfo",
            data: {
                sessionid: o.sessionid,
                uid: o.memberInfo.uid
            },
            success: function(o) {
                0 == o.data.data.error ? (console.log(t), t.doServices()) : 2 == o.data.data.error && t.doServices();
            }
        }) : (console.log("tmddddsssssqqqqs1111"), app.util.getUserInfo(function(o) {
            e.setData({
                userinfo: o
            });
        }), !1) : (console.log("tmddddssssss222222"), app.util.getUserInfo(function(o) {
            app.util.request({
                url: "entry/wxapp/checkuserinfo",
                data: {
                    sessionid: o.sessionid,
                    uid: o.memberInfo.uid
                },
                success: function(o) {
                    0 == o.data.data.error ? (console.log(t), t.doServices()) : 2 == o.data.data.error && t.doServices();
                }
            }), e.setData({
                userinfo: o
            });
        }), !1);
    }
});