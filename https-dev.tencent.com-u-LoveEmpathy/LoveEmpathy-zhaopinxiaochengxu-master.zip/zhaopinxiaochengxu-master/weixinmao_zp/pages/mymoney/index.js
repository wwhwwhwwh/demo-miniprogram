var app = getApp();

Page({
    data: {
        moneyinfo: ""
    },
    onLoad: function(o) {
        var n = this;
        wx.setNavigationBarTitle({
            title: "申请提现"
        });
        var a = wx.getStorageSync("userInfo");
        app.util.request({
            url: "entry/wxapp/getmoney",
            data: {
                sessionid: a.sessionid,
                uid: a.memberInfo.uid
            },
            success: function(o) {
                o.data.message.errno || (o.data.data.intro.maincolor || (o.data.data.intro.maincolor = "#3274e5"), 
                wx.setNavigationBarColor({
                    frontColor: wx.getStorageSync('textcolor'),
                    backgroundColor: o.data.data.intro.maincolor,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                }), n.data.moneyinfo = o.data.data.moneyinfo, n.setData({
                    moneyinfo: o.data.data.moneyinfo
                }));
            }
        });
    },
    toGetmoney: function(o) {
        var n = this.data.moneyinfo, a = o.detail.value.money;
        if ("" != a) if (a > n.totalmoney) wx.showModal({
            title: "提示",
            content: "提现金额大于余额",
            showCancel: !1
        }); else {
            var t = wx.getStorageSync("userInfo");
            app.util.request({
                url: "entry/wxapp/dealmoneyrecord",
                data: {
                    sessionid: t.sessionid,
                    uid: t.memberInfo.uid,
                    money: a,
                    type: "getmoney"
                },
                success: function(o) {
                    if (!o.data.message.errno) return 0 == o.data.data.error ? void wx.showModal({
                        title: "提示",
                        content: o.data.data.msg,
                        showCancel: !1,
                        success: function() {}
                    }) : void wx.showModal({
                        title: "提示",
                        content: o.data.data.msg,
                        showCancel: !1
                    });
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请输入提现金额",
            showCancel: !1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});