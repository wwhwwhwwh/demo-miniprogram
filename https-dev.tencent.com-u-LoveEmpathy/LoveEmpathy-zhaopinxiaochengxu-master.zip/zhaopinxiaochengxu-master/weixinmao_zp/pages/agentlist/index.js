var app = getApp();

Page({
    data: {},
    onLoad: function(a) {
        wx.setNavigationBarTitle({
            title: "经纪人-" + wx.getStorageSync("companyinfo").name
        });
        var t = this;
        app.util.request({
            url: "entry/wxapp/getagentlist",
            success: function(a) {
                a.data.message.errno || (a.data.data.intro.maincolor || (a.data.data.intro.maincolor = "#3274e5"), 
                wx.setNavigationBarColor({
                    frontColor: wx.getStorageSync('textcolor'),
                    backgroundColor: a.data.data.intro.maincolor,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                }), console.log(a.data.data), t.setData({
                    list: a.data.data.list
                }));
            },
            complete: function() {
                wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
            }
        });
    },
    toAgentDetail: function(a) {
        var t = a.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/weixinmao_zp/pages/agentdetail/index?id=" + t
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.showNavigationBarLoading(), this.onLoad();
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "经纪人-" + wx.getStorageSync("companyinfo").name,
            path: "/weixinmao_zp/pages/agentlist/index"
        };
    }
});