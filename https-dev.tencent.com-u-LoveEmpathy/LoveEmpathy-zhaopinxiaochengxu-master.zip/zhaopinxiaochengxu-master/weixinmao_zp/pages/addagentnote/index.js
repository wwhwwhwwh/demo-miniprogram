var _Page;

function _defineProperty(e, a, t) {
	return a in e ? Object.defineProperty(e, a, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[a] = t, e;
}

var app = getApp();

function isHasElementOne(e, a) {
	for (var t = 0, i = e.length; t < i; t++)
		if (e[t] == a) return t;
	return -1;
}

function isHasElementTwo(e, a) {
	for (var t = 0, i = e.length; t < i; t++)
		if (e[t].id == a) return t;
	return -1;
}

Page((_defineProperty(_Page = {
	data: {
		title: "",
		special: "",
		imagelist: [],
		uploadimagelist: ["", "", "", "", "", ""],
		true1: !0,
		true2: !0,
		true3: !0,
		true4: !0,
		true5: !0,
		true6: !0,
		arealist: [],
		areaindexid: 0,
		areaid: 0,
		jobcate: [],
		jobcateid: 0,
		toplist: [],
		toplistid: 0,
		sex: 1,
		speciallist: [{
			name: "五险一金",
			checked: !1
		}, {
			name: "补充医疗保险",
			checked: !1
		}, {
			name: "员工旅游",
			checked: !1
		}, {
			name: "交通补贴",
			checked: !1
		}, {
			name: "餐饮补贴",
			checked: !1
		}, {
			name: "出国机会",
			checked: !1
		}, {
			name: "年终奖金",
			checked: !1
		}, {
			name: "定期体检",
			checked: !1
		}],
		education: ["初中", "高中", "中技", "中专", "大专", "本科", "硕士", "博士", "博后"],
		educationindex: -1,
		educationname: "",
		express: ["无经验", "1年以下", "1-3年", "3-5年", "5-10年", "10年以上"],
		expressindex: -1,
		expressname: "",
		currentstatus: ["我目前已离职,可快速到岗", "我目前在职，但考虑换个新环境", "观望有好的机会再考虑", "目前暂无跳槽打算", "应届毕业生"],
		currentstatusindex: -1,
		currentstatusname: "",
		worktype: ["全职", "兼职", "实习"],
		worktypeindex: -1,
		worktypename: "",
		money: ["1千~2千/月", "2千~3千/月", "3千~4千/月", "4千~5千/月", "5千~1万/月", "1万以上/月"],
		moneyindex: -1,
		moneyname: "",
		id: 0
	},
	onLoad: function(e) {
		var a = this;
		a.data.id = e.id, wx.setNavigationBarTitle({
			title: "简历编辑-" + wx.getStorageSync("companyinfo").name
		});
		var t = wx.getStorageSync("userInfo");
		t && t.hasOwnProperty("wxInfo") ? (a.data.isuser = !0, a.initpage(),
			a.setData({
				userinfo: t
			})) : a.data.isuser = !1, a.setData({
			isuser: a.data.isuser
		});
	},
	initpage: function() {
		var e = wx.getStorageSync("cityinfo");
		e ? wx.setStorageSync("city", e.name) : (qqmapsdk = new QQMapWX({
			key: "5D3BZ-J55WF-SFPJJ-NI6PG-YN2ZO-M4BHX"
		}), wx.getLocation({
			type: "gcj02",
			success: function(e) {
				qqmapsdk.reverseGeocoder({
					location: {
						latitude: e.latitude,
						longitude: e.longitude
					},
					success: function(e) {
						var a = e.result.address_component.city,
							t = a.substr(0, a.length - 1);
						wx.setStorageSync("city", t);
					}
				});
			},
			fail: function() {},
			complete: function() {}
		}));
	},
	oldhouseinit: function(e) {
		var i = this,
			a = wx.getStorageSync("userInfo"),
			t = wx.getStorageSync("city");
		app.util.request({
			url: "entry/wxapp/Getpubinit",
			data: {
				city: t,
				sessionid: a.sessionid,
				uid: a.memberInfo.uid
			},
			success: function(e) {
				if (!e.data.message.errno && (e.data.data.intro.maincolor || (e.data.data.intro.maincolor = "#3274e5"),
						wx.setNavigationBarColor({
							frontColor: wx.getStorageSync('textcolor'),
							backgroundColor: e.data.data.intro.maincolor,
							animation: {
								duration: 400,
								timingFunc: "easeIn"
							}
						}), 1 == e.data.data.isbind)) {
					var a = e.data.data.cityinfo;
					wx.setStorageSync("cityinfo", a), i.data.arealist = e.data.data.arealist;
					var t = e.data.data.noteinfo;
					t && (i.data.jobtitle = t.jobtitle, i.data.currentstatusindex = isHasElementOne(i.data.currentstatus, t.currentstatus),
						i.data.currentstatusname = t.currentstatus, i.data.jobcateindex = isHasElementTwo(e.data.data.jobcate, t
							.jobcateid),
						i.data.jobcateid = t.jobcateid, i.data.areaindexid = isHasElementTwo(e.data.data.arealist, t.areaid),
						i.data.areaid = t.areaid, i.data.educationindex = isHasElementOne(i.data.education, t.education),
						i.data.educationname = t.education, i.data.expressindex = isHasElementOne(i.data.express, t.express),
						i.data.expressname = t.express, i.data.worktypeindex = isHasElementOne(i.data.worktype, t.worktype),
						i.data.worktypename = t.worktype, i.data.moneyindex = isHasElementOne(i.data.money, t.money),
						i.data.moneyname = t.money, i.data.sex = t.sex, i.data.special = t.special), i.setData({
						jobcate: e.data.data.jobcate,
						arealist: e.data.data.arealist,
						noteinfo: t,
						currentstatusindex: i.data.currentstatusindex,
						jobcateindex: i.data.jobcateindex,
						educationindex: i.data.educationindex,
						expressindex: i.data.expressindex,
						worktypeindex: i.data.worktypeindex,
						moneyindex: i.data.moneyindex,
						areaindexid: i.data.areaindexid
					});
				}
			}
		});
	},
	checkboxChange: function(e) {
		var a = e.detail.value;
		this.data.special = a.join(",");
	},
	bindAreaChange: function(e) {
		var a = this.data.arealist;
		a && (this.data.areaid = a[e.detail.value].id, this.data.areaindexid = e.detail.value),
			this.setData({
				arealist: a,
				areaindexid: e.detail.value
			});
	},
	bindJobcateChange: function(e) {
		var a = this.data.jobcate;
		a && (this.data.jobcateindex = e.detail.value, this.data.jobcateid = a[e.detail.value].id),
			this.setData({
				jobcate: a,
				jobcateindex: e.detail.value
			});
	},
	bindExpressChange: function(e) {
		var a = this.data.express;
		a && (this.data.expressindex = e.detail.value, this.data.expressname = a[e.detail.value]),
			this.setData({
				express: a,
				expressindex: e.detail.value
			});
	},
	bindEducationChange: function(e) {
		var a = this.data.education;
		a && (this.data.educationindex = e.detail.value, this.data.educationname = a[e.detail.value]),
			this.setData({
				education: a,
				educationindex: e.detail.value
			});
	},
	bindWorktypeChange: function(e) {
		var a = this.data.worktype;
		a && (this.data.worktypeindex = e.detail.value, this.data.worktypename = a[e.detail.value]),
			this.setData({
				worktype: a,
				worktypeindex: e.detail.value
			});
	},
	bindMoneyChange: function(e) {
		var a = this.data.money;
		a && (this.data.moneyindex = e.detail.value, this.data.moneyname = a[e.detail.value]),
			this.setData({
				money: a,
				moneyindex: e.detail.value
			});
	},
	bindCurrentstatusChange: function(e) {
		var a = this.data.currentstatus;
		a && (this.data.currentstatusindex = e.detail.value, this.data.currentstatusname = a[e.detail.value]),
			this.setData({
				currentstatus: a,
				currentstatusindex: e.detail.value
			});
	},
	bindToplistChange: function(e) {
		var a = this.data.toplist;
		a && (this.data.toplistid = a[e.detail.value].id), this.setData({
			toplist: a,
			toplistidindex: e.detail.value
		});
	},
	savepubinfo: function(e) {
		var a, t = this,
			i = wx.getStorageSync("userInfo"),
			n = e.detail.value.jobtitle,
			s = e.detail.value.name,
			o = t.data.sex,
			d = e.detail.value.birthday,
			r = t.data.educationname,
			l = t.data.expressname,
			u = e.detail.value.address,
			c = e.detail.value.email,
			h = e.detail.value.tel,
			p = t.data.currentstatusname,
			f = t.data.worktypename,
			m = this.data.jobcateid,
			x = this.data.moneyname,
			w = this.data.areaid,
			g = e.detail.value.content;
		if (wx.getStorageSync("tid") && wx.getStorageSync("tid"), wx.getStorageSync("shareid") && wx.getStorageSync(
				"shareid"),
			"" != n)
			if (0 != s)
				if ("" != d)
					if ("" != r)
						if ("" != l)
							if ("" != u)
								if ("" != c)
									if ("" != h)
										if ("" != p)
											if ("" != f)
												if (0 != m)
													if ("" != x)
														if (0 != w)
															if ("" != g) {
																var y = this.data.uploadimagelist;
																if (y.length < 2) wx.showModal({
																	title: "提示",
																	content: "上传图片不少于2张",
																	showCancel: !1
																});
																else {
																	var v = y[0],
																		b = (_defineProperty(a = {
																				cityid: wx.getStorageSync("cityinfo").id,
																				sessionid: i.sessionid,
																				uid: i.memberInfo.uid,
																				jobtitle: n,
																				name: s,
																				sex: o,
																				tel: h,
																				birthday: d,
																				education: r,
																				express: l,
																				address: u,
																				email: c
																			}, "tel", h), _defineProperty(a, "currentstatus", p), _defineProperty(a, "worktype", f),
																			_defineProperty(a, "jobcateid", m), _defineProperty(a, "money", x), _defineProperty(a, "areaid",
																				w),
																			_defineProperty(a, "content", g), _defineProperty(a, "uploadimagelist_str", v),
																			a);
																	app.util.request({
																		url: "entry/wxapp/Savenote",
																		data: b,
																		success: function(e) {
																			if (0 != e.data.errno) return wx.hideLoading(), void wx.showModal({
																				title: "失败",
																				content: e.data.data.msg,
																				showCancel: !1
																			});
																			wx.showToast({
																				title: "保存成功",
																				icon: "success",
																				duration: 2e3,
																				success: function(e) {
																					wx.navigateBack({
																						changed: !0
																					});
																				}
																			});
																		}
																	});
																}
															} else wx.showModal({
																title: "提示",
																content: "请输入自我介绍及工作经历",
																showCancel: !1
															});
		else wx.showModal({
			title: "提示",
			content: "请选择工作地区",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择期望薪资",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择期望行业",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择工作性质",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择目前状态",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请填写手机号",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请填写邮箱",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请填写现居住地",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择工作经验",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择最高学历",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择出生年份",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入姓名",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入意向职位",
			showCancel: !1
		});
	},
	onReady: function() {},
	radioChange: function(e) {
		this.data.sex = e.detail.value;
	},
	onShow: function() {},
	onHide: function() {},
	onUnload: function() {},
	onPullDownRefresh: function() {},
	onReachBottom: function() {},
	onShareAppMessage: function() {},
	bindGetUserInfo: function(e) {
		var a = this;
		app.util.getUserInfo(function(e) {
			a.data.isuser = !0, a.oldhouseinit(), a.setData({
				userinfo: e,
				isuser: a.data.isuser
			});
		}, e.detail);
	},
	uploadimg: function(e, n) {
		var a = app.util.geturl({
			url: "entry/wxapp/upload"
		});
		n = n;
		wx.showToast({
			icon: "loading",
			title: "正在上传"
		});
		var s = this;
		wx.uploadFile({
			url: a,
			filePath: e[0],
			name: "file",
			header: {
				"Content-Type": "multipart/form-data"
			},
			formData: {
				session_token: wx.getStorageSync("session_token")
			},
			success: function(e) {
				var a = JSON.parse(e.data);
				if (200 == e.statusCode)
					for (var t = a.data.path, i = 0; i < s.data.uploadimagelist.length; i++) {
						i + 1 == n && (s.data.uploadimagelist[i] = t);
					} else wx.showModal({
						title: "提示",
						content: "上传失败",
						showCancel: !1
					});
			},
			fail: function(e) {
				wx.showModal({
					title: "提示",
					content: "上传失败",
					showCancel: !1
				});
			},
			complete: function() {
				wx.hideToast();
			}
		});
	},
	upload: function(e) {
		var a = this;
		e = e;
		a.checkuser({
			doServices: function() {
				a.doupload(e);
			},
			doElseServices: function() {
				a.doupload(e);
			}
		});
	},
	doupload: function(e) {
		var t, i, n, s, o, d, r = this,
			l = parseInt(e.currentTarget.dataset.id);
		switch (l) {
			case 1:
				if (0 == r.data.true1) return;
				break;

			case 2:
				if (0 == r.data.true2) return;
				break;

			case 3:
				if (0 == r.data.true3) return;
				break;

			case 4:
				if (0 == r.data.true4) return;
				break;

			case 5:
				if (0 == r.data.true5) return;
				break;

			case 6:
				if (0 == r.data.true6) return;
		}
		wx.chooseImage({
			count: 1,
			sizeType: ["compressed"],
			sourceType: ["album", "camera"],
			success: function(e) {
				var a = e.tempFilePaths;
				switch (l) {
					case 1:
						if (t = a, 0 == r.data.true1) return;
						r.data.true1 = !1;
						break;

					case 2:
						i = a, r.data.true2 = !1;
						break;

					case 3:
						n = a, r.data.true3 = !1;
						break;

					case 4:
						s = a, r.data.true4 = !1;
						break;

					case 5:
						o = a, r.data.true5 = !1;
						break;

					case 6:
						d = a, r.data.true6 = !1;
				}
				r.setData({
					imgurl1: t,
					imgurl2: i,
					imgurl3: n,
					imgurl4: s,
					imgurl5: o,
					imgurl6: d,
					true1: r.data.true1,
					true2: r.data.true2,
					true3: r.data.true3,
					true4: r.data.true4,
					true5: r.data.true5,
					true6: r.data.true6
				}), r.data.imagelist.push(a), r.uploadimg(a, l);
			}
		});
	},
	delupload: function(e) {
		var a = this,
			t = parseInt(e.currentTarget.dataset.id);
		switch (t) {
			case 1:
				a.setData({
					imgurl1: "",
					true1: !0
				});
				break;

			case 2:
				a.setData({
					imgurl2: "",
					true2: !0
				});
				break;

			case 3:
				a.setData({
					imgurl3: "",
					true3: !0
				});
				break;

			case 4:
				a.setData({
					imgurl4: "",
					true4: !0
				});
				break;

			case 5:
				a.setData({
					imgurl5: "",
					true5: !0
				});
				break;

			case 6:
				a.setData({
					imgurl6: "",
					true6: !0
				});
		}
		for (var i = 0; i < this.data.uploadimagelist.length; i++) {
			i + 1 == t && (this.data.uploadimagelist[i] = "");
		}
	}
}, "checkboxChange", function(e) {
	var a = e.detail.value;
	this.data.special = a.join(",");
}), _defineProperty(_Page, "checkuser", function(a) {
	var t = this,
		e = (a = a, wx.getStorageSync("userInfo"));
	return e ? e.memberInfo.uid ? void app.util.request({
		url: "entry/wxapp/checkuserinfo",
		data: {
			sessionid: e.sessionid,
			uid: e.memberInfo.uid
		},
		success: function(e) {
			0 == e.data.data.error ? a.doServices() : 2 == e.data.data.error && a.doElseServices();
		}
	}) : (app.util.getUserInfo(), !1) : (app.util.getUserInfo(function(e) {
		t.oldhouseinit();
	}), !1);
}), _Page));
