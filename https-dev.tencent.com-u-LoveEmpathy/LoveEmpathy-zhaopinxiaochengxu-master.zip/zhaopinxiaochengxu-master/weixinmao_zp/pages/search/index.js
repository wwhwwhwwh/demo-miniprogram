function _defineProperty(a, t, e) {
    return t in a ? Object.defineProperty(a, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[t] = e, a;
}

var app = getApp();

Page(_defineProperty({
    data: {},
    onLoad: function(a) {
        wx.setNavigationBarTitle({
            title: "信息综合查询"
        }), this.setData({
            loadmore: !0
        }), app.util.request({
            url: "entry/wxapp/GetSysInit",
            data: {},
            success: function(a) {
                a.data.message.errno || (a.data.data.intro.maincolor || (a.data.data.intro.maincolor = "#3274e5"), 
                wx.setNavigationBarColor({
                    frontColor: wx.getStorageSync('textcolor'),
                    backgroundColor: a.data.data.intro.maincolor,
                    animation: {
                        duration: 400,
                        timingFunc: "easeIn"
                    }
                }));
            },
            complete: function() {
                wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
            }
        });
    },
    toJobDetail: function(a) {
        var t = a.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/weixinmao_zp/pages/jobdetail/index?id=" + t
        });
    },
    onReady: function() {},
    onShow: function() {
        this.setData({
            loadmore: !0
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    bindSave: function(a) {
        var t = this, e = a.detail.value.keyword;
        "" != e ? app.util.request({
            url: "entry/wxapp/search",
            data: {
                keyword: e
            },
            success: function(a) {
                if (0 != a.data.errno) return wx.hideLoading(), void wx.showModal({
                    title: "失败",
                    content: a.data.data.msg,
                    showCancel: !1
                });
                0 == a.data.data.length ? (console.log("fffffffff"), t.setData({
                    list: a.data.data,
                    loadmore: !1
                })) : t.setData({
                    list: a.data.data,
                    loadmore: !0
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "请输入相关职位名称",
            showCancel: !1
        });
    }
}, "onShareAppMessage", function() {
    return {
        title: "信息综合查询-" + wx.getStorageSync("companyinfo").name,
        path: "/weixinmao_zp/pages/search/index"
    };
}));