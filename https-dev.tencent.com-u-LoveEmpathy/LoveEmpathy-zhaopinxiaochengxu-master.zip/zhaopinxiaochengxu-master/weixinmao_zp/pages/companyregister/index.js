var _Page;

function _defineProperty(a, e, t) {
	return e in a ? Object.defineProperty(a, e, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : a[e] = t, a;
}

var qqmapsdk, QQMapWX = require("../../resource/js/qqmap-wx-jssdk.min.js"),
	app = getApp();

function isHasElementOne(a, e) {
	for (var t = 0, o = a.length; t < o; t++)
		if (a[t] == e) return t;
	return -1;
}

function isHasElementTwo(a, e) {
	for (var t = 0, o = a.length; t < o; t++)
		if (a[t].id == e) return t;
	return -1;
}

Page((_defineProperty(_Page = {
	data: {
		title: "",
		special: "",
		imagelist: [],
		uploadimagelist: ["", "", "", "", "", ""],
		true1: !0,
		true2: !0,
		true3: !0,
		true4: !0,
		true5: !0,
		true6: !0,
		arealist: [],
		areaidindex: -1,
		areaid: 0,
		lat: 0,
		lng: 0
	},
	onLoad: function(a) {
		var o = this;
		o.data.id = a.id, wx.setNavigationBarTitle({
			title: "企业注册"
		});
		wx.getStorageSync("companyid");
		var e = wx.getStorageSync("cityinfo");
		e ? (wx.setStorageSync("city", e.name), o.oldhouseinit()) : (qqmapsdk = new QQMapWX({
			key: "5D3BZ-J55WF-SFPJJ-NI6PG-YN2ZO-M4BHX"
		}), wx.getLocation({
			type: "gcj02",
			success: function(a) {
				qqmapsdk.reverseGeocoder({
					location: {
						latitude: a.latitude,
						longitude: a.longitude
					},
					success: function(a) {
						var e = a.result.address_component.city,
							t = e.substr(0, e.length - 1);
						wx.setStorageSync("city", t), o.oldhouseinit();
					}
				});
			},
			fail: function() {
				o.oldhouseinit();
			},
			complete: function() {}
		}));
	},
	oldhouseinit: function(a) {
		var o = this,
			e = wx.getStorageSync("companyid"),
			t = wx.getStorageSync("city");
		console.log(t), o.setData({}), app.util.request({
			url: "entry/wxapp/Regcompanyinit",
			data: {
				city: t,
				companyid: e
			},
			success: function(a) {
				if (!a.data.message.errno)
					if (a.data.data.intro.maincolor || (a.data.data.intro.maincolor = "#3274e5"),
						wx.setNavigationBarColor({
							frontColor: wx.getStorageSync('textcolor'),
							backgroundColor: a.data.data.intro.maincolor,
							animation: {
								duration: 400,
								timingFunc: "easeIn"
							}
						}), 1 == a.data.data.isbind) {
						o.data.arealist = a.data.data.arealist;
						var e = a.data.data.companyinfo,
							t = a.data.data.cityinfo;
						wx.setStorageSync("cityinfo", t), o.setData({
							companyinfo: e,
							arealist: o.data.arealist,
							city: t.name
						});
					} else wx.redirectTo({
						url: "/weixinmao_zp/pages/binduser/index"
					});
			}
		});
	},
	getpostion: function() {
		var e = this;
		wx.chooseLocation({
			success: function(a) {
				console.log(a.name), console.log(a.latitude), console.log(a.longitude), e.data.lat = a.latitude,
					e.data.lng = a.longitude, e.setData({
						address: a.name
					});
			},
			fail: function(a) {
				console.log(a);
			},
			complete: function() {}
		});
	},
	checkboxChange: function(a) {
		var e = a.detail.value;
		this.data.special = e.join(",");
	},
	bindAreaChange: function(a) {
		var e = this.data.arealist;
		e && (this.data.areaid = e[a.detail.value].id, this.data.areaidindex = a.detail.value),
			this.setData({
				arealist: e,
				areaidindex: a.detail.value
			});
	},
	savepubinfo: function(a) {
		var e = this,
			t = a.detail.formId,
			o = wx.getStorageSync("userInfo"),
			i = wx.getStorageSync("companyid"),
			n = a.detail.value.companyname,
			s = a.detail.value.companycate,
			r = a.detail.value.companytype,
			l = a.detail.value.companyworker,
			d = a.detail.value.mastername,
			c = a.detail.value.tel,
			u = a.detail.value.address,
			g = a.detail.value.account,
			f = a.detail.value.password,
			p = a.detail.value.password2,
			w = a.detail.value.content,
			m = (e.data.id,
				e.data.areaid);
		if (0 != m)
			if ("" != n)
				if (0 != s)
					if ("" != r)
						if ("" != l)
							if ("" != d)
								if ("" != c)
									if ("" != e.data.lat && "" != e.data.lng)
										if ("" != u)
											if ("" != g)
												if ("" != f)
													if ("" != p)
														if (f == p)
															if ("" != w) {
																var h = 0;
																wx.getStorageSync("tid") && (h = wx.getStorageSync("tid"));
																var y = this.data.uploadimagelist;
																console.log(y);
																var x = {
																	areaid: m,
																	cityid: wx.getStorageSync("cityinfo").id,
																	sessionid: o.sessionid,
																	uid: o.memberInfo.uid,
																	companyid: i,
																	companyname: n,
																	companycate: s,
																	companytype: r,
																	companyworker: l,
																	mastername: d,
																	tel: c,
																	address: u,
																	account: g,
																	password: f,
																	content: w,
																	lat: e.data.lat,
																	lng: e.data.lng,
																	logo: y[0],
																	cardimg: y[1],
																	tid: h,
																	form_id: t
																};
																app.util.request({
																	url: "entry/wxapp/Addcompanyinfo",
																	data: x,
																	success: function(a) {
																		if (0 != a.data.errno) return wx.hideLoading(), void wx.showModal({
																			title: "失败",
																			content: a.data.data.msg,
																			showCancel: !1
																		});
																		wx.showToast({
																			title: "提交成功",
																			icon: "success",
																			success: function(a) {
																				setTimeout((r)=>{
																					wx.navigateTo({
																						url: "/weixinmao_zp/pages/message/index"
																					});
																				}, 1500)
																			},
																		});
																	}
																});
															} else wx.showModal({
																title: "提示",
																content: "请输入公司介绍",
																showCancel: !1
															});
		else wx.showModal({
			title: "提示",
			content: "两次密码不一致",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入确认密码",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入登录密码",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入登录账号",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择位置",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择位置",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入手机号",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入负责人",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入人员规模",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入企业性质",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入企业行业",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请输入企业名称",
			showCancel: !1
		});
		else wx.showModal({
			title: "提示",
			content: "请选择区域",
			showCancel: !1
		});
	},
	onReady: function() {},
	radioChange: function(a) {
		this.data.sex = a.detail.value;
	},
	onShow: function() {},
	onHide: function() {},
	onUnload: function() {},
	onPullDownRefresh: function() {},
	onReachBottom: function() {},
	onShareAppMessage: function() {},
	upload: function(a) {
		a = a;
		this.doupload(a);
	},
	doupload: function(a) {
		var t, o, i, n, s, r, l = this,
			d = parseInt(a.currentTarget.dataset.id);
		switch (d) {
			case 1:
				if (0 == l.data.true1) return;
				break;

			case 2:
				if (0 == l.data.true2) return;
				break;

			case 3:
				if (0 == l.data.true3) return;
				break;

			case 4:
				if (0 == l.data.true4) return;
				break;

			case 5:
				if (0 == l.data.true5) return;
				break;

			case 6:
				if (0 == l.data.true6) return;
		}
		wx.chooseImage({
			count: 1,
			sizeType: ["compressed"],
			sourceType: ["album", "camera"],
			success: function(a) {
				var e = a.tempFilePaths;
				switch (d) {
					case 1:
						if (t = e, console.log(l.data.true1), 0 == l.data.true1) return;
						l.data.true1 = !1;
						break;

					case 2:
						o = e, l.data.true2 = !1;
						break;

					case 3:
						i = e, l.data.true3 = !1;
						break;

					case 4:
						n = e, l.data.true4 = !1;
						break;

					case 5:
						s = e, l.data.true5 = !1;
						break;

					case 6:
						r = e, l.data.true6 = !1;
				}
				l.setData({
					imgurl1: t,
					imgurl2: o,
					imgurl3: i,
					imgurl4: n,
					imgurl5: s,
					imgurl6: r,
					true1: l.data.true1,
					true2: l.data.true2,
					true3: l.data.true3,
					true4: l.data.true4,
					true5: l.data.true5,
					true6: l.data.true6
				}), l.data.imagelist.push(e), l.uploadimg(e, d);
			}
		});
	},
	uploadimg: function(a, i) {
		var e = app.util.geturl({
			url: "entry/wxapp/upload"
		});
		i = i;
		wx.showToast({
			icon: "loading",
			title: "正在上传"
		});
		var n = this;
		wx.uploadFile({
			url: e,
			filePath: a[0],
			name: "file",
			header: {
				"Content-Type": "multipart/form-data"
			},
			formData: {
				session_token: wx.getStorageSync("session_token")
			},
			success: function(a) {
				var e = JSON.parse(a.data);
				if (200 == a.statusCode)
					for (var t = e.data.path, o = 0; o < n.data.uploadimagelist.length; o++) {
						o + 1 == i && (n.data.uploadimagelist[o] = t);
					} else wx.showModal({
						title: "提示",
						content: "上传失败",
						showCancel: !1
					});
			},
			fail: function(a) {
				wx.showModal({
					title: "提示",
					content: "上传失败",
					showCancel: !1
				});
			},
			complete: function() {
				wx.hideToast();
			}
		});
	},
	delupload: function(a) {
		var e = this,
			t = parseInt(a.currentTarget.dataset.id);
		switch (t) {
			case 1:
				e.setData({
					imgurl1: "",
					true1: !0
				});
				break;

			case 2:
				e.setData({
					imgurl2: "",
					true2: !0
				});
				break;

			case 3:
				e.setData({
					imgurl3: "",
					true3: !0
				});
				break;

			case 4:
				e.setData({
					imgurl4: "",
					true4: !0
				});
				break;

			case 5:
				e.setData({
					imgurl5: "",
					true5: !0
				});
				break;

			case 6:
				e.setData({
					imgurl6: "",
					true6: !0
				});
		}
		for (var o = 0; o < this.data.uploadimagelist.length; o++) {
			o + 1 == t && (this.data.uploadimagelist[o] = "");
		}
		console.log(this.data.uploadimagelist);
	}
}, "checkboxChange", function(a) {
	var e = a.detail.value;
	this.data.special = e.join(",");
}), _defineProperty(_Page, "checkuser", function(e) {
	var t = this,
		a = (e = e, wx.getStorageSync("userInfo"));
	return console.log(a), a ? a.memberInfo.uid ? void app.util.request({
		url: "entry/wxapp/checkuserinfo",
		data: {
			sessionid: a.sessionid,
			uid: a.memberInfo.uid
		},
		success: function(a) {
			console.log("payyyy"), 0 == a.data.data.error ? e.doServices() : 2 == a.data.data.error && e.doElseServices();
		}
	}) : (app.util.getUserInfo(), !1) : (app.util.getUserInfo(function(a) {
		t.oldhouseinit();
	}), !1);
}), _Page));
