var config = {
    key: "PKZBZ-GMBKF-TQ2JH-NWSA6-C4WIS-TABRB"
};

module.exports.Config = config;