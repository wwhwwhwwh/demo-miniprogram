const id = 3 //所属ID
module.exports = {
    name: "",
    uniacid: id,
    acid: id,
    multiid: "0",
    version: "4.0.85",
    siteroot: "https://job.tpengyun.com/app/index.php",
    design_method: "3"
};

//你看最上面有一行  声明了id  这个id就是对应的we7的acid  但是往往acid跟uniacid是一样的   不一样的情况非常少
//这个后台看