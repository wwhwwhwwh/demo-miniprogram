# 仿酷安app发布按钮动效

> 以前写的一个代码，稍微完善了下，代码比较简单，用到了css动画跟小程序Animation，完善了下注释。多的不说了，代码比较简陋，直接看效果图吧

## 效果视频
!!!
<video id="video" controls="" preload="none" poster="http://pwxt9ivat.bkt.clouddn.com/poster.png">
      <source id="mp4" src="http://pwxt9ivat.bkt.clouddn.com/video.mp4" type="video/mp4">
</video>
!!!

## 序言
> 部分css代码参考网上代码

## 源码
> 腾讯代码托管 [去看看](https://dev.tencent.com/u/LoveEmpathy/p/kuan_menu/git)

## 博客
> LoveEmpathy [去看看](https://loveempathy.com)