var id = ""//填写小程序acid即可
module.exports = {
    name: "小程序演示",
    uniacid: id,//不用修改
    acid: id,//不用修改
    multiid: "0",//不用修改
    version: "3.4.5",//不用修改
    siteroot: "https://114.tpengyun.com/app/index.php",//不用修改
    design_method: "3"
};