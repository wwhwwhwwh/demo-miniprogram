var _underscore = require("../../../resource/utils/underscore"), _underscore2 = _interopRequireDefault(_underscore), _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var app = getApp();

Page({
    data: {
        userInfo: {},
        menu_list: "",
        isshow: !0,
        showFlag: !0,
        is_open_card: !1,
        systel: "17601500531"
    },
    onLoad: function() {
        app.setTabbar();
        var e = this, a = wx.getStorageSync("userInfo");
        a || null != a.wxInfo ? e.setData({
            showFlag: !0
        }) : e.setData({
            showFlag: !1
        });
        var n = "http://s1.ljcdn.com/matrix_wx_app/images/user/user@2x.png?v=1522316729673", t = "";
        a && a.wxInfo && (n = a.wxInfo.avatarUrl, t = a.wxInfo.nickName), a && a.memberInfo && (a.memberInfo && a.memberInfo.avatar && (n = a.memberInfo.avatar), 
        a.memberInfo && a.memberInfo.nickname && (t = a.memberInfo.nickname)), wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"];
            }
        }), e.setData({
            avatarUrl: n,
            nickName: t
        });
    },
    onShow: function() {
        var a = this;
        _request2.default.get("ApiGetMyInfo", {}).then(function(e) {
            a.setData({
                config: e
            }), app.globalData.sysinfo.credit1 = e.credit1, app.globalData.sysinfo.is_call = e.is_call, 
            null != e.bgcolor && 2 < e.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: e.bgcolor,
                animation: {
                    duration: 400,
                    timingFunc: "linear"
                }
            }), a.onPullDownRefresh();
        });
    },
    onPullDownRefresh: function() {
        var e = this, a = [];
        null != e.data.config && 0 == e.data.config.is_credit && (a.push({
            // menus: [ {
            //     name: "_view2",
            //     text: "我的积分(" + e.data.config.credit1 + ")",
            //     link: "/amouse_tel/pages/integral/mall/index",
            //     icon: "icon-favor"
            // } ],
            type: "line"
        }), a.push({
            menus: [ {
                name: "_view",
                text: "积分商场",
                link: "/amouse_tel/pages/integral/mall/index",
                icon: "icon-hotfill"
            } ],
            type: "line"
          })), a.push({
            menus: [{
              name: "_view",
              text: "小程序导航",
              link: "/amouse_tel/pages/nav/index/index",
              icon: "icon-we7-xiaochengxudaohang"
            }],
          //   type: "line"
          // });null != e.data.config && "" != e.data.config.systel && a.push({
          //   menus: [{
          //     name: "wechat_tel",
          //     text: "联系我们",
          //     link: "wechat_tel",
          //     icon: "icon-phone"
          //   }],
            type: "line"
        }), e.setData({
            menus: a,
        });
    },
    onNavigateTap: function(e) {
        var a = this, n = e.currentTarget.dataset, t = n.url, o = n.name;
        "wechat_clear" == o ? (wx.showToast({
            title: "正在清理中...",
            icon: "loading",
            duration: 10
        }), wx.clearStorageSync(), app.util.getUserInfo(function(e) {
            app.globalData.hasLogin = !0, a.setData({
                userInfo: e
            }), app.globalData.userInfo = e;
        }), wx.showToast({
            title: "清理完成",
            icon: "success",
            duration: 1500
        })) : "wechat_tel" == o ? wx.makePhoneCall({
            phoneNumber: a.data.config.systel
        }) : "wechat_info_sync" == o ? a.onSyncWechatInfo() : "_view2" == o ? wx.switchTab({
            url: t,
            fail: function() {
                wx.navigateTo({
                    url: t
                });
            }
        }) : "_view3" == o ? wx.navigateToMiniProgram ? wx.navigateToMiniProgram({
            appId: t,
            path: "",
            extraData: {},
            envVersion: "trial",
            success: function(e) {
                console.log(e);
            },
            fail: function(e) {
                console.log(e);
            }
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        }) : "other" == o ? wx.showModal({
            title: "敬请期待",
            content: "功能开发中，敬请期待",
            showCancel: !1
        }) : wx.navigateTo({
            url: t,
            fail: function() {
                wx.switchTab({
                    url: t
                });
            }
        });
    },
    onSyncWechatInfo: function() {
        var a = this;
        app.util.getUserInfo(function(e) {
            app.globalData.hasLogin = !0, a.setData({
                userInfo: e
            }), app.globalData.userInfo = e;
        });
    },
    updateUserInfo: function(e) {
        var n = this, t = this, a = wx.getStorageSync("userInfo");
        a && null != a.wxInfo || (app.util.getUserInfo(function(e) {
            t.setData({
                showFlag: !0,
                userInfo: e
            });
            var a = null == e.memberInfo.headimgurl ? e.wxInfo.avatarUrl : e.memberInfo.headimgurl, n = "" == e.memberInfo.nickname ? e.wxInfo.nickName : e.memberInfo.nickname;
            t.setData({
                avatarUrl: a,
                nickName: n
            }), app.globalData.userInfo = e;
        }), "getUserInfo:fail auth deny" == e.detail.errMsg && wx.getSetting({
            success: function(e) {
                if (!0 === e.authSetting["scope.userInfo"]) {
                    var a = n;
                    app.util.getUserInfo(function(e) {
                        a.setData({
                            userInfo: e,
                            noAuthorized: !1
                        });
                    });
                }
            }
        }));
    },
    onToggleTap: function(e) {
        var a = e.currentTarget.dataset;
        a.name;
        this.setData({
            isshow: !a.isshow
        });
    },
    send_link_msg: function() {}
});