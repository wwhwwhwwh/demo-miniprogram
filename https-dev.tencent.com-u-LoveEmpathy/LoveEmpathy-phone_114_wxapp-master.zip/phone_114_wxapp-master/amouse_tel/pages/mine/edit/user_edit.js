var app = getApp(), utils = require("../../../resource/utils/util.js");

Page({
    data: {
        _userInfo: {},
        userInfo: []
    },
    onLoad: function() {
        app.globalData.hasLogin ? this.setData({
            _userInfo: app.globalData.userInfo
        }) : app.util.getUserInfo(function(a) {
            app.globalData.hasLogin = !0, this.setData({
                _userInfo: a
            }), app.globalData.userInfo = a;
        });
    },
    onShow: function(a) {
        var e = this;
        app.util.request({
            url: "entry/wxapp/ApiGetUserInfo",
            data: {
                m: "amouse_wxapp_card"
            },
            method: "GET",
            success: function(a) {
                0 == a.data.errno && e.setData({
                    userInfo: a.data.data
                });
            },
            fail: function(a) {},
            complete: function() {
                wx.hideToast();
            }
        });
    },
    postUser: function(a) {
        var e = this, t = a.detail.value.mobile, s = a.detail.value.realname, o = a.detail.value.sex, n = a.detail.value.address, i = (a.detail.value.desc, 
        a.detail.value.uid);
        return t ? utils.regularPhoneNumber(t) ? void app.util.request({
            url: "entry/wxapp/ApiPostUser",
            data: {
                m: "amouse_tel",
                uid: i,
                realname: s,
                mobile: t,
                sex: o,
                address: n
            },
            method: "POST",
            success: function(a) {
                0 == a.data.errno ? wx.showModal({
                    title: "提示",
                    content: "资料更新成功",
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && wx.navigateBack({});
                    }
                }) : wx.showModal({
                    title: "提示",
                    content: a.data.message,
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && e.setData({
                            btn_disabled: !1,
                            submitIsLoading: !1
                        });
                    }
                });
            },
            fail: function(a) {
                wx.showModal({
                    title: "提示",
                    content: a.data.message,
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && e.setData({
                            btn_disabled: !1,
                            submitIsLoading: !1
                        });
                    }
                });
            },
            complete: function() {
                wx.hideToast();
            }
        }) : (wx.showModal({
            title: "提示",
            content: "手机号码格式不对",
            showCancel: !1,
            success: function(a) {
                a.confirm && console.log("用户点击确定");
            }
        }), !1) : (wx.showModal({
            title: "提示",
            content: "请填写您的手机号码",
            showCancel: !1,
            success: function(a) {
                a.confirm && console.log("用户点击确定");
            }
        }), !1);
    }
});