var _underscore = require("../../../resource/utils/underscore.js"), _underscore2 = _interopRequireDefault(_underscore), _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function t(t) {
    var a = [];
    for (var e in t) a.push(t[e]);
    return a;
}

var app = getApp();

Page({
    ad: {
        timerId: 0
    },
    data: {
        data: [],
        showFlag: !0,
        hasMore: !0,
        isLoading: !0,
        config: {},
        tels: app.globalData.tels,
        param: {
            type: -1
        },
        this_options: {},
        city: "未定位",
        isLocationSuccess: !1,
        open_entry: 0,
        location: {
            lat: 0,
            lng: 0
        },
        keyword: "",
        page: 0,
        this_keywords: ""
    },
    onLoad: function(t) {
        if (this.setData({
            this_options: t
        }), null != t.scene) {
            var a = decodeURIComponent(t.scene), e = [];
            -1 != a.indexOf(",") && (e = a.split(",")), -1 != a.indexOf("%2C") && (e = a.split("%2C")), 
            console.log(e);
            e[0];
            var i = e[1];
            wx.navigateTo({
                url: "/amouse_tel/pages/tel/detail/detail?id=" + i
            });
        }
        this.setData({
            page: 1
        }), app.setTabbar();
    },
    onShow: function() {
        var a = this;
        app.util.getUserInfo(function(t) {
            a.loadConfig(), a.get_location_init(), a.getTelList(1);
        });
    },
    loadConfig: function() {
        var i = this;
        _request2.default.get("ApiLoadConfig", {
            m: "amouse_tel"
        }).then(function(t) {
            var a = t;
            i.startAd(a), a.add_count = a && a.add_count ? a.add_count : 1e3, a.add_count = 1e4 <= a.add_count ? Math.floor(a.add_count / 100) / 100 + " 万" : a.add_count, 
            a.click_count = a && a.click_count ? a.click_count : 1e3, a.click_count = 1e4 <= a.click_count ? Math.floor(a.click_count / 100) / 100 + " 万" : a.click_count, 
            null != t.bgcolor && 2 < t.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: t.bgcolor,
                animation: {
                    timingFunc: "linear"
                }
            }), t.followurl && wx.setNavigationBarTitle({
                title: t.followurl
            }), wx.setStorageSync("config", a), app.globalData.sysinfo = t, app.globalData.claim_fee = t.claim_fee;
            var e = [];
            e.sharetitle = t.sharetitle, e.sharedesc = t.sharedesc, wx.setStorageSync("shareInfo", e), 
            i.setData({
                config: a,
                shareInfo: e,
                imgUrls: a.slides,
                public_credit: a.public_credit ? a.public_credit : 0,
                share_credit: a.share_credit ? a.share_credit : 0,
                icons: a.icons
            }), app.globalData.sysinfo = a, app.globalData.claim_fee = a.claim_fee;
        });
    },
    startAd: function(a) {
        var e = this;
        if (clearInterval(this.ad.timerId), a.notices && a.notices.length) {
            var i = 0, t = (void 0 === a.ad_interval || a.ad_interval, function() {
                var t = {};
                t.notice = a.notices[i].title, t.noticeid = a.notices[i].id, i = (t.notice_index = i) >= a.notices.length - 1 ? 0 : i + 1, 
                e.setData(t);
            });
            this.ad.timerId = setInterval(t, 3e3), t();
        }
    },
    onPullDownRefresh: function() {
        var t = this;
        t.data.param;
        if (0 == t.data.isLocationSuccess) return t.get_location_init(), !1;
        t.getTelList(1);
    },
    chang_this_keyword: function(t) {
        this.setData({
            this_keywords: t.detail.value
        });
    },
    search_index_data: function() {
        wx.navigateTo({
            url: "../list/list?keyword=" + this.data.this_keywords
        });
    },
    go_all_service_bind: function(t) {
        t.currentTarget.dataset.type;
        var a = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../list/list?cate_id=" + a + "&level=1"
        });
    },
    go_record_bind: function(t) {
        wx.navigateTo({
            url: "../myRecord/myRecord?type=" + t.currentTarget.dataset.type
        });
    },
    go_url_bind: function(t) {
        var a = t.currentTarget.dataset.url, e = t.currentTarget.dataset.jump, i = t.currentTarget.dataset.click, n = t.currentTarget.dataset.appid, o = t.currentTarget.dataset.cid, s = t.currentTarget.dataset.qrcode;
        2 == e && 0 == i && n ? wx.navigateToMiniProgram({
            appId: n,
            path: "",
            extraData: {
                foo: "bar"
            },
            envVersion: "develop",
            success: function(t) {}
        }) : 2 == e && 1 == i && s ? wx.previewImage({
            current: s,
            urls: [ s ]
        }) : 0 == e && a ? wx.navigateTo({
            url: a
        }) : a && wx.navigateTo({
            url: "../link/index?url=" + a + "&cid=" + o
        });
    },
    go_detail_bind: function(t) {
        wx.navigateTo({
            url: "../detail/detail?id=" + t.currentTarget.id
        });
    },
    onReachBottom: function() {
        this.setData({
            isLoading: !0
        });
        var t = this.data.page + 1;
        this.setData({
            page: t
        }), this.getTelList(t);
    },
    getTelList: function(i) {
        var n = this, e = n.data.param;
        e.m = "amouse_tel", e.pageIndex = i;
        var o = [];
        _request2.default.get("ApiQueryTelList", e).then(function(e) {
            e.list && 0 == e.list.length && "add" == i ? (wx.hideLoading(), a.toast.error("没有更多数据了")) : (o = 1 < i ? n.data.telList.concat(t(e.list)) : t(e.list) || [], 
            n.setData({
                telList: o,
                hasMore: !(e.list.length < n.data.limit),
                showLoading: !1
            }), wx.hideLoading());
        });
    },
    onSetData: function(t, a) {
        t = t || [];
        var e = this.data.data;
        0 != t.length && (0, _underscore2.default)(t).map(function(t) {
            return t;
        }), e = 1 == a ? t || [] : e.concat(t || []), this.setData({
            page: void 0 !== a ? a : this.data.page,
            data: e,
            hasMore: void 0 !== a && 20 <= t.length,
            isEmpty: (1 === a || void 0 === a) && 0 === t.length,
            isLoading: !1
        });
    },
    onSwtchTabTap: function(t) {
        var a = this, e = t.currentTarget.dataset.index, i = this.data.param;
        e != i.type && (0 == e && wx.getLocation({
            success: function(t) {
                i.type = e, i.lat = t.latitude, i.lng = t.longitude, a.setData({
                    showFlag: !0,
                    isLocationSuccess: !0,
                    param: i
                });
            },
            fail: function() {
                a.setData({
                    showFlag: !1
                });
            }
        }), i.type = e, this.setData({
            param: i,
            page: 0,
            data: []
        }), this.onPullDownRefresh());
    },
    onSetValueTap: function(t) {
        var a = t.currentTarget.dataset.value;
        this.setData(JSON.parse(a));
    },
    onEmptyTap: function() {},
    handlerUserLocation: function(t) {
        var i = this, n = i.data.param;
        t.detail.authSetting["scope.userLocation"] ? wx.getLocation({
            type: "gcj02",
            success: function(t) {
                var a = t.latitude, e = t.longitude;
                n.lat = t.latitude, n.lng = t.longitude, i.setData({
                    showFlag: !0,
                    param: n
                }), _request2.default.get("ApiGetCurrent", {
                    m: "amouse_tel",
                    lat: a,
                    lng: e
                }).then(function(t) {
                    i.setData({
                        city: t
                    });
                });
            }
        }) : i.setData({
            showFlag: !1
        });
    },
    startPullDownRefresh: function() {
        wx.getSystemInfoSync();
    },
    onNavigateTap: function(t) {
        var a = t.currentTarget.dataset, e = a.url, i = a.type, n = {
            url: e
        };
        a.invalid || ("switch" == i ? (n.fail = function() {
            wx.navigateTo({
                url: e
            });
        }, wx.switchTab(n)) : wx.navigateTo(n));
    },
    onCallTap: function(t) {
        var e = this, i = t.currentTarget.dataset, n = i.mobile, a = i.vip, o = i.iscall, s = i.isauth;
        n && (0 == a && 1 == o && 1 == s ? wx.showModal({
            title: "警告",
            content: "您拨打的电话没有认证，禁止拨打",
            showCancel: !1
        }) : wx.showModal({
            title: "温馨提示",
            content: "你将要拨打电话：" + n,
            success: function(t) {
                if (!t.cancel) {
                    wx.makePhoneCall({
                        phoneNumber: n
                    });
                    var a = {
                        id: i.id,
                        m: "amouse_tel",
                        type: 3
                    };
                    app.util.request({
                        url: "entry/wxapp/ApiSetCollect",
                        data: a,
                        showLoading: !1,
                        success: function(t) {
                            if (0 == t.data.errno) {
                                var a = t.data.data;
                                e.setData({
                                    collect: a
                                });
                            }
                        },
                        fail: function() {},
                        complete: function() {
                            e.setData({
                                isShowLoading: !1
                            });
                        }
                    });
                }
            }
        }));
    },
    onShareAppMessage: function(t) {
        "button" === t.from && console.log(t.target);
        var a = this.data.shareInfo || {};
        this.data.config.share_credit;
        return {
            title: a.sharetitle || "电话本",
            desc: a.sharedesc || "",
            path: "/amouse_tel/pages/tel/index/index",
            success: function(t) {
                app.util.request({
                    url: "entry/wxapp/ApiShare",
                    data: {
                        m: "amouse_tel",
                        type: "index"
                    },
                    showLoading: !1,
                    success: function(t) {
                        0 == t.data.errno && wx.showModal({
                            title: "温馨提示",
                            content: t.data.message,
                            showCancel: !1
                        });
                    },
                    fail: function(t) {
                        wx.showModal({
                            title: "温馨提示",
                            content: t.data.message,
                            showCancel: !1
                        });
                    },
                    complete: function(t) {}
                });
            },
            fail: function(t) {}
        };
    },
    get_location_init: function() {
        var i = this;
        wx.getLocation({
            type: "gcj02",
            success: function(t) {
                var a = t.latitude, e = t.longitude;
                i.setData({
                    isLocationSuccess: !0,
                    showFlag: !0,
                    param: {
                        type: i.data.param.type,
                        lat: a,
                        lng: e
                    }
                }), _request2.default.get("ApiGetCurrent", {
                    m: "amouse_tel",
                    lat: a,
                    lng: e
                }).then(function(t) {
                    i.setData({
                        city: t
                    });
                }), i.onPullDownRefresh();
            },
            fail: function(t) {
                i.setData({
                    showFlag: !1
                });
            }
        });
    },
    openLocation: function(t) {
        var a = t.currentTarget.dataset.index || 0, e = this.data.telList[a], i = e.lat, n = e.lng, o = e.place, s = e.title;
        console.log(t), wx.openLocation({
            latitude: parseFloat(i),
            longitude: parseFloat(n),
            address: o,
            name: s,
            scale: 28
        });
    },
    inputKeyword: function(t) {
        var a = t.detail.value;
        this.setData({
            keyword: a
        });
    },
    blurKeyword: function(t) {
        var a = "../list/list?keyword=" + this.data.keyword;
        wx.navigateTo({
            url: a
        });
    },
    view_platform_tap: function() {
        wx.navigateTo({
            url: "../info/info"
        });
    }
});