var app = getApp();

Page({
    data: {
        this_type_id: 1,
        this_tel_data: null
    },
    onLoad: function(t) {
        var a = this, e = 1;
        null == t.type || (e = t.type), a.setData({
            this_type_id: e
        }), a.get_index_data(), a.setData({
            bgcolor: app.globalData.sysinfo.bgcolor
        }), null != app.globalData.sysinfo.bgcolor && 2 < app.globalData.sysinfo.bgcolor.length && wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: app.globalData.sysinfo.bgcolor,
            animation: {
                duration: 400,
                timingFunc: "linear"
            }
        });
    },
    get_index_data: function() {
        var a = this;
        a.setData({
            collects: null
        }), app.util.request({
            url: "entry/wxapp/ApiGetMyCollect",
            data: {
                m: "amouse_tel",
                type_id: a.data.this_type_id
            },
            success: function(t) {
                0 == t.data.errno && a.setData({
                    collects: t.data.data
                });
            },
            fail: function() {},
            complete: function() {
                a.setData({
                    isShowLoading: !0
                });
            }
        });
    },
    change_this_type_bind: function(t) {
        this.setData({
            this_type_id: t.currentTarget.dataset.type
        }), this.get_index_data();
    },
    onPullDownRefresh: function() {
        this.onLoad(), setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1e3);
    },
    go_cate_list_bind: function(t) {
        var a = t.currentTarget.dataset.level, e = t.currentTarget.dataset.id;
        wx.redirectTo({
            url: "../telList/telList?cate_id=" + e + "&level=" + a
        });
    },
    go_detail_bind: function(t) {
        wx.navigateTo({
            url: "../detail/detail?id=" + t.currentTarget.id
        });
    },
    onCallTap: function(t) {
        var e = this, a = t.currentTarget.dataset, n = a.mobile, i = a.is_call, o = a.vip;
        if (n) {
            0 == o && 1 == i ? wx.showModal({
                title: "警告",
                content: "您拨打的电话没有认证，禁止拨打",
                showCancel: !1
            }) : wx.makePhoneCall({
                phoneNumber: n
            });
            var l = {
                id: a.id,
                m: "amouse_tel",
                type: 3
            };
            app.util.request({
                url: "entry/wxapp/ApiSetCollect",
                data: l,
                success: function(t) {
                    if (0 == t.data.errno) {
                        var a = t.data.data;
                        e.setData({
                            collect: a,
                            isShowLoading: !1
                        });
                    }
                },
                fail: function() {},
                complete: function() {
                    e.setData({
                        isShowLoading: !1
                    });
                }
            });
        }
    },
    openLocation: function(t) {
        wx.openLocation({
            latitude: parseFloat(t.currentTarget.dataset.lat),
            longitude: parseFloat(t.currentTarget.dataset.lng),
            address: t.currentTarget.dataset.address,
            name: t.currentTarget.dataset.name,
            scale: 28
        });
    },
    delete_data_bind: function(t) {
        var a = t.currentTarget.id, e = this;
        app.util.request({
            url: "entry/wxapp/ApiGetDelData",
            data: {
                m: "amouse_tel",
                collectid: a,
                type: e.data.this_type_id
            },
            success: function(t) {
                0 == t.data.errno && e.get_index_data();
            }
        });
    }
});