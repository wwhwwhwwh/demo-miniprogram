var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        keyColumn: 0,
        listColumn: 0,
        multiArray: [ [], [] ],
        multiIndex: [ -1, 0 ],
        coordinateArr: [],
        this_cate_one_id: 0,
        this_cate_two_id: 0,
        region: [ "城市", "城市", "请选择" ],
        index: 3,
        synSortArr: [ "附近发现", "最新入驻", "热门推荐", "认证商家" ],
        tel_list: null,
        pageIndex: 1,
        pageSize: 20,
        is_loadmore: !0,
        user_city: "",
        open_entry: 0,
        this_latitude_data: 0,
        this_longitude_data: 0,
        this_keywords: ""
    },
    chang_this_keyword: function(t) {
        this.setData({
            this_keywords: t.detail.value
        });
    },
    search_index_data: function() {
        this.setData({
            pageIndex: 1,
            pageSize: 20,
            is_loadmore: !0
        }), null != this.data.this_keywords && "" != this.data.this_keywords || wx.showModal({
            title: "提示",
            content: "请输入关键字",
            showCancel: !1,
            success: function(t) {
                return !1;
            }
        }), this.get_index_data();
    },
    get_user_location: function() {
        var a = this;
        wx.getLocation({
            type: "gcj02",
            success: function(t) {
                a.setData({
                    this_latitude_data: t.latitude,
                    this_longitude_data: t.longitude
                });
            },
            complete: function() {
                a.get_index_data();
            }
        });
    },
    go_detail_bind: function(t) {
        wx.navigateTo({
            url: "../detail/detail?id=" + t.currentTarget.id
        });
    },
    onLoad: function(t) {
        var s = this;
        (null != t.keyword && s.setData({
            this_keywords: t.keyword
        }), null != t.cate_id) ? (1 == t.level ? s.setData({
            this_cate_one_id: t.cate_id
        }) : s.setData({
            this_cate_two_id: t.cate_id
        }), 0 < t.cate_id && app.util.request({
            url: "entry/wxapp/ApiGetCategoryId",
            data: {
                m: "amouse_tel",
                id: t.cate_id
            },
            success: function(t) {
                0 == t.data.errno && (wx.setNavigationBarTitle({
                    title: t.data.data.title
                }), s.setData({
                    cid: t.data.data.id,
                    title: t.data.data.title
                }));
            },
            complete: function(t) {}
        })) : s.setData({
            this_cate_one_id: 0
        });
        var o = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        _request2.default.get("ApiLoadConfig", {}).then(function(t) {
            for (var a = t.enable, e = t.categorys, i = [], n = [], d = 0; d < e.length; d++) if (i.push(e[d].title), 
            null != e[d].childs && 0 == d) for (var l = 0; l < e[d].childs.length; l++) n.push(e[d].childs[l].title);
            o.multiArray[0] = i, o.multiArray[1] = n, s.setData(o), s.setData({
                open_entry: t.open_entry,
                enable: a,
                categoryArr: e,
                is_entry: t.is_entry
            }), null != t.bgcolor && 2 < t.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: t.bgcolor,
                animation: {
                    duration: 400,
                    timingFunc: "linear"
                }
            }), s.setData({
                config: t
            });
        }), s.get_user_location();
    },
    bindMultiPickerChange: function(t) {
        var a, e = t.detail.value, i = parseInt(e[0]) ? parseInt(e[0]) : 0, n = parseInt(e[1]) ? parseInt(e[1]) : 0, d = this.data.categoryArr, l = 0;
        a = d[i].id, null != d[i].childs && (l = d[i].childs[n].id), this.setData({
            multiIndex: t.detail.value,
            this_cate_one_id: a,
            this_cate_two_id: l
        }), this.get_index_data();
    },
    bindMultiPickerColumnChange: function(t) {
        var a = t.detail.column, e = t.detail.value, i = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        i.multiIndex[a] = e;
        var n = [];
        if (0 != a) return !1;
        var d = this.data.categoryArr;
        if (null != d[e].childs) for (var l = 0; l < d[e].childs.length; l++) n.push(d[e].childs[l].title);
        i.multiArray[1] = n, i.multiIndex[1] = 0, this.setData(i);
    },
    get_index_data: function() {
        var e = this, t = {};
        t.pageIndex = e.data.pageIndex, t.pageSize = e.data.pageSize, t.keyword = e.data.this_keywords, 
        t.one_cate_id = e.data.this_cate_one_id, t.two_cate_id = e.data.this_cate_two_id, 
        t.user_city = e.data.user_city, t.lng = e.data.this_longitude_data, t.lat = e.data.this_latitude_data, 
        t.city = e.data.region[2], t.type = e.data.index, t.m = "amouse_tel", app.util.request({
            url: "entry/wxapp/ApiQueryTelList",
            data: t,
            success: function(t) {
                if (0 == t.data.errno) {
                    var a = t.data.data.list;
                    null == a ? e.setData({
                        is_loadmore: !1
                    }) : a.length < 20 && e.setData({
                        is_loadmore: !1
                    }), e.setData({
                        tel_list: a
                    }), app.globalData.tels = a;
                }
            },
            complete: function(t) {
                e.setData({
                    isShowLoading: !0
                });
            }
        });
    },
    onReachBottom: function() {
        var i = this, t = {};
        t.pageIndex = i.data.pageIndex + 1, t.pageSize = i.data.pageSize, t.one_cate_id = i.data.this_cate_one_id, 
        t.two_cate_id = i.data.this_cate_two_id, t.user_city = i.data.user_city, t.lng = i.data.this_longitude_data, 
        t.lat = i.data.this_latitude_data, t.city = i.data.region[2], t.type = i.data.index, 
        t.m = "amouse_tel", app.util.request({
            url: "entry/wxapp/ApiQueryTelList",
            data: t,
            success: function(t) {
                if (0 == t.data.errno) {
                    var a = t.data.data.list;
                    if (null == a) i.setData({
                        is_loadmore: !1
                    }); else {
                        var e = i.data.tel_list;
                        e = e.concat(a), i.setData({
                            tel_list: e,
                            pageIndex: i.data.pageIndex + 1
                        });
                    }
                }
            },
            complete: function(t) {
                i.setData({
                    isShowLoading: !0
                });
            }
        });
    },
    onCallTap: function(t) {
        var e = this, a = t.currentTarget.dataset, i = a.mobile, n = a.vip, d = a.iscall, l = a.isauth;
        if (i) {
            0 == n && 1 == d && 1 == l ? wx.showModal({
                title: "警告",
                content: "您拨打的电话没有认证，禁止拨打",
                showCancel: !1
            }) : wx.makePhoneCall({
                phoneNumber: i
            });
            var s = {
                id: a.id,
                m: "amouse_tel",
                type: 3
            };
            app.util.request({
                url: "entry/wxapp/ApiSetCollect",
                data: s,
                success: function(t) {
                    if (0 == t.data.errno) {
                        var a = t.data.data;
                        e.setData({
                            collect: a
                        });
                    }
                },
                fail: function() {},
                complete: function() {
                    e.setData({
                        isShowLoading: !1
                    });
                }
            });
        }
    },
    onNavigateTap: function(t) {
        var a = t.currentTarget.dataset, e = a.url, i = a.type, n = {
            url: e
        };
        "switch" == i ? (n.fail = function() {
            wx.navigateTo({
                url: e
            });
        }, wx.switchTab(n)) : wx.navigateTo(n);
    },
    bindRegionChange: function(t) {
        var a = t.detail.value;
        this.setData({
            region: a
        }), this.get_index_data();
    },
    bindPickerChange: function(t) {
        console.log(t.detail.value), this.setData({
            index: t.detail.value,
            pageIndex: 0
        }), this.get_index_data();
    },
    openLocation: function(t) {
        wx.openLocation({
            latitude: parseFloat(t.currentTarget.dataset.lat),
            longitude: parseFloat(t.currentTarget.dataset.lng),
            address: t.currentTarget.dataset.address,
            name: t.currentTarget.dataset.name,
            scale: 28
        });
    }
});