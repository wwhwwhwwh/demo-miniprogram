var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request), _util = require("../../../resource/utils/util.js"), _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp(), WxParse = require("../../../resource/wxParse/wxParse.js");

Page({
    data: {
        this_tel_id: 0,
        collect: "",
        this_tel_info: null
    },
    onLoad: function(t) {
        var e = this, i = 0;
        if (null != t.scene) {
            var a = decodeURIComponent(t.scene);
            if (null != a) {
                var n = _util2.default.scene_decode(a);
                console.log("scene obj=>" + JSON.stringify(n)), n.m && n.tid && (i = n.tid);
            }
        }
        e.setData({
            this_tel_id: t.id || i
        }), e.load_detail_id(), _request2.default.get("ApiLoadConfig", {
            m: "amouse_tel"
        }).then(function(t) {
            null != t.bgcolor && 2 < t.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: t.bgcolor,
                animation: {
                    timingFunc: "linear"
                }
            }), e.setData({
                config: t,
                public_credit: t.public_credit ? t.public_credit : 0,
                share_credit: t.share_credit ? t.share_credit : 0
            }), app.globalData.sysinfo = t, app.globalData.claim_fee = t.claim_fee;
        });
    },
    go_cate_list_bind: function(t) {
        var e = t.currentTarget.dataset.level, i = t.currentTarget.dataset.id;
        wx.redirectTo({
            url: "../telList/telList?cate_id=" + i + "&level=" + e
        });
    },
    onShow: function() {},
    load_detail_id: function() {
        var i = this;
        0 < i.data.this_tel_id ? _request2.default.get("ApiTelInfo", {
            m: "amouse_tel",
            id: i.data.this_tel_id
        }).then(function(t) {
            var e = "商家全景";
            null != t.diy_txt && (e = t.diy_txt), t.info && WxParse.wxParse("content", "html", t.info, i), 
            i.setData({
                this_tel_info: t,
                isShowLoading: !0,
                collect: t.collect,
                diy_txt: e
            }), wx.setNavigationBarTitle({
                title: t.title
            });
        }) : wx.switchTab({
            url: "../index/index"
        });
    },
    go_index_bind: function() {
        wx.switchTab({
            url: "../index/index"
        });
    },
    onCallTap: function(t) {
        var i = this, e = {
            id: i.data.this_tel_info.id,
            m: "amouse_tel",
            type: 3
        }, a = t.currentTarget.dataset, n = a.mobile, l = a.vip, o = a.iscall, s = a.isauth;
        app.util.request({
            url: "entry/wxapp/ApiSetCollect",
            data: e,
            showLoading: !1,
            success: function(t) {
                if (0 == t.data.errno) {
                    var e = t.data.data;
                    i.setData({
                        collect: e
                    });
                }
            },
            fail: function() {},
            complete: function() {
                i.setData({
                    isShowLoading: !1
                });
            }
        }), n && (0 == l && 1 == o && 1 == s ? wx.showModal({
            title: "警告",
            content: "您拨打的电话没有认证，禁止拨打",
            showCancel: !1
        }) : wx.showModal({
            title: "温馨提示",
            content: "你将要拨打电话：" + n,
            success: function(t) {
                t.cancel || wx.makePhoneCall({
                    phoneNumber: n
                });
            }
        }));
    },
    openLocation: function(t) {
        wx.openLocation({
            latitude: parseFloat(this.data.this_tel_info.lat),
            longitude: parseFloat(this.data.this_tel_info.lng),
            address: this.data.this_tel_info.place,
            name: this.data.this_tel_info.title,
            scale: 28
        });
    },
    onShareAppMessage: function() {
        var i = this;
        return {
            title: i.data.this_tel_info.title || "",
            desc: "",
            path: "/amouse_tel/pages/tel/detail/detail?id=" + i.data.this_tel_id,
            success: function(t) {
                var e = {
                    m: "amouse_tel",
                    type: "detail",
                    id: i.data.this_tel_id
                };
                app.util.request({
                    url: "entry/wxapp/ApiShare",
                    data: e,
                    success: function(t) {
                        0 == t.data.errno && wx.showModal({
                            title: "提示",
                            content: t.data.message,
                            showCancel: !1
                        });
                    },
                    fail: function(t) {
                        wx.showModal({
                            title: "提示",
                            content: t.data.message,
                            showCancel: !1
                        });
                    }
                });
            }
        };
    },
    shoucang_bind: function(t) {
        var i = this;
        i.setData({
            collect: this.data.this_tel_info.collect
        });
        var e = {
            id: i.data.this_tel_id,
            m: "amouse_tel",
            type: 1
        };
        app.util.request({
            url: "entry/wxapp/ApiSetCollect",
            data: e,
            success: function(t) {
                if (0 == t.data.errno) {
                    var e = t.data.data;
                    i.setData({
                        collect: e
                    });
                }
            },
            fail: function() {},
            complete: function() {
                i.setData({
                    isShowLoading: !1
                });
            }
        });
    },
    corrent_bind: function() {
        wx.navigateTo({
            url: "../corrent/corrent?id=" + this.data.this_tel_id
        });
    },
    go_url_bind: function(t) {
        wx.reLaunch({
            url: "../link/index?url=" + t.currentTarget.dataset.url
        });
    },
    img_max_bind: function(t) {
        wx.previewImage({
            current: this.data.this_tel_info.imgs[0],
            urls: this.data.this_tel_info.imgs
        });
    },
    videoPlay: function(t) {
        wx.setNavigationBarTitle({
            title: "视频加载中..."
        });
    },
    img_max_bind2: function(t) {
        wx.previewImage({
            current: this.data.this_tel_info.qrcode,
            urls: [ this.data.this_tel_info.qrcode ]
        });
    },
    onNavigateTap: function(t) {
        var e = t.currentTarget.dataset, i = e.url, a = e.type, n = {
            url: i
        };
        e.invalid || ("switch" == a ? (n.fail = function() {
            wx.navigateTo({
                url: i
            });
        }, wx.switchTab(n)) : wx.navigateTo(n));
    },
    on_fuzhi_bind: function() {
        wx.setClipboardData({
            data: this.data.this_tel_info.weixin,
            success: function(t) {
                wx.showToast({
                    title: "复制成功",
                    icon: "success",
                    duration: 2e3
                });
            }
        });
    }
});