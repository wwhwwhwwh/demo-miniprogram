var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var app = getApp(), WxParse = require("../../../resource/wxParse/wxParse.js");

Page({
    data: {
        userInfo: {}
    },
    onLoad: function(e) {
        var r = this;
        _request2.default.get("ApiLoadConfig", {
            m: "amouse_tel"
        }).then(function(e) {
            e.info && WxParse.wxParse("content", "html", e.info, r), null != e.bgcolor && 2 < e.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: e.bgcolor,
                animation: {
                    duration: 400,
                    timingFunc: "linear"
                }
            });
            var t = [];
            t.sharetitle = e.sharetitle, t.sharedesc = e.sharedesc, r.setData({
                config: e,
                shareInfo: t
            });
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.shareInfo.sharetitle || "微发布",
            path: "amouse_tel/pages/tel/info/info"
        };
    }
});