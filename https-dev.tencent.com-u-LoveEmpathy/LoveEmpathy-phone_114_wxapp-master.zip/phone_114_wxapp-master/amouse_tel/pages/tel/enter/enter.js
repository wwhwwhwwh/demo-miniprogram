var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        durIndex: 0,
        catIndex: 0,
        coorIndex: 0,
        rules: [],
        public_price: 0,
        day: 0,
        enable: 0,
        is_free: 0,
        total_amount: 0,
        is_top: 0,
        is_auth: 1,
        categoryArr: {},
        multiArray: [ [], [] ],
        multiIndex: [ -1, 0 ],
        coordinateArr: [],
        this_cate_one_id: 0,
        this_cate_two_id: 0,
        this_t_img: null,
        this_t_lng: 0,
        this_t_lat: 0,
        this_t_address: "",
        this_tel_config: null,
        this_check_str: "提交审核",
        img_count_limit: 6,
        this_img_i: 0,
        this_img_max: 0,
        imageList: [],
        img_index: 0,
        image_list1: [],
        uploadimgArr: []
    },
    onLoad: function(t) {
        var a = this;
        app.util.getUserInfo(function(t) {
            app.setTabbar(), a.getSysinfo();
        });
    },
    getSysinfo: function() {
        var m = this, p = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        _request2.default.get("ApiLoadConfig", {}).then(function(t) {
            for (var a = t.enable ? t.enable : 0, e = t.categorys, i = [], s = [], n = "提交审核", o = 0; o < e.length; o++) if (i.push(e[o].title), 
            null != e[o].childs && 0 == o) for (var l = 0; l < e[o].childs.length; l++) s.push(e[o].childs[l].title);
            p.multiArray[0] = i, p.multiArray[1] = s;
            var d = "VR链接";
            null != t.diy_txt && (d = t.diy_txt), m.setData(p), n = 1 == t.isopen ? "提交审核" : "提交入驻";
            var r = t.rules, u = 0, c = 0;
            if (0 == t.is_entry && 1 == m.data.is_top) {
                if (r.length) {
                    var h = r[0].amount;
                    c = parseFloat(h);
                }
                u = c;
            }
            0 < t.fee && (u += parseFloat(t.fee)), m.setData({
                public_price: t.fee ? t.fee : 0,
                day: t.day ? t.day : 0,
                is_free: t.free ? t.free : 0,
                enable: a,
                diy_txt: d,
                total_amount: u,
                categoryArr: e,
                top_amount: c,
                rules: t.rules,
                config: t,
                is_call: t.is_call ? t.is_call : 0,
                is_entry: t.is_entry ? t.is_entry : 0,
                this_check_str: n
            }), null != t.bgcolor && 2 < t.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: t.bgcolor,
                animation: {
                    duration: 400,
                    timingFunc: "linear"
                }
            });
        });
    },
    selectDuration: function(t) {
        var a = this;
        a.setData({
            durIndex: t.detail.value
        });
        var e = a.data.rules, i = parseInt(t.detail.value);
        0 != e.length && (a.setData({
            top_day: e[i].day,
            top_amount: parseFloat(e[i].amount)
        }), 0 < a.data.public_price ? a.setData({
            total_amount: parseFloat(e[i].amount) + parseFloat(this.data.public_price)
        }) : a.setData({
            total_amount: parseFloat(e[i].amount)
        }));
    },
    onIsTopChange: function(t) {
        var a = this, e = a.data.public_price, i = 0;
        t.detail.value && 1 == a.data.is_auth && 0 < a.data.rules.length ? i = parseFloat(a.data.rules[0].amount) + parseFloat(e) : 1 == a.data.is_auth && (i = e), 
        a.setData({
            is_top: t.detail.value ? 1 : 0,
            total_amount: i
        });
    },
    bindMultiPickerChange: function(t) {
        var a, e = t.detail.value, i = parseInt(e[0]) ? parseInt(e[0]) : 0, s = parseInt(e[1]) ? parseInt(e[1]) : 0, n = this.data.categoryArr, o = 0;
        a = n[i].id, 0 < n[i].childs.length && (o = n[i].childs[s].id), this.setData({
            multiIndex: t.detail.value,
            this_cate_one_id: a,
            this_cate_two_id: o
        });
    },
    bindMultiPickerColumnChange: function(t) {
        var a = t.detail.column, e = t.detail.value, i = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        i.multiIndex[a] = e;
        var s = [];
        if (0 != a) return !1;
        var n = this.data.categoryArr;
        if (null != n && 0 < n.length && null != n[e].childs) for (var o = 0; o < n[e].childs.length; o++) s.push(n[e].childs[o].title);
        i.multiArray[1] = s, i.multiIndex[1] = 0, this.setData(i);
    },
    selectCoordinate: function(t) {
        this.setData({
            coorIndex: t.detail.value
        });
    },
    chooseimg_bind: function() {
        var a = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                a.setData({
                    this_t_img: t.tempFilePaths
                }), a.uploadSingle(a, t.tempFilePaths);
            }
        });
    },
    chooseVideo: function(t) {
        var a = this;
        wx.chooseVideo({
            sourceType: [ "album", "camera" ],
            maxDuration: 60,
            camera: "back",
            success: function(t) {
                a.setData({
                    videoSrc: t.tempFilePath
                });
            }
        });
    },
    uploadSingle: function(e, t) {
        var a = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: a + "m=amouse_tel&type=1",
            filePath: t[0],
            name: "file",
            success: function(t) {
                var a = t.data;
                "string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno ? e.setData({
                    logo: a.data
                }) : e.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                e.setData({
                    hidden: !0
                });
            }
        });
    },
    uploadImg: function(s, n) {
        s.setData({
            hidden: !1
        });
        var t = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: t + "m=amouse_tel&type=1",
            filePath: n,
            name: "file",
            success: function(t) {
                var a = t.data;
                if ("string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno) {
                    var e = new Array(), i = new Array();
                    (i = s.data.uploadimgArr).push(a.data), (e = s.data.imageList).push(n), s.setData({
                        uploadimgArr: i,
                        imageList: e
                    }), s.data.img_index = s.data.img_index + 1, s.data.img_index < s.data.image_list1.length ? s.uploadImg(s, "" + s.data.image_list1[s.data.img_index]) : s.setData({
                        hidden: !0
                    });
                } else s.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                s.setData({
                    hidden: !0
                });
            }
        });
    },
    choose_t_map: function(t) {
        var a = this;
        wx.chooseLocation({
            success: function(t) {
                console.log(t), a.setData({
                    this_t_lat: t.latitude,
                    this_t_lng: t.longitude,
                    this_t_address: t.address
                });
            },
            error: function(t) {
                a.showModalTips("请允许地理位置授权");
            }
        });
    },
    post_tel_formSubmit: function(t) {
        var a = this, e = t.detail.value, i = t.detail.formId;
        e.formid = i;
        var s = t.detail.target.dataset.free;
        if (e.isfree = s, null == a.data.logo || a.data.logo, a.data.this_cate_one_id, a.setData({
            submitIsLoading: !0,
            buttonIsDisabled: !0
        }), e.cid = a.data.this_cate_one_id, e.ccateid = a.data.this_cate_two_id, !e.title) return wx.showModal({
            title: "提示",
            content: "商家名称不能为空",
            showCancel: !1
        }), void a.setData({
            submitIsLoading: !1,
            buttonIsDisabled: !1
        });
        if (!e.contact_name) return wx.showModal({
            title: "提示",
            content: "商家联系人不能为空",
            showCancel: !1
        }), void a.setData({
            submitIsLoading: !1,
            buttonIsDisabled: !1
        });
        if (!e.mobile) return wx.showModal({
            title: "提示",
            content: "商家联系电话不能为空",
            showCancel: !1
        }), void a.setData({
            submitIsLoading: !1,
            buttonIsDisabled: !1
        });
        if (1 == a.data.enable ? e.place = t.detail.value.address : 0 == a.data.enable && (e.lng = a.data.this_t_lng, 
        e.lat = a.data.this_t_lat, e.place = a.data.this_t_address), !e.place) return wx.showModal({
            title: "提示",
            content: "商家地址不能为空",
            showCancel: !1
        }), void a.setData({
            submitIsLoading: !1,
            buttonIsDisabled: !1
        });
        if (e.pay_money = a.data.total_amount, e.is_top = a.data.is_top, e.is_auth = a.data.is_auth, 
        e.public_price = a.data.public_price, 0 < a.data.rules.length && 0 == a.data.is_entry && (e.pay_day = a.data.rules ? a.data.rules[a.data.durIndex].day : 0), 
        1 <= a.data.imageList.length) {
            var n = a.data.uploadimgArr;
            n = n.join("|"), e.imagesList = n;
        }
        e.logo = a.data.logo, e.m = "amouse_tel", wx.showToast({
            title: "提交中...",
            icon: "loading",
            duration: 1e4
        }), app.util.request({
            url: "entry/wxapp/ApiPostInfo",
            data: e,
            method: "POST",
            success: function(t) {
                0 == t.data.errno ? (a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                }), a.data.videoSrc && a.uploadVideo(a, a.data.videoSrc, t.data.data.telid), 0 < a.data.total_amount && 1 == s ? a.onPayment(t.data.data) : wx.showModal({
                    title: "发布成功",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        wx.switchTab({
                            url: "../../tel/index/index",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/index/index"
                                });
                            }
                        });
                    }
                })) : wx.showModal({
                    title: "提示",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && console.log("用户点击确定");
                    }
                });
            },
            fail: function(t) {
                wx.hideToast(), wx.showModal({
                    title: "提示",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && console.log("用户点击确定");
                    }
                }), a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                });
            },
            complete: function() {
                wx.hideToast(), a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                });
            }
        });
    },
    onPayment: function(t) {
        wx.requestPayment({
            timeStamp: t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.paySign,
            success: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款成功",
                    showCancel: !1,
                    success: function(t) {
                        wx.showToast({
                            title: "已支付成功...",
                            icon: "success"
                        }), wx.switchTab({
                            url: "../../tel/index/index"
                        });
                    }
                });
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "支付失败",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && wx.switchTab({
                            url: "../../tel/index/index",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/index/index"
                                });
                            }
                        });
                    }
                });
            }
        }), this.setData({
            isShowLoading: !0,
            buttonIsDisabled: !0
        });
    },
    uploadVideo: function(e, t, a) {
        var i = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: i + "m=amouse_tel&type=0&telid=" + a,
            filePath: t,
            name: "file",
            success: function(t) {
                var a = t.data;
                "string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno || e.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                e.setData({
                    hidden: !0
                });
            }
        });
    },
    showModalTips: function(t) {
        var a = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: a,
            success: function(t) {
                return !1;
            }
        });
    },
    onPullDownRefresh: function() {
        this.onLoad(), setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1e3);
    },
    onDeleteImage: function(t) {
        var a = t.currentTarget.dataset.index;
        this.data.uploadimgArr.splice(a, 1), this.setData({
            imageList: this.data.uploadimgArr
        });
    },
    chooseimg_bind_all: function() {
        var e = this;
        e.data.imageList.length < 9 ? wx.chooseImage({
            count: 9 - e.data.imageList.length,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                e.data.image_list1 = new Array();
                for (var a = 0; a < t.tempFilePaths.length; a++) e.data.image_list1.push(t.tempFilePaths[a]);
                e.uploadImg(e, "" + e.data.image_list1[0]);
            },
            fail: function() {
                wx.showToast({
                    title: "选取失败",
                    icon: "success",
                    duration: 2e3
                });
            }
        }) : wx.showToast({
            title: "当前最多只能选择9张图片",
            icon: "success",
            duration: 2e3
        });
    }
});