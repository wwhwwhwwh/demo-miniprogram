var _util = require("../../../resource/utils/util.js"), _util2 = _interopRequireDefault(_util), _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        this_tel_id: 0,
        this_check_str: "提交审核",
        this_tel_info: null
    },
    onLoad: function(t) {
        var a = this;
        app.util.getUserInfo(function(t) {
            app.globalData.hasLogin = !0, a.setData({
                userInfo: t
            }), app.globalData.userInfo = t;
        }), a.setData({
            claim_fee: app.globalData.claim_fee,
            config: app.globalData.sysinfo
        }), null != app.globalData.sysinfo.bgcolor && 2 < app.globalData.sysinfo.bgcolor.length && wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: app.globalData.sysinfo.bgcolor,
            animation: {
                duration: 400,
                timingFunc: "linear"
            }
        }), null != t.id ? a.setData({
            this_tel_id: t.id
        }) : a.setData({
            this_tel_id: 0
        }), a.get_detail_data();
    },
    get_detail_data: function() {
        var a = this;
        _request2.default.get("ApiTelInfo", {
            m: "amouse_tel",
            id: a.data.this_tel_id
        }).then(function(t) {
            a.setData({
                this_tel_info: t
            }), wx.setNavigationBarTitle({
                title: t.title
            });
        });
    },
    onAuthenticationChange: function(t) {
        var a = 0;
        t.detail.value && (a = parseFloat(this.data.claim_fee)), this.setData({
            is_auth: t.detail.value ? 1 : 0,
            total_amount: a
        });
    },
    post_tel_formSubmit: function(t) {
        var a = this, e = t.detail.formId;
        a.setData({
            submitIsLoading: !0,
            buttonIsDisabled: !0
        });
        var i = t.detail.value;
        if ("" == i.contact_mobile || null == i.contact_mobile) return a.showToastError("联系电话不能为空！"), 
        a.setData({
            submitIsLoading: !1,
            buttonIsDisabled: !1
        }), !1;
        i.formid = e, i.telid = a.data.this_tel_id, i.pay_money = a.data.claim_fee, i.m = "amouse_tel", 
        wx.showToast({
            title: "提交中...",
            icon: "loading",
            duration: 1e4
        }), app.util.request({
            url: "entry/wxapp/ApiPostCorrectInfo",
            data: i,
            method: "POST",
            success: function(t) {
                0 == t.data.errno ? (a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                }), 0 < a.data.claim_fee ? a.onPayment(t.data.data) : wx.showModal({
                    title: "纠错提交成功",
                    content: "纠错提交成功，请等待管理员审核",
                    showCancel: !1,
                    success: function(t) {
                        wx.switchTab({
                            url: "../../tel/detail/detail?id=" + a.data.this_tel_id,
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/detail/detail?id=" + a.data.this_tel_id
                                });
                            }
                        });
                    }
                })) : wx.showModal({
                    title: "提示",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && console.log("用户点击确定");
                    }
                });
            },
            fail: function(t) {},
            complete: function() {
                wx.hideToast(), a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                });
            }
        });
    },
    onPayment: function(t) {
        wx.requestPayment({
            timeStamp: t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.paySign,
            success: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款成功",
                    showCancel: !1,
                    success: function(t) {
                        wx.showToast({
                            title: "已支付成功...",
                            icon: "success"
                        }), wx.switchTab({
                            url: "../../tel/index/index"
                        });
                    }
                });
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款失败",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && wx.switchTab({
                            url: "../../tel/index/index",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/index/index"
                                });
                            }
                        });
                    }
                });
            }
        }), this.setData({
            isShowLoading: !0,
            buttonIsDisabled: !0
        });
    },
    showModalTips: function(t) {
        var a = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: a,
            success: function(t) {
                return !1;
            }
        });
    },
    showToastError: function(t) {
        wx.showToast({
            title: t,
            icon: "loading",
            duration: 1e3,
            mask: !0
        });
    },
    onNavigateTap: function(t) {
        var a = t.currentTarget.dataset, e = a.url, i = a.type, o = {
            url: e
        };
        a.invalid || ("switch" == i ? (o.fail = function() {
            wx.navigateTo({
                url: e
            });
        }, wx.switchTab(o)) : wx.navigateTo(o));
    }
});