var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var app = getApp();

Page({
    data: {},
    onLoad: function(e) {
        var t = this;
        null != e.cid ? _request2.default.get("ApiGetSlide", {
            m: "amouse_tel",
            id: e.cid
        }).then(function(e) {
            t.setData({
                url: e.followurl
            });
        }) : wx.navigateBack({
            delta: -1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {}
});