var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        var a = this;
        a.setData({
            list: [],
            is_call: app.globalData.sysinfo.is_call
        }), app.util.getUserInfo(function(t) {
            app.globalData.hasLogin = !0, a.setData({
                userInfo: t
            }), app.globalData.userInfo = t;
        }), _request2.default.get("ApiGetMyFabu", {}).then(function(t) {
            a.setData({
                list: t
            });
        }), null != app.globalData.sysinfo.bgcolor && 2 < app.globalData.sysinfo.bgcolor.length && wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: app.globalData.sysinfo.bgcolor,
            animation: {
                duration: 400,
                timingFunc: "linear"
            }
        });
    },
    onReady: function() {},
    onNavigateTap: function(t) {
        wx.navigateTo({
            url: "../enter/enter",
            fail: function() {
                wx.switchTab({
                    url: "../enter/enter"
                });
            }
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    go_detail_bind: function(t) {
        wx.navigateTo({
            url: "../edit/edit?id=" + t.currentTarget.id
        });
    },
    selectDuration: function(t) {
        var a = this;
        a.setData({
            durIndex: t.detail.value
        });
        var n = a.data.rules, e = parseInt(t.detail.value);
        0 != n.length && (a.setData({
            top_day: n[e].day,
            top_amount: parseFloat(n[e].amount)
        }), 0 < a.data.public_price ? a.setData({
            total_amount: parseFloat(n[e].amount) + parseFloat(this.data.public_price)
        }) : a.setData({
            total_amount: parseFloat(n[e].amount)
        }));
    },
    go_to_pay: function(t) {
        var a = this;
        app.util.request({
            url: "entry/wxapp/ApiPostPay",
            data: {
                m: "amouse_tel",
                id: t.currentTarget.id
            },
            method: "POST",
            success: function(t) {
                0 == t.data.errno && (a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                }), 0 < t.data.data.fee ? a.onPayment(t.data.data) : wx.showModal({
                    title: "认证",
                    showCancel: !1,
                    success: function(t) {
                        wx.switchTab({
                            url: "myEnter",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "myEnter"
                                });
                            }
                        });
                    }
                }));
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款出错了",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && console.log("用户点击确定");
                    }
                });
            },
            complete: function() {
                wx.hideToast(), a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                });
            }
        });
    },
    onPayment: function(t) {
        wx.requestPayment({
            timeStamp: t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.paySign,
            success: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款成功",
                    showCancel: !1,
                    success: function(t) {
                        wx.showToast({
                            title: "已支付成功...",
                            icon: "success"
                        }), wx.switchTab({
                            url: "myEnter"
                        });
                    }
                });
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款失败",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && wx.switchTab({
                            url: "myEnter",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "myEnter"
                                });
                            }
                        });
                    }
                });
            }
        }), this.setData({
            isShowLoading: !0,
            buttonIsDisabled: !0
        });
    }
});