var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var app = getApp();

Page({
    data: {
        categoryArr: null
    },
    onLoad: function() {
        var t = this;
        _request2.default.get("ApiGetCategory", {}).then(function(e) {
            t.setData({
                categoryArr: e
            });
        }), _request2.default.get("ApiLoadConfig", {}).then(function(e) {
            t.setData({
                config: e
            }), null != e.bgcolor && 2 < e.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: e.bgcolor,
                animation: {
                    duration: 400,
                    timingFunc: "linear"
                }
            });
        }), app.setTabbar();
    },
    onPullDownRefresh: function() {
        this.onLoad(), setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1e3);
    },
    go_index_bind: function() {
        wx.switchTab({
            url: "../index/index"
        });
    },
    go_cate_list_bind: function(e) {
        var t = e.currentTarget.dataset.level, n = e.currentTarget.dataset.id;
        wx.navigateTo({
            url: "../list/list?cate_id=" + n + "&level=" + t
        });
    }
});