var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        durIndex: 0,
        catIndex: 0,
        coorIndex: 0,
        rules: [],
        enable: 0,
        categoryArr: {},
        multiArray: [ [], [] ],
        multiIndex: [ -1, 0 ],
        coordinateArr: [],
        this_cate_one_id: 0,
        this_cate_two_id: 0,
        this_t_img: null,
        this_t_lng: 0,
        this_t_lat: 0,
        this_t_address: "",
        this_tel_config: null,
        this_check_str: "编辑审核",
        img_count_limit: 9,
        this_img_i: 0,
        this_img_max: 0,
        imageList: [],
        img_index: 0,
        image_list1: [],
        uploadimgArr: []
    },
    onLoad: function(t) {
        var a = this, e = 0;
        null == t.id || (e = t.id), a.setData({
            edit_id: e
        }), 0 < e && app.util.request({
            url: "entry/wxapp/ApiEditTelInfo",
            data: {
                m: "amouse_tel",
                id: e
            },
            success: function(t) {
                0 == t.data.errno && a.setData({
                    this_t_img: t.data.data.logo,
                    logo: t.data.data.logo,
                    this_t_address: t.data.data.place,
                    imageList: t.data.data.imgs,
                    uploadimgArr: t.data.data.imgs,
                    this_cate_one_id: t.data.data.cid,
                    this_cate_two_id: t.data.data.ccateid,
                    cate_title: t.data.data.cate_title,
                    this_t_lng: t.data.data.lng,
                    this_t_lat: t.data.data.lat,
                    scate_title: t.data.data.scate_title,
                    info: t.data.data
                });
            }
        });
    },
    onShow: function() {
        var d = this;
        app.util.getUserInfo(function(t) {
            app.globalData.hasLogin = !0, d.setData({
                userInfo: t
            }), app.globalData.userInfo = t;
        });
        var r = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        app.util.request({
            url: "entry/wxapp/ApiLoadConfig",
            data: {
                m: "amouse_tel"
            },
            success: function(t) {
                if (0 == t.data.errno) {
                    for (var a = t.data.data.enable, e = t.data.data.categorys, i = [], s = [], n = "提交审核", o = 0; o < e.length; o++) if (i.push(e[o].title), 
                    null != e[o].childs && 0 == o) for (var l = 0; l < e[o].childs.length; l++) s.push(e[o].childs[l].title);
                    r.multiArray[0] = i, r.multiArray[1] = s, d.setData(r), n = 1 == t.data.data.isopen ? "提交审核" : "提交入驻", 
                    d.setData({
                        enable: a,
                        categoryArr: e,
                        rules: t.data.data.rules,
                        is_entry: t.data.data.is_entry,
                        this_check_str: n
                    });
                }
            }
        });
    },
    bindMultiPickerChange: function(t) {
        var a, e = t.detail.value, i = parseInt(e[0]) ? parseInt(e[0]) : 0, s = parseInt(e[1]) ? parseInt(e[1]) : 0, n = this.data.categoryArr, o = 0;
        a = n[i].id, null != n[i].childs && (o = n[i].childs[s].id), this.setData({
            multiIndex: t.detail.value,
            this_cate_one_id: a,
            this_cate_two_id: o
        });
    },
    bindMultiPickerColumnChange: function(t) {
        var a = t.detail.column, e = t.detail.value, i = {
            multiArray: this.data.multiArray,
            multiIndex: this.data.multiIndex
        };
        i.multiIndex[a] = e;
        var s = [];
        if (0 != a) return !1;
        var n = this.data.categoryArr;
        if (null != n[e].childs) for (var o = 0; o < n[e].childs.length; o++) s.push(n[e].childs[o].title);
        i.multiArray[1] = s, i.multiIndex[1] = 0, this.setData(i);
    },
    selectCoordinate: function(t) {
        this.setData({
            coorIndex: t.detail.value
        });
    },
    chooseimg_logo_bind: function() {
        var a = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                a.setData({
                    this_t_img: t.tempFilePaths
                }), a.uploadSingle(a, t.tempFilePaths);
            }
        });
    },
    uploadSingle: function(e, t) {
        var a = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: a + "m=amouse_tel",
            filePath: t[0],
            name: "file",
            success: function(t) {
                var a = t.data;
                "string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno ? e.setData({
                    logo: a.data
                }) : e.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                e.setData({
                    hidden: !0
                });
            }
        });
    },
    uploadImg: function(s, n) {
        s.setData({
            hidden: !1
        });
        var t = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: t + "m=amouse_tel",
            filePath: n,
            name: "file",
            success: function(t) {
                var a = t.data;
                if ("string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno) {
                    var e = new Array(), i = new Array();
                    (i = s.data.uploadimgArr).push(a.data), (e = s.data.imageList).push(n), s.setData({
                        uploadimgArr: i,
                        imageList: e
                    }), s.data.img_index = s.data.img_index + 1, s.data.img_index < s.data.image_list1.length ? s.uploadImg(s, "" + s.data.image_list1[s.data.img_index]) : s.setData({
                        hidden: !0
                    });
                } else s.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                s.setData({
                    hidden: !0
                });
            }
        });
    },
    choose_t_map: function(t) {
        var a = this;
        wx.chooseLocation({
            success: function(t) {
                console.log(t), a.setData({
                    this_t_lat: t.latitude,
                    this_t_lng: t.longitude,
                    this_t_address: t.address
                });
            },
            error: function(t) {
                a.showModalTips("请允许地理位置授权");
            }
        });
    },
    post_tel_formSubmit: function(t) {
        var a = this;
        if (null == a.data.logo || a.data.logo, 0 == a.data.this_cate_one_id) return a.showModalTips("请选择分类"), 
        !1;
        a.setData({
            submitIsLoading: !0,
            buttonIsDisabled: !0
        });
        var e = t.detail.value, i = t.detail.formId;
        if (e.formid = i, console.log("==formid==" + i), e.cid = a.data.this_cate_one_id, 
        e.ccateid = a.data.this_cate_two_id, 1 == a.data.enable ? e.place = t.detail.value.address : 0 == a.data.enable && (e.lng = a.data.this_t_lng, 
        e.lat = a.data.this_t_lat, e.place = a.data.this_t_address), 1 <= a.data.imageList.length) {
            var s = a.data.uploadimgArr;
            s = s.join("|"), e.imagesList = s;
        }
        e.logo = a.data.logo, e.m = "amouse_tel", e.id = a.data.edit_id, wx.showToast({
            title: "提交中...",
            icon: "loading",
            duration: 1e4
        }), app.util.request({
            url: "entry/wxapp/ApiUpdatePostInfo",
            data: e,
            method: "POST",
            success: function(t) {
                0 == t.data.errno ? (a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                }), wx.showModal({
                    title: "发布成功",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        wx.switchTab({
                            url: "../../tel/fabu/myEnter",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/fabu/myEnter"
                                });
                            }
                        });
                    }
                })) : (console.log(t), wx.switchTab({
                    url: "../../tel/fabu/myEnter",
                    fail: function(t) {
                        wx.redirectTo({
                            url: "../../tel/fabu/myEnter"
                        });
                    }
                }));
            },
            fail: function(t) {
                console.log(t), wx.switchTab({
                    url: "../../tel/fabu/myEnter",
                    fail: function(t) {
                        wx.redirectTo({
                            url: "../../tel/fabu/myEnter"
                        });
                    }
                });
            },
            complete: function() {
                a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                });
            }
        });
    },
    onPayment: function(t) {
        wx.requestPayment({
            timeStamp: t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.paySign,
            success: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款成功",
                    showCancel: !1,
                    success: function(t) {
                        wx.showToast({
                            title: "已支付成功...",
                            icon: "success"
                        }), wx.switchTab({
                            url: "../../tel/index/index"
                        });
                    }
                });
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款失败",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && wx.switchTab({
                            url: "../../tel/index/index",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/index/index"
                                });
                            }
                        });
                    }
                });
            }
        }), this.setData({
            isShowLoading: !0,
            buttonIsDisabled: !0
        });
    },
    showModalTips: function(t) {
        var a = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: a,
            success: function(t) {
                return !1;
            }
        });
    },
    onPullDownRefresh: function() {
        this.onLoad(), setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1e3);
    },
    onDeleteImage: function(t) {
        var a = t.currentTarget.dataset.index;
        this.data.uploadimgArr.splice(a, 1), this.setData({
            imageList: this.data.uploadimgArr
        });
    },
    chooseimg_bind_all: function() {
        var e = this;
        e.data.imageList.length < 9 ? wx.chooseImage({
            count: 9 - e.data.imageList.length,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                e.data.image_list1 = new Array();
                for (var a = 0; a < t.tempFilePaths.length; a++) e.data.image_list1.push(t.tempFilePaths[a]);
                e.uploadImg(e, "" + e.data.image_list1[0]);
            },
            fail: function() {
                wx.showToast({
                    title: "选取失败",
                    icon: "success",
                    duration: 2e3
                });
            }
        }) : wx.showToast({
            title: "当前最多只能选择9张图片",
            icon: "success",
            duration: 2e3
        });
    }
});