var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        is_auth: 0,
        this_tel_config: null,
        this_check_str: "提交审核",
        img_count_limit: 6,
        this_img_i: 0,
        this_img_max: 0,
        imageList: [],
        img_index: 0,
        image_list1: [],
        uploadimgArr: []
    },
    onLoad: function(t) {
        var i = this;
        app.util.getUserInfo(function(t) {
            app.globalData.hasLogin = !0, i.setData({
                userInfo: t
            }), app.globalData.userInfo = t;
        }), _request2.default.get("ApiLoadConfig", {}).then(function(t) {
            t.enable;
            var a = "提交审核";
            a = 1 == t.isopen ? "提交审核" : "提交入驻";
            var e = 0;
            0 < t.adv_fee && (e = parseFloat(t.adv_fee)), i.setData({
                adv_fee: t.fee,
                adv_day: t.adv_day,
                total_amount: e,
                config: t,
                this_check_str: a
            }), null != t.bgcolor && 2 < t.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: app.globalData.sysinfo.bgcolor,
                animation: {
                    duration: 400,
                    timingFunc: "linear"
                }
            });
        });
    },
    chooseimg_bind: function() {
        var a = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                a.setData({
                    this_t_img: t.tempFilePaths
                }), a.uploadSingle(a, t.tempFilePaths);
            }
        });
    },
    uploadSingle: function(e, t) {
        var a = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: a + "m=amouse_tel",
            filePath: t[0],
            name: "file",
            success: function(t) {
                var a = t.data;
                "string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno ? e.setData({
                    logo: a.data
                }) : e.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                e.setData({
                    hidden: !0
                });
            }
        });
    },
    uploadImg: function(o, n) {
        o.setData({
            hidden: !1
        });
        var t = app.util.url("entry/wxapp/ApiWxUpload");
        wx.uploadFile({
            url: t + "m=amouse_tel",
            filePath: n,
            name: "file",
            success: function(t) {
                var a = t.data;
                if ("string" == typeof a && (a = JSON.parse(a.trim())), 0 == a.errno) {
                    var e = new Array(), i = new Array();
                    (i = o.data.uploadimgArr).push(a.data), (e = o.data.imageList).push(n), o.setData({
                        uploadimgArr: i,
                        imageList: e
                    }), o.data.img_index = o.data.img_index + 1, o.data.img_index < o.data.image_list1.length ? o.uploadImg(o, "" + o.data.image_list1[o.data.img_index]) : o.setData({
                        hidden: !0
                    });
                } else o.setData({
                    hidden: !0
                });
            },
            fail: function(t) {
                o.setData({
                    hidden: !0
                });
            }
        });
    },
    post_tel_formSubmit: function(t) {
        var a = this, e = t.detail.value, i = t.detail.formId;
        if (e.formid = i, null == a.data.logo || "" == a.data.logo) return a.showModalTips("请上传幻灯片"), 
        !1;
        a.setData({
            submitIsLoading: !0,
            buttonIsDisabled: !0
        }), e.pay_money = a.data.total_amount, e.logo = a.data.logo, e.m = "amouse_tel", 
        wx.showToast({
            title: "提交中...",
            icon: "loading",
            duration: 1e4
        }), app.util.request({
            url: "entry/wxapp/ApiPostAdv",
            data: e,
            method: "POST",
            success: function(t) {
                0 == t.data.errno ? (a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                }), 0 < a.data.total_amount ? a.onPayment(t.data.data) : wx.showModal({
                    title: "发布成功",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        wx.switchTab({
                            url: "../../tel/index/index",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/index/index"
                                });
                            }
                        });
                    }
                })) : wx.showModal({
                    title: "提示",
                    content: t.data.message,
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && console.log("用户点击确定");
                    }
                });
            },
            complete: function() {
                wx.hideToast(), a.setData({
                    submitIsLoading: !1,
                    buttonIsDisabled: !1
                });
            }
        });
    },
    onPayment: function(t) {
        wx.requestPayment({
            timeStamp: t.timeStamp,
            nonceStr: t.nonceStr,
            package: t.package,
            signType: "MD5",
            paySign: t.paySign,
            success: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "付款成功",
                    showCancel: !1,
                    success: function(t) {
                        wx.showToast({
                            title: "已支付成功...",
                            icon: "success"
                        }), wx.switchTab({
                            url: "../../tel/index/index"
                        });
                    }
                });
            },
            fail: function(t) {
                wx.showModal({
                    title: "提示",
                    content: "支付失败",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && wx.switchTab({
                            url: "../../tel/index/index",
                            fail: function(t) {
                                wx.redirectTo({
                                    url: "../../tel/index/index"
                                });
                            }
                        });
                    }
                });
            }
        }), this.setData({
            isShowLoading: !0,
            buttonIsDisabled: !0
        });
    },
    showModalTips: function(t) {
        var a = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        wx.showModal({
            title: "提示",
            content: t,
            showCancel: a,
            success: function(t) {
                return !1;
            }
        });
    },
    onPullDownRefresh: function() {
        this.onLoad(), setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1e3);
    },
    onDeleteImage: function(t) {
        var a = t.currentTarget.dataset.index;
        this.data.uploadimgArr.splice(a, 1), this.setData({
            imageList: this.data.uploadimgArr
        });
    },
    chooseimg_bind_all: function() {
        var e = this;
        e.data.imageList.length < 9 ? wx.chooseImage({
            count: 9 - e.data.imageList.length,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                e.data.image_list1 = new Array();
                for (var a = 0; a < t.tempFilePaths.length; a++) e.data.image_list1.push(t.tempFilePaths[a]);
                e.uploadImg(e, "" + e.data.image_list1[0]);
            },
            fail: function() {
                wx.showToast({
                    title: "选取失败",
                    icon: "success",
                    duration: 2e3
                });
            }
        }) : wx.showToast({
            title: "当前最多只能选择9张图片",
            icon: "success",
            duration: 2e3
        });
    }
});