var app = getApp();

Page({
    data: {
        webview_url: null
    },
    onLoad: function(t) {
        var e = t.weburl, a = t.title;
        wx.hideToast(), this.setData({
            webview_url: e
        }), wx.setNavigationBarTitle({
            title: a
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.this_data_info.title,
            path: "amouse_tel/pages/nva/web-index/web-index"
        };
    }
});