var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

Page({
    data: {
        page: 1,
        data: [],
        rmp_data: [],
        cid: 0,
        cate_data: [],
        imgs: [],
        imgconfig: [],
        this_page_size: 1,
        this_page_num: 10,
        is_load_more: !0,
        keyword: "",
        searchShow: !1
    },
    onLoad: function(t) {
        var e = this;
        app.setTabbar(), this.setData({
            this_page_size: 1,
            data: []
        }), this.getAllData(), this.getRecommendOther(), _request2.default.get("ApiLoadConfig", {
            m: "amouse_tel"
        }).then(function(t) {
            null != t.bgcolor && 2 < t.bgcolor.length && wx.setNavigationBarColor({
                frontColor: "#ffffff",
                backgroundColor: t.bgcolor,
                animation: {
                    timingFunc: "linear"
                }
            }), e.setData({
                config: t,
                share_credit: t.share_credit ? t.share_credit : 0
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onPullDownRefresh: function() {
        var t = this;
        t.setData({
            data: [],
            this_page_size: 1,
            searchShow: !1,
            title: ""
        }), t.getAllApplets(), t.getRecommendOther();
    },
    getRecommendOther: function() {
        var e = this;
        _request2.default.get("ApiGetRecommend", {
            showLoading: !1
        }).then(function(t) {
            e.setData({
                recommends: t
            });
        });
    },
    getAllData: function(t) {
        var e = this, a = e.data.data;
        t = t || !1;
        var i = {};
        i.pageIndex = e.data.this_page_size, i.pageSize = e.data.this_page_num, i.keyword = e.data.keyword, 
        _request2.default.get("ApiGetAllNav", i).then(function(t) {
            null == t.list || "" == t.list ? e.setData({
                is_load_more: !1
            }) : 1 == e.data.this_page_size && t.list.length < e.data.this_page_num ? e.setData({
                allList: t.list,
                is_load_more: !1
            }) : 1 == e.data.this_page_size && t.list.length == e.data.this_page_num ? e.setData({
                allList: t.list,
                is_load_more: !0
            }) : 1 < e.data.this_page_size && (a = a.concat(t.list), e.setData({
                allList: a,
                is_load_more: !0
            }));
        });
    },
    onReachBottom: function() {
        var t = this;
        if (0 == t.data.is_load_more) return wx.hideNavigationBarLoading(), !1;
        t.setData({
            this_page_size: ++t.data.this_page_size
        }), t.getAllData(!0);
    },
    onShowSearchTap: function() {
        this.setData({
            searchShow: !0
        });
    },
    onHideSearchBlur: function(t) {
        t.detail.value || this.setData({
            searchShow: !1
        });
    },
    onClearKeywordTap: function() {
        this.setData({
            searchShow: !1,
            keyword: ""
        }), this.getAllData();
    },
    onSearchSubmit: function(t) {
        var e = t.detail.value.keyword;
        this.setData({
            this_page_size: 1,
            data: [],
            cid: 0,
            keyword: e
        }), this.getAllData();
    },
    onNavigateTap: function(t) {
        var e = t.currentTarget.dataset.jumptype, a = t.currentTarget.dataset.click, i = t.currentTarget.dataset.title, s = t.currentTarget.dataset.url, r = t.currentTarget.dataset.appid, n = t.currentTarget.dataset.qrcode;
        1 == e ? wx.navigateTo({
            url: "../web-index/web-index?weburl=" + s + "&title=" + i
        }) : 0 == e && 0 == a ? wx.navigateToMiniProgram ? wx.navigateToMiniProgram({
            appId: r,
            path: "",
            envVersion: "release",
            success: function(t) {
                console.log("打开成功");
            }
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        }) : this.setData({
            isqrcode: !0,
            qrcode: n,
            xcx_title: i
        });
    },
    closeEject: function() {
        this.setData({
            isqrcode: !1,
            qrcode: "",
            xcx_title: ""
        });
    },
    toImg: function(t) {
        var e = t.currentTarget.dataset.img.split();
        wx.previewImage({
            urls: e
        });
    },
    onShareAppMessage: function() {
        var t = wx.getStorageInfoSync("shareInfo") || {};
        return {
            title: t.title || "导航（升级版）",
            desc: t.desc || "",
            path: "/amouse_tel/pages/nav/index/index"
        };
    },
    onMenuItemTap: function(t) {
        var e = t.currentTarget.dataset.index;
        this.setData({
            cid: e,
            this_page_size: 1,
            data: []
        }), this.getAllData();
    }
});