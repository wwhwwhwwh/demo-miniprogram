var _page = require("../page2.js"), _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}

var app = getApp();

(0, _page2.default)({
    data: {
        id: 0,
        hasExchange: !1
    },
    onLoad: function(a) {
        a.id ? (this.data.id = a.id, this.onPullDownRefresh(), this.setData({
            config: app.globalData.sysinfo
        }), null != app.globalData.sysinfo.bgcolor && 2 < app.globalData.sysinfo.bgcolor.length && wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: app.globalData.sysinfo.bgcolor,
            animation: {
                duration: 400,
                timingFunc: "linear"
            }
        })) : wx.showModal({
            content: "参数错误！",
            showCancel: !1
        });
    },
    onPullDownRefresh: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/ApiGetGoodsDetail",
            data: {
                m: "amouse_tel",
                id: e.data.id
            },
            success: function(a) {
                if (0 == a.data.errno) {
                    var t = a.data.data;
                    t.hasExchange = 1 == t.is_end_time && parseFloat(app.globalData.sysinfo.credit1) >= parseFloat(t.credit), 
                    e.setData(t), console.log(t), wx.showShareMenu && wx.showShareMenu();
                }
            },
            complete: function() {
                wx.stopPullDownRefresh;
            }
        });
    },
    onExchangeSubmit: function(a) {
        var t = "cancel" == a.detail.target.dataset.type, e = this;
        t ? e.setData({
            isShowExchangeDialog: !1
        }) : app.util.request({
            url: "entry/wxapp/ApiExchangeGoods",
            method: "post",
            data: {
                m: "amouse_tel",
                gid: this.data.id
            },
            success: function(a) {
                if (0 == a.data.errno) {
                    var t = a.data.data;
                    t.hasExchange = 1 == t.is_end_time && parseFloat(app.globalData.sysinfo.credit1) >= parseFloat(t.credit), 
                    e.setData(t), wx.showShareMenu && wx.showShareMenu(), e.setData({
                        isShowExchangeDialog: !1
                    });
                }
            },
            complete: function() {
                wx.stopPullDownRefresh;
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.title,
            path: "amouse_tel/pages/integral/goods/index?id=" + this.data.id
        };
    }
});