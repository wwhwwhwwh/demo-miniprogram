var _underscore = require("../../resource/utils/underscore.js"), _underscore2 = _interopRequireDefault(_underscore), _requestUtil = require("../../resource/utils/requestUtil.js"), _requestUtil2 = _interopRequireDefault(_requestUtil);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp(), BASE_PAGE = {
    onNavigateTap: function(t) {
        var e = t.detail.target ? t.detail.target.dataset : t.currentTarget.dataset, a = e.url, r = e.type, i = {
            url: a
        };
        t.detail.formId && _requestUtil2.default.pushFormId(t.detail.formId), "switch" == r ? (i.fail = function() {
            return wx.navigateTo({
                url: a
            });
        }, wx.switchTab(i)) : wx.navigateTo(i);
    },
    onSetValueTap: function(t) {
        var e = t.target.dataset, a = e.name, r = e.value, i = {};
        i[a] = r, this.setData(i), t.detail.formId && _requestUtil2.default.pushFormId(t.detail.formId);
    },
    onEmptyTap: function() {},
    startPullDownRefresh: function() {
        var t = wx.getSystemInfoSync();
        wx.startPullDownRefresh && "ios" !== t.platform ? wx.startPullDownRefresh() : this.onPullDownRefresh();
    },
    onSetData: function(t, e) {
        t = t || [], this.setData({
            page: void 0 !== e ? e : this.data.page,
            data: 1 === e || void 0 === e ? t : this.data.data.concat(t),
            hasMore: void 0 !== e && 20 <= t.length,
            isEmpty: (1 === e || void 0 === e) && 0 === t.length,
            isLoading: !1
        });
    },
    onCopyTap: function(t) {
        var e = this, a = t.currentTarget.dataset.data;
        wx.setClipboardData({
            data: a,
            success: function(t) {
                e.setData({
                    isShowCopyTips: !0
                }), setTimeout(function() {
                    e.setData({
                        isShowCopyTips: !1
                    });
                }, 1e3);
            }
        });
    },
    onPreviewTap: function(t) {
        var e = t.target.dataset, a = e.index, r = e.url;
        if (void 0 !== a || void 0 !== r) {
            var i = t.currentTarget.dataset.urls;
            i = void 0 === i ? [] : i, void 0 === a || r || (r = i[a]), wx.previewImage({
                current: r,
                urls: i
            });
        }
    }
};

function Page2(t) {
    Page(_underscore2.default.extend({}, BASE_PAGE, t));
}

module.exports = Page2;