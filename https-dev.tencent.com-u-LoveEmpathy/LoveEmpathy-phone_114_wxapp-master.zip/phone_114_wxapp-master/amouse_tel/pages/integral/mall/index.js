var _page = require("../page2.js"), _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}

var app = getApp();

(0, _page2.default)({
    data: {
        list: [],
        isEmpty: !1,
        hasMore: !0,
        isLoading: !1,
        page: 1
    },
    onLoad: function(a) {
        app.setTabbar();
        var e = this;
        app.util.request({
            url: "entry/wxapp/ApiGetMyInfo",
            data: {
                m: "amouse_tel"
            },
            success: function(a) {
                if (0 == a.data.errno) {
                    var t = a.data.data;
                    e.setData({
                        config: t
                    }), t.bgcolor && wx.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: t.bgcolor,
                        animation: {
                            duration: 400,
                            timingFunc: "linear"
                        }
                    });
                }
            }
        }), e.onPullDownRefresh();
    },
    onSetData: function(a, t) {
        a = a || [], this.setData({
            page: void 0 !== t ? t : this.data.page,
            list: 1 === t || void 0 === t ? a : this.data.list.concat(a),
            hasMore: void 0 !== t && 20 <= a.length,
            isEmpty: (1 === t || void 0 === t) && 0 === a.length,
            isLoading: !1
        });
    },
    onPullDownRefresh: function() {
        var t = this;
        app.util.request({
            url: "entry/wxapp/ApiGetGoodsList",
            data: {
                m: "amouse_tel",
                page: t.data.page
            },
            success: function(a) {
                0 == a.data.errno && t.onSetData(a.data.data, 1);
            },
            complete: function() {
                wx.stopPullDownRefresh;
            }
        });
    },
    onReachBottom: function() {
        var t = this;
        if (!t.data.hasMore) return console.log("没有更多了..."), void wx.stopPullDownRefresh();
        app.util.request({
            url: "entry/wxapp/ApiGetGoodsList",
            data: {
                m: "amouse_tel",
                page: t.data.page + 1
            },
            success: function(a) {
                0 == a.data.errno && t.onSetData(a.data.data, t.data.page + 1);
            },
            complete: function() {
                wx.stopPullDownRefresh;
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "积分商城",
            path: "/amouse_tel/pages/integral/mall/index"
        };
    }
});