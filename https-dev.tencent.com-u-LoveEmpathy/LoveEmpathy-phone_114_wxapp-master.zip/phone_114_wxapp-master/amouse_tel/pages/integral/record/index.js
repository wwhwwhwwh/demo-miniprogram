var _page = require("../page2.js"), _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}

var app = getApp();

(0, _page2.default)({
    data: {
        data: [],
        isEmpty: !1,
        hasMore: !0,
        isLoading: !1,
        page: 1
    },
    onLoad: function(a) {
        this.onPullDownRefresh();
    },
    onPullDownRefresh: function() {
        var t = this;
        app.util.request({
            url: "entry/wxapp/ApiGetExchages",
            data: {
                m: "amouse_tel",
                page: t.data.page
            },
            success: function(a) {
                if (0 == a.data.errno) {
                    var e = a.data.data;
                    t.onSetData(e, 1);
                }
            },
            complete: function() {
                wx.stopPullDownRefresh;
            }
        });
    },
    onSetData: function(a, e) {
        a = a || [], this.setData({
            page: void 0 !== e ? e : this.data.page,
            list: 1 === e || void 0 === e ? a : this.data.list.concat(a),
            hasMore: void 0 !== e && 20 <= a.length,
            isEmpty: (1 === e || void 0 === e) && 0 === a.length,
            isLoading: !1
        });
    },
    onReachBottom: function() {
        var t = this;
        if (!t.data.hasMore) return console.log("没有更多了..."), void wx.stopPullDownRefresh();
        app.util.request({
            url: "entry/wxapp/ApiGetExchages",
            data: {
                m: "amouse_tel",
                page: t.data.page + 1
            },
            success: function(a) {
                if (0 == a.data.errno) {
                    var e = a.data.data;
                    t.onSetData(e, 1);
                }
            },
            complete: function() {
                wx.stopPullDownRefresh;
            }
        });
    }
});