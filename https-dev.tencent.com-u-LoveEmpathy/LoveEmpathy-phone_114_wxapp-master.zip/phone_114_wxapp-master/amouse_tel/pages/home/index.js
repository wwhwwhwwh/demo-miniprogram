var _data;

function _defineProperty(t, a, e) {
    return a in t ? Object.defineProperty(t, a, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[a] = e, t;
}

var app = getApp();

Page({
    data: (_data = {
        reachBottom_delayTime: 0,
        store_type: "",
        store_cate: "",
        single_store_info: [],
        page_index: 1,
        storeListArr: [],
        is_toLoad: !1,
        param: {
            keyword: "",
            type: 0
        },
        g_share_title: "",
        g_share_desc: "",
        search_p: "搜索",
        source_data: {},
        goods_data_waimai: [],
        goods_data_diannei: [],
        store_data: !1,
        tabTit: "",
        this_store_id: 0,
        consume_type: "",
        cart_list_isshow: !1,
        cart_list: [],
        store_yingye_status_text: "未营业",
        store_yingye_status_val: 2,
        store_button_status: !0,
        submitIsLoading: !1,
        guigeIsShow: !1,
        goods_attr_select: {},
        goods_specification: "",
        goods_a_info: {}
    }, _defineProperty(_data, "store_data", !1), _defineProperty(_data, "this_store_id", 0), 
    _data),
    onLoad: function(t) {
        var a = this;
        a.setData({
            this_options: t
        }), app.util.getUserInfo(function(t) {
            app.globalData.hasLogin = !0, a.setData({
                userInfo: t
            }), app.globalData.userInfo = t;
        }), app.util.request({
            url: "entry/wxapp/ApiGetSlides",
            data: {
                m: "amouse_tel"
            },
            success: function(t) {
                0 == t.data.errno && a.setData({
                    imgUrls: t.data.data,
                    hasSlider: !1
                });
            },
            fail: function(t) {
                a.setData({
                    hasSlider: !0
                });
            }
        });
    },
    loadAlls: function() {
        var o = this;
        app.util.request({
            url: "entry/wxapp/ApiLoadConfig",
            data: {
                m: "amouse_tel"
            },
            success: function(t) {
                if (0 == t.data.errno) {
                    var a = t.data.data;
                    a.add_count = 1e4 <= a.add_count ? Math.floor(a.add_count / 100) / 100 + " 万" : a.add_count, 
                    a.click_count = 1e4 <= a.click_count ? Math.floor(a.click_count / 100) / 100 + " 万" : a.click_count, 
                    wx.setNavigationBarTitle({
                        title: a.followurl
                    });
                    var e = [];
                    e.sharetitle = t.data.data.sharetitle, e.sharedesc = t.data.data.sharedesc, o.setData({
                        config: a,
                        shareInfo: e
                    }), app.globalData.sysinfo = a, app.globalData.claim_fee = a.claim_fee, o.setData({
                        public_credit: a.public_credit,
                        share_credit: a.share_credit
                    });
                }
            }
        });
    },
    loadAllIcons: function() {
        app.util.request({
            url: "entry/wxapp/apiGetIcons",
            data: {
                m: "amouse_tel"
            },
            success: function(t) {
                if (0 == t.data.errno) {
                    var a = t.data.data, e = [], o = {}, r = -1;
                    for (var s in a) {
                        s % 8 == 0 && (e[++r] = []);
                        var i = a[s];
                        e[r].push(i);
                        try {
                            o[i.id] = JSON.parse(i.style ? i.style : "{}");
                        } catch (t) {
                            console.error(t);
                        }
                    }
                    this.setData({
                        icons: e,
                        styles: o
                    });
                }
            },
            fail: function(t) {
                console.log(t);
            }
        });
    },
    onPullDownRefresh: function() {
        this.data.page_index = 1, setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 1e3);
    },
    onReachBottom: function() {},
    onShow: function() {
        var t = this.data.this_options;
        null != t.scene && 1044 == t.scene && wx.getShareInfo({
            shareTicket: t.shareTicket,
            success: function(t) {
                t.encryptedData, t.iv;
                console.log(t);
            }
        });
    },
    getShareData: function() {
        var a = this;
        requestUtil.get(_DgData.duoguan_get_share_data_url, {
            mmodule: "dg_store"
        }, function(t) {
            a.setData({
                g_share_title: t.title,
                g_share_desc: t.desc
            });
        });
    },
    getStoreConfig: function() {
        var r = this;
        requestUtil.get(_DgData.duoguan_host_api_url + "/index.php?s=/addon/DgStore/Api/getStoreConfig.html", {}, function(t) {
            if (r.data.store_type = t.store_type, r.setData({
                is_ruzhu: t.is_ruzhu
            }), 1 == t.store_type) r.data.this_store_id = t.store_id, r.setData({
                store_type: t.store_type
            }), r.getStoreInfo(); else if (2 == t.store_type) {
                r.setData({
                    store_type: t.store_type
                });
                var a = wx.getStorageSync("LATITUD"), e = wx.getStorageSync("LONGITUDE"), o = wx.getStorageSync("ADDRESS");
                a && e && o && "undefined" != a && "undefined" != e ? (r.setData({
                    address: o
                }), r.getManyStoresSource()) : r.getLocation();
            }
        });
    },
    refresh: function() {
        var t = this;
        t.setData({
            is_toLoad: !0
        }), 0 == t.data.reachBottom_delayTime && 0 == t.data.is_toLoad && (t.onPullDownRefresh(), 
        t.data.reachBottom_delayTime = 3), setTimeout(function() {
            t.data.reachBottom_delayTime = 0, t.setData({
                is_toLoad: !1
            });
        }, 2e3);
    },
    reachBottom: function() {
        var t = this;
        0 == t.data.reachBottom_delayTime && (1 < t.data.page_index && t.onReachBottom(), 
        t.data.reachBottom_delayTime = 3), setTimeout(function() {
            t.data.reachBottom_delayTime = 0;
        }, 2e3);
    },
    getManyStoresSource: function() {
        var s = this;
        requestUtil.get(_DgData.duoguan_host_api_url + "/index.php?s=/addon/DgStore/Api/getStoreCategoryAndAdvert.html", {}, function(t) {
            var a, e = t.categoryList, o = t.advert, r = o.length;
            a = !(t.category_num < 10), s.setData({
                store_category_list: e,
                store_category_num: t.category_num,
                advertList: o,
                advertCount: r,
                indicatorDots: a
            });
        }), this.getStoreList();
    },
    getStoreList: function() {
        var a = this, t = wx.getStorageSync("LATITUD"), e = wx.getStorageSync("LONGITUDE");
        wx.getStorageSync("ADDRESS");
        requestUtil.get(_DgData.duoguan_host_api_url + "/index.php?s=/addon/DgStore/Api/getStoreList.html", {
            page_index: a.data.page_index,
            ws_lat: t,
            ws_lng: e,
            store_cate: a.data.store_cate,
            keywords: a.data.param.keyword
        }, function(t) {
            1 == a.data.page_index && a.data.storeListArr.splice(0, a.data.storeListArr.length), 
            0 < t.length && (a.data.storeListArr = a.data.storeListArr.concat(t)), a.setData({
                store_list: a.data.storeListArr
            }), a.data.page_index = parseInt(a.data.page_index) + 1;
        });
    },
    getLocation: function() {
        var o = this;
        wx.getLocation({
            type: "wgs84",
            success: function(t) {
                util.getMapSdk().reverseGeocoder({
                    location: {
                        latitude: t.latitude,
                        longitude: t.longitude
                    },
                    success: function(t) {
                        var a = t.result.address_component, e = "";
                        a.street_number ? e = a.street_number : a.street ? e = a.street : a.city && (e = a.city), 
                        t = t.result, wx.setStorageSync("LATITUD", t.location.lat), wx.setStorageSync("LONGITUDE", t.location.lng), 
                        wx.setStorageSync("ADDRESS", e), o.setData({
                            address: e
                        }), o.data.page_index = 1, o.getManyStoresSource();
                    }
                });
            },
            complete: function() {}
        });
    },
    onShareAppMessage: function() {
        var t = this;
        return 2 == t.data.store_type ? {
            title: t.data.g_share_title,
            desc: t.data.g_share_desc,
            path: "/pages/store/store-home/index"
        } : {
            title: t.data.store_data.store_name,
            desc: t.data.store_data.store_jieshao,
            path: "pages/store/store-info/index?store_id=" + t.data.this_store_id
        };
    },
    advert_top_bind: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url
        });
    },
    store_category_click: function(t) {
        var a = this;
        a.data.param.keyword = "", a.data.store_cate = t.currentTarget.id, "全部" == t.currentTarget.dataset.cate_name && (a.data.store_cate = ""), 
        a.data.page_index = 1, a.getStoreList(), this.setData({
            toView: "store_list"
        });
    },
    onShowSearchTap: function() {
        this.setData({
            searchShow: !0
        });
    },
    onHideSearchBlur: function(t) {
        var a = this.data.param;
        a.keyword = "", this.setData({
            searchShow: !1,
            param: a
        });
    },
    onSearchSubmit: function(t) {
        var a = this;
        a.data.param.keyword = t.detail.value.keyword, a.data.store_cate = "", a.data.page_index = 1, 
        a.getStoreList();
        var e = a.data.param.keyword;
        e || (e = "搜索"), this.setData({
            toView: "store_list",
            search_p: a.data.param.keyword,
            param: a.data.param
        });
    },
    onClearKeywordTap: function() {
        this.data.param.keyword = "", this.setData({
            param: this.data.param
        });
    },
    onOpenMapTap: function(t) {
        var a = this;
        wx.chooseLocation({
            success: function(t) {
                console.log(t), a.setData({
                    address: t.name
                }), wx.setStorageSync("LATITUD", t.latitude), wx.setStorageSync("LONGITUDE", t.longitude), 
                wx.setStorageSync("ADDRESS", t.name), a.data.page_index = 1, a.getManyStoresSource();
            }
        });
    },
    store_info_bind: function(t) {
        wx.navigateTo({
            url: "../store-info/index?store_id=" + t.currentTarget.id
        });
    },
    ruzhu_bind: function(t) {
        wx.navigateTo({
            url: "../store-ruzhu/index"
        });
    }
});