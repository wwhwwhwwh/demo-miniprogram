var _Page, _underscore = require("../../../resource/utils/underscore.js"), _underscore2 = _interopRequireDefault(_underscore), _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _defineProperty(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var app = getApp(), WxParse = require("../../../resource/wxParse/wxParse.js"), allinfo = [], playKey = "play_info", order = [ "red", "yellow", "blue", "green", "red" ];

Page((_defineProperty(_Page = {
    timeId: 0,
    palyUrl: "",
    data: {
        src: "",
        continue_read: !1,
        single_read: "single",
        playStatus: 0,
        stepTime: "00:00",
        durationTime: "00:00",
        progress: "0",
        to_vip: "month",
        write_msg: !1,
        zanshang_show: !1,
        message: "",
        info_data: [],
        comment_list: [],
        id: "",
        typeid: "",
        title: "",
        is_load_more: !0,
        zanNum: "",
        is_avAutoPlay: 0,
        jindu: 0,
        isToplay: !1,
        isEnd: !1,
        iszan: 0,
        is_collection: !1,
        is_otherShang: !1,
        tabOffsetTop: ""
    },
    onLoad: function(a) {
        var o = this, t = a.id;
        this.setData({
            is_load_more: !0,
            id: t,
            info_data: []
        }), this.getArticleInfo(), wx.onBackgroundAudioStop(this.onStop), wx.getBackgroundAudioPlayerState({
            success: function(t) {
                var e = wx.getStorageSync(playKey);
                t.dataUrl;
                e && 1 == t.status && a.id == e.id && o.startProgressListener();
            }
        });
        var e = wx.getStorageSync("bgcolor");
        null != e && 2 < e.length && wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: e,
            animation: {
                duration: 400,
                timingFunc: "linear"
            }
        });
    },
    onShow: function() {},
    onUnload: function() {
        this.stopProgressListener();
    },
    startProgressListener: function() {
        var t = this, e = function() {
            wx.getBackgroundAudioPlayerState({
                success: t.onProgressUpdate
            });
        };
        this.timeId = setInterval(e, 250), e();
    },
    stopProgressListener: function() {
        clearInterval(this.timeId);
    },
    onProgressUpdate: function(t) {
        if (1 == t.status) {
            this.playUrl = t.dataUrl;
            var e = t.currentPosition, a = t.duration, o = Math.floor(e / 60), n = Math.floor(e % 60), i = Math.floor(a / 60), s = Math.floor(a % 60), r = {
                stepTime: (o < 10 ? "0" + o : o) + ":" + (n < 10 ? "0" + n : n),
                durationTime: (i < 10 ? "0" + i : i) + ":" + (s < 10 ? "0" + s : s),
                progress: e / a * 100,
                downloadPercent: t.downloadPercent
            };
            0 != t.status && 1 != t.status || (r.playStatus = t.status), this.setData(r);
        }
    },
    onTogglePlayTap: function(t) {
        var e = this;
        if (e.data.playStatus) wx.pauseBackgroundAudio({
            success: e.onPause,
            fail: function(t) {
                wx.showModal({
                    content: "暂停失败：" + t.errMsg,
                    showCancel: !1
                });
            }
        }); else {
            var a = wx.getStorageSync(playKey);
            e.playUrl != a.path && wx.stopBackgroundAudio(), wx.playBackgroundAudio({
                dataUrl: e.data.info_data.musicurl,
                complete: e.onPlay
            });
        }
    },
    onPlay: function() {
        this.setData({
            playStatus: 1
        }), wx.setStorageSync(playKey, {
            id: this.data.id,
            path: this.data.info_data.musicurl
        }), this.startProgressListener();
    },
    onPause: function() {
        this.setData({
            playStatus: 0
        }), this.stopProgressListener();
    },
    onStop: function(t) {
        this.setData({
            playStatus: 0
        }), this.stopProgressListener(), wx.removeStorageSync(playKey), wx.getBackgroundAudioPlayerState({
            success: this.onProgressUpdate
        });
    },
    getArticleInfo: function(t) {
        var a = this;
        t = t || !1;
        var e = a.data.id;
        _request2.default.post("ApiGetCmsArt", {
            m: "amouse_tel",
            artId: e
        }).then(function(t) {
            if (a.setData({
                info_data: t,
                id: t.id,
                zanNum: t.zanNum,
                iszan: t.iszan,
                collect: t.collect,
                typeid: t.is_video,
                is_avAutoPlay: !0
            }), null != t.title && null != t.title && wx.setNavigationBarTitle({
                title: t.title
            }), WxParse.wxParse("freeinfo", "html", t.description, a), WxParse.wxParse("content", "html", t.content, a), 
            2 == t.is_video && t.musicurl) {
                var e = wx.getStorageSync(playKey);
                t.musicurl != e.path && (wx.stopBackgroundAudio(), wx.playBackgroundAudio({
                    dataUrl: t.musicurl,
                    complete: a.onPlay
                }));
            }
        });
    },
    videoErrorCallback: function(t) {
        console.log("视频错误信息:" + t.detail.errMsg);
    },
    toPlay: function() {
        this.setData({
            isToplay: !0
        });
    },
    onTimejindu: function(t) {
        var e = t.detail.currentTime, a = t.detail.duration, o = parseInt(e / a * 100);
        this.setData({
            jindu: o,
            isToplay: !1
        });
    },
    toZan: function(t) {
        var e = this, a = {
            id: t.currentTarget.id,
            is_sell: 21,
            m: "amouse_tel"
        };
        _request2.default.post("ApiToDianzanArticle", a).then(function(t) {
            e.setData({
                iszan: !e.data.iszan,
                zanNum: 0 == t ? parseInt(e.data.zanNum) - 1 : parseInt(e.data.zanNum) + 1
            });
        });
    },
    onNavigateTap: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url
        });
    },
    CommentLocation: function(t) {
        var e = t.currentTarget.offsetTop;
        wx.pageScrollTo({
            scrollTop: e
        });
    },
    updateTabOffsetTop: function() {
        var e = this, t = wx.createSelectorQuery();
        t.select("#comment").boundingClientRect(), t.selectViewport().scrollOffset(), t.exec(function(t) {
            console.log(t), t[0] && t[1] && (0 < t[1].scrollTop ? 0 < t[0].top ? e.tabOffsetTop = t[1].scrollTop + t[0].top : e.tabOffsetTop = t[1].scrollTop - Math.abs(t[0].bottom) + 2 * t[0].height : e.tabOffsetTop = t[0].top, 
            e.setData({
                tabOffsetTop: e.tabOffsetTop
            }));
        });
    },
    write_msg: function() {
        this.setData({
            write_msg: !0
        });
    },
    toClose: function(t) {
        this.setData({
            write_msg: !1
        });
    },
    formSubmit: function(t) {
        var e = t.detail.target.id, a = this.data.info_data.c_info.title, o = t.detail.value;
        o.cid = e, o.ctitle = a;
    },
    toComment: function(t) {},
    toDianzan: function(t) {
        t.currentTarget.id;
    },
    toIndex: function(t) {
        var e = "/amouse_tel/pages/cms/index/index";
        wx.navigateTo({
            url: e,
            fail: function() {
                wx.reLaunch({
                    url: e
                });
            }
        });
    },
    toCollection: function(t) {
        console.log(t);
        var a = this, e = {
            id: t.currentTarget.id,
            is_sell: 20,
            m: "amouse_tel"
        };
        _request2.default.post("ApiSetCollect", e).then(function(t, e) {
            a.setData({
                collect: !a.data.collect
            });
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.info_data.title,
            desc: this.data.info_data.title,
            path: "/amouse_tel/pages/cms/article/article?id=" + this.data.id + "&is_video=" + this.data.typeid,
            success: function() {}
        };
    },
    commentLocation: function(t) {
        this.updateTabOffsetTop();
    }
}, "updateTabOffsetTop", function() {
    var e = this, t = wx.createSelectorQuery();
    t.select("#comment").boundingClientRect(), t.selectViewport().scrollOffset(), t.exec(function(t) {
        console.log(t), t[0] && t[1] && (0 < t[1].scrollTop ? 0 < t[0].top ? e.tabOffsetTop = t[1].scrollTop + t[0].top : e.tabOffsetTop = t[1].scrollTop - Math.abs(t[0].bottom) + 2 * t[0].height : e.tabOffsetTop = t[0].top, 
        e.setData({
            tabOffsetTop: e.tabOffsetTop
        }), wx.pageScrollTo({
            scrollTop: e.data.tabOffsetTop
        }));
    });
}), _defineProperty(_Page, "continue_read", function() {
    this.setData({
        continue_read: !this.data.continue_read
    });
}), _defineProperty(_Page, "toCloseRead", function() {
    this.setData({
        continue_read: !1
    });
}), _defineProperty(_Page, "single_read_change", function() {
    this.setData({
        single_read: "single"
    });
}), _defineProperty(_Page, "to_vip_change", function() {
    this.setData({
        single_read: "to_vip"
    });
}), _defineProperty(_Page, "to_vip_month", function() {
    this.setData({
        to_vip: "month"
    });
}), _defineProperty(_Page, "to_vip_quarter", function() {
    this.setData({
        to_vip: "quarter"
    });
}), _defineProperty(_Page, "to_vip_year", function() {
    this.setData({
        to_vip: "year"
    });
}), _defineProperty(_Page, "zanshang_show", function() {
    this.setData({
        zanshang_show: !0
    });
}), _defineProperty(_Page, "shangMoney", function(t) {
    var e = t.target.dataset.name;
    console.log(e);
}), _defineProperty(_Page, "otherShangMoney", function() {
    this.setData({
        is_otherShang: !0
    });
}), _defineProperty(_Page, "closeOther", function() {
    this.setData({
        is_otherShang: !1,
        zanshang_show: !1
    });
}), _defineProperty(_Page, "toCloseShang", function() {
    this.setData({
        zanshang_show: !1
    });
}), _defineProperty(_Page, "onSyncWechatInfo", function(e) {
    var a = this, o = this;
    util.getUserInfo(function(t) {
        a.syncWechatInfoId = requestUtil.post(API_USER_INFO_SAVE_URL, {
            nickname: t.nickName,
            headimgurl: t.avatarUrl,
            sex: t.gender,
            city: t.city,
            province: t.province,
            country: t.country,
            language: t.language
        }, function(t) {
            o.toComment(e);
        });
    });
}), _Page));