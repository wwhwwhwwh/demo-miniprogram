var _request = require("../../../util/request.js"), _request2 = _interopRequireDefault(_request), _underscore = require("../../../resource/utils/underscore"), _underscore2 = _interopRequireDefault(_underscore);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var app = getApp();

function e(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

Page({
    data: {
        tabIndex: "",
        cateList: [],
        artList: [],
        querys: {
            title: "",
            change_title: "",
            is_rmd: 0,
            keyword: "",
            pageNo: 1,
            pageSize: 20
        },
        is_load_more: !0,
        scrollTop: 0,
        cid: ""
    },
    onLoad: function(t) {
        var e = this;
        if (app.setTabbar(), t.cid) {
            var a = t.cid;
            e.setData({
                "querys.pageNo": 1,
                cid: a,
                artList: []
            });
        } else if (t.keyword) {
            var s = t.keyword;
            e.setData({
                "querys.pageNo": 1,
                cid: a,
                artList: [],
                "querys.keyword": s
            });
        } else e.setData({
            "querys.is_rmd": 0,
            "querys.pageNo": 1,
            artList: []
        });
        _request2.default.get("GetCmsCategory", {
            m: "amouse_tel"
        }).then(function(t) {
            e.setData({
                cateList: t
            });
        });
        var r = wx.getStorageSync("config");
        null != r && 2 < r.bgcolor.length && wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: r.bgcolor,
            animation: {
                duration: 400,
                timingFunc: "linear"
            }
        }), this.getCmsList();
    },
    onReady: function() {},
    onShow: function() {
        var t = wx.getStorageSync("_sysset");
        t && this.setData({
            config: t
        });
    },
    getCmsList: function() {
        var i = this, t = {}, o = this.data.querys, e = i.data.cid;
        for (var a in 1 == o.pageNo && i.setData({
            "querys.pageSize": 20,
            scrollTop: 0,
            list: []
        }), o) "" !== o[a] && (t[a] = o[a]);
        console.log(t), e && i.setData({
            is_rmd: 0,
            tabIndex: e
        }), t.keyword && i.setData({
            is_rmd: 0
        }), t.m = "amouse_tel", t.cateid = i.data.tabIndex, i.setData({
            isLast: !1
        }), _request2.default.post("ApiGetCmsArts", t).then(function(t) {
            if (i.data.isFinish = !0, t && 0 < t.list.length) {
                var e = i.data.artList, a = t.list;
                0 == e.length && !0;
                for (var s = 0, r = a.length; s < r; s++) e.push(a[s]);
                0 < e.length ? t.totalPage == t.pageNo ? i.setData({
                    hasList: !0,
                    isLast: !0,
                    artList: e
                }) : i.setData({
                    hasList: !0,
                    isLast: !1,
                    artList: e
                }) : i.setData({
                    hasList: !1,
                    artList: []
                });
            }
            1 == o.pageNo && i.setData({
                "querys.pageSize": 10,
                "querys.pageNo": 2
            }), i.data.locked = !1;
        });
    },
    loadmoreData: function() {
        this.data.locked || this.data.isLast || (this.data.locked = !0, this.data.querys.pageNo++, 
        this.getCmsList());
    },
    onTabChangeTap: function(t) {
        var e = this;
        e.setData({
            "querys.is_load_more": !0
        });
        var a = t.currentTarget.dataset.tabIndex;
        "rmd" == a ? e.setData({
            tabIndex: "",
            "querys.is_rmd": 0,
            "querys.change_title": "",
            "querys.pageNo": 1,
            "querys.pageSize": 20,
            artList: [],
            cid: "",
            "querys.keyword": ""
        }) : e.setData({
            tabIndex: a,
            "querys.is_rmd": 1,
            "querys.change_title": "",
            "querys.pageNo": 1,
            artList: [],
            cid: a,
            "querys.keyword": ""
        }), e.getCmsList();
    },
    searchTitle: function(t) {
        this.setData({
            title: t.detail.value,
            is_load_more: !0
        });
    },
    onSearch: function(t) {
        var e = this, a = e.data.title;
        e.setData({
            "querys.change_title": a,
            "querys.pageNo": 1,
            artList: [],
            tabIndex: "",
            cid: "",
            "querys.keyword": a
        }), e.getCmsList();
    },
    closeSearch: function(t) {
        var e = this;
        e.setData({
            title: ""
        }), e.data.querys.change_title && (e.setData({
            tabIndex: "",
            "querys.is_rmd": 0,
            "querys.change_title": "",
            "querys.pageNo": 1,
            "querys.pageSize": 20,
            c_data: [],
            cid: "",
            "querys.keyword": ""
        }), e.getCmsList());
    },
    onNavigateTap: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url
        });
    },
    onLunboContent: function(t) {
        wx.navigateTo({
            url: t.currentTarget.dataset.url
        });
    },
    onShareAppMessage: function() {
        var t = wx.getStorageSync("share_Info");
        return {
            title: (t = t || {}).title || "房产资讯",
            desc: t.desc || "",
            path: "/amouse_tel/pages/cms/index/index?cid=" + this.data.cid,
            success: function() {}
        };
    },
    changeSearchStatus: function() {
        this.setData({
            search_open_status: !this.data.search_open_status
        });
    }
});