var __assign = Object.assign || function(e) {
    for (var t, n = 1, o = arguments.length; n < o; n++) for (var s in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s]);
    return e;
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var listener_js_1 = require("./listener.js"), Config = function() {
    function e(e, t) {
        this.host = e, this.port = t;
    }
    return e.prototype.getHost = function() {
        return this.host;
    }, e.prototype.setHost = function(e) {
        this.host = e;
    }, e.prototype.getPort = function() {
        return this.port;
    }, e.prototype.setPort = function(e) {
        this.port = e;
    }, e.prototype.getAddress = function() {
        return this.host + ":" + this.port;
    }, e;
}();

exports.Config = Config;

var Message = function() {
    function t(e, t, n) {
        this.id = e, this.type = t, this.data = n;
    }
    return t.parse = function(e) {
        return new t((e = JSON.parse(e)).id, e.type, e.data);
    }, t.prototype.getId = function() {
        return this.id || (this.id = "m" + new Date().getTime()), this.id;
    }, t.prototype.getType = function() {
        return this.type;
    }, t.prototype.getData = function() {
        return this.data;
    }, t.prototype.setData = function(e) {
        this.data = e;
    }, t.prototype.toString = function() {
        return JSON.stringify({
            id: this.getId(),
            type: this.getType(),
            data: this.getData()
        });
    }, t;
}();

exports.Message = Message;

var Client = function() {
    function s() {}
    return s.init = function(e) {
        s.config = e, wx.onSocketOpen(function(e) {
            return listener_js_1.default.fireEventListener("websocket.open", [ e ]);
        }), wx.onSocketError(function(e) {
            return listener_js_1.default.fireEventListener("websocket.error", [ e ]);
        }), wx.onSocketClose(function(e) {
            s._isConnected = !1, s._isLogin = !1, listener_js_1.default.fireEventListener("websocket.close", [ e ]);
        }), wx.onSocketMessage(function(e) {
            if ("ping" === (e = JSON.parse(e.data)).type) return console.debug("ping server...", new Date()), 
            void wx.sendSocketMessage({
                data: '{"type":"pong"}'
            });
            var t = new Message(e.id, e.type, e.data);
            console.debug("receiving server message", t);
            for (var n = 0; n < s.routes.length; n++) {
                var o = s.routes[n];
                if ("function" == typeof o.rule) {
                    if (o.rule.call(null, t) && !1 === o.callback.call(null, t)) return;
                } else if (o.rule === t.getType() && !1 === o.callback.call(null, t)) return;
            }
        });
    }, s.isInited = function() {
        return null != s.config;
    }, s.connect = function(e) {
        void 0 === e && (e = {});
        var t = e.success;
        e.success = function(e) {
            s._isConnected = !0, t && t.call(null, e);
        }, wx.connectSocket(__assign({
            url: "wss://" + s.config.getAddress()
        }, e));
    }, s.close = function(e) {
        void 0 === e && (e = {
            code: 1e3,
            reason: ""
        }), wx.closeSocket(e);
    }, s.request = function(n, o) {
        void 0 === o && (o = {}), wx.sendSocketMessage({
            data: n + "",
            success: function() {
                var t = s.addRoute(function(e) {
                    return e.getId() === n.getId();
                }, function(e) {
                    return s.removeRoute(t), o.success && o.success.call(null, e), o.complete && o.complete.call(null, e), 
                    !1;
                });
            },
            fail: function(e) {
                console.error("sendSocketMessage:", e), o.fail && o.fail.call(null, e), o.complete && o.complete.call(null, e);
            }
        });
    }, s.login = function(n, o) {
        void 0 === o && (o = {});
        var e = function() {
            console.log("login server...");
            var e = new Message(null, "login", {
                uid: n
            }), t = o.success;
            o.success = function(e) {
                console.log("login result", e), s._isLogin = !0, t && t.call(null, e);
            }, s.request(e, o);
        };
        s.isConnected() ? (console.log("connected!"), e()) : s.connect({
            success: function() {
                return setTimeout(e, 500);
            },
            fail: console.error
        });
    }, s.send = function(e, t) {
        void 0 === t && (t = {}), wx.sendSocketMessage(__assign({
            data: e
        }, t));
    }, s.isConnected = function() {
        return s._isConnected;
    }, s.isLogin = function() {
        return s._isLogin;
    }, s.addRoute = function(e, t) {
        var n = {
            rule: e,
            callback: t
        };
        return s.routes.push(n), n;
    }, s.removeRoute = function(e) {
        var t = s.routes, n = t.indexOf(e);
        -1 !== n && t.splice(n, 1);
    }, s.addOnOpenListener = function(e) {
        listener_js_1.default.addEventListener("websocket.open", e);
    }, s.addOnErrorListener = function(e) {
        listener_js_1.default.addEventListener("websocket.error", e);
    }, s.addOnCloseListener = function(e) {
        listener_js_1.default.addEventListener("websocket.close", e);
    }, s.removeOnOpenListener = function(e) {
        listener_js_1.default.removeEventListener("websocket.open", e);
    }, s.removeOnErrorListener = function(e) {
        listener_js_1.default.removeEventListener("websocket.open", e);
    }, s.removeOnCloseListener = function(e) {
        listener_js_1.default.removeEventListener("websocket.open", e);
    }, s.routes = [], s._isConnected = !1, s._isLogin = !1, s;
}();

exports.Client = Client;