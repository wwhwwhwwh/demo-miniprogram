var $ = require("underscore"), _require = require("client"), Client = _require.Client, isLoginLoading = !1, FORM_ID_LIST = [];

module.exports = {
    pushFormId: function(e) {
        FORM_ID_LIST.push(e);
    }
};