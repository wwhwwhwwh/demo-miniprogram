function formatTime(e) {
    var t = e.getFullYear(), r = e.getMonth() + 1, n = e.getDate(), o = e.getHours(), a = e.getMinutes(), l = e.getSeconds();
    return [ t, r, n ].map(formatNumber).join("/") + " " + [ o, a, l ].map(formatNumber).join(":");
}

function formatNumber(e) {
    return (e = e.toString())[1] ? e : "0" + e;
}

function selectedShopDetail(e) {
    for (var t = getApp(), r = 0; r < t.globalData.tels.length; ++r) if (t.globalData.tels[r].id == e) return t.globalData.tels[r];
    return null;
}

function format(e, t) {
    var r = {
        "M+": (e = e instanceof Date ? e : new Date(e)).getMonth() + 1,
        "d+": e.getDate(),
        "h+": e.getHours(),
        "m+": e.getMinutes(),
        "s+": e.getSeconds(),
        "q+": Math.floor((e.getMonth() + 3) / 3),
        S: e.getMilliseconds()
    };
    for (var n in /(y+)/.test(t) && (t = t.replace(RegExp.$1, (e.getFullYear() + "").substr(4 - RegExp.$1.length))), 
    r) new RegExp("(" + n + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? r[n] : ("00" + r[n]).substr(("" + r[n]).length)));
    return t;
}

function formatSmartTime(e) {
    e = e instanceof Date ? e.getTime() : e;
    var t = new Date().getTime() - e + 2e4, r = new Date().setHours(0, 0, 0), n = r - 864e5, o = r + 864e5, a = n - 864e5, l = o + 864e5;
    if (t < 0) {
        if ((t = Math.abs(t)) < 6e4) return "一会儿";
        if (6e4 <= t && t < 36e5) return parseInt(t / 6e4) + "分钟后";
        if (e < o) return "今天" + format(e, "hh:mm");
        if (e < l) return "明天" + format(e, "hh:mm");
        if (e < l + 864e5) return "后天" + format(e, "hh:mm");
    } else {
        if (t < 6e4) return "刚刚";
        if (6e4 <= t && t < 36e5) return parseInt(t / 6e4) + "分钟前";
        if (r < e) return "今天" + format(e, "hh:mm");
        if (n < e) return "昨天" + format(e, "hh:mm");
        if (a < e) return "前天" + format(e, "hh:mm");
    }
    var s = new Date();
    s.setMonth(0, 0), s.setHours(0, 0, 0, 0);
    var u = new Date(e);
    return u.setMonth(0, 0), u.setHours(0, 0, 0, 0), s.getTime() == u.getTime() ? format(e, "M月d日 hh:mm") : format(e, "yyyy年M月d日 hh:mm");
}

function trySyncWechatInfo(t) {
    wx.getSetting({
        success: function(e) {
            e.authSetting["scope.userInfo"] && t && wx.getUserInfo({
                success: function() {
                    t.call(null, e.userInfo);
                }
            });
        }
    });
}

function regularPhoneNumber(e) {
    var t = e.replace(/\s|\-/g, "");
    0 == t.indexOf("+86") && (t = t.substr(3));
    return /^1\d{10}$/g.test(t) ? t : null;
}

function uploadImg(e) {
    var t = this, r = e.i ? e.i : 0, n = e.success ? e.success : 0, o = e.fail ? e.fail : 0;
    wx.uploadFile({
        url: e.url,
        filePath: e.path[r],
        name: "fileData",
        formData: null,
        success: function(e) {
            n++, console.log(e), console.log(r);
        },
        fail: function(e) {
            o++, console.log("fail:" + r + "fail:" + o);
        },
        complete: function() {
            console.log(r), ++r == e.path.length ? (console.log("执行完毕"), console.log("成功：" + n + " 失败：" + o)) : (console.log(r), 
            e.i = r, e.success = n, e.fail = o, t.uploadImg(e));
        }
    });
}

function scene_decode(e) {
    var t = (e + "").split(","), r = {};
    for (var n in t) {
        var o = t[n].split(":");
        0 < o.length && o[0] && (r[o[0]] = o[1] || null);
    }
    return r;
}

module.exports = {
    format: format,
    formatTime: formatTime,
    formatSmartTime: formatSmartTime,
    regularPhoneNumber: regularPhoneNumber,
    uploadImg: uploadImg,
    selectedShopDetail: selectedShopDetail,
    scene_decode: scene_decode
};