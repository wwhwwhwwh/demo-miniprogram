var _ = require("underscore"), LISTENER_MANAGER = [];

module.exports = {
    addEventListener: function(r, e) {
        if (!r || !isNaN(parseInt(r))) throw TypeError("监听器名称只能为英文字母以及下划线！");
        if (!_.isFunction(e)) throw TypeError("监听器只能为回调函数！");
        void 0 === LISTENER_MANAGER[r] && (LISTENER_MANAGER[r] = []), LISTENER_MANAGER[r].push(e);
    },
    removeEventListener: function(r, e) {
        if (_.isFunction(e)) {
            var n = function(r, e) {
                var n = _.indexOf(r, e);
                -1 !== n && r.splice(n, 1);
            };
            r && isNaN(parseInt(r)) ? n(LISTENER_MANAGER[r] || [], e) : _.each(LISTENER_MANAGER, function(r) {
                n(r, e);
            });
        }
    },
    fireEventListener: function(r, e, n) {
        if (!r || !isNaN(parseInt(r))) throw TypeError("监听器名称只能为英文字母以及下划线！");
        for (var E = LISTENER_MANAGER[r] || [], i = 0; i < E.length; i++) if (!1 === E[i].apply(n, e)) return !1;
    }
};