function navTo(o, t) {
    var a = "" == t ? o : o + "?" + t;
    wx.navigateTo({
        url: a
    });
}

function swithTo(o, t) {
    var a = "" == t ? o : o + "?" + t;
    wx.switchTab({
        url: a
    });
}

module.exports = {
    navTo: navTo,
    swithTo: swithTo
};