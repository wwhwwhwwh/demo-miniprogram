Object.defineProperty(exports, "__esModule", {
    value: !0
});

var app = getApp();

function request(e, t, s) {
    return s || (s = {}), s.m || (s.m = "amouse_tel"), new Promise(function(t, a) {
        app.util.request({
            url: "entry/wxapp/" + e,
            data: s,
            showLoading: !1,
            success: function(e) {
                0 == e.data.errno && t(e.data.data), a(e.data.message);
            },
            fail: function(e) {
                "request:fail timeout" == e.errMsg ? (wx.showLoading({
                    title: "请求服务器超时，请稍后再试"
                }), wx.navigateBack({
                    delta: -1
                })) : a(e.data && e.data.message ? e.data.message : e.errMsg);
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    });
}

function iget(e, t) {
    return request(e, "GET", t);
}

function ipost(e, t) {
    return request(e, "POST", t);
}

exports.default = {
    get: iget,
    post: ipost
};