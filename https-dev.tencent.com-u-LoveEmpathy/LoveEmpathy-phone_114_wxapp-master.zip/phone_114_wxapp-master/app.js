App({
    onLaunch: function() {},
    globalData: {
        userInfo: [],
        hasLogin: !1,
        gloabalFomIds: [],
        claim_fee: 0,
        cate_id: 1,
        tels: [],
        sysinfo: []
    },
    util: require("/we7/resource/js/util.js"),
    setTabbar: function() {
        var a = this, e = getCurrentPages(), t = e[e.length - 1], o = t.__route__;
        0 != o.indexOf("/") && (o = "/" + o);
        var s = {
            background_image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABAQMAAAAl21bKAAAAA1BMVEX///+nxBvIAAAACklEQVQI12NgAAAAAgAB4iG8MwAAAABJRU5ErkJggg==",
            border_color: "rgba(0,0,0,.1)"
        }, r = a.globalData.navbar;
        function l(e) {
            for (var a in e.tabbars) e.tabbars[a] && (e.tabbars[a].pagePath == o ? e.tabbars[a].active = !0 : e.tabbars[a].active = !1);
            t.setData({
                _allNavbar: e
            });
        }
        r && l(r), r || a.util.request({
            url: "entry/wxapp/ApiGetTabbar",
            data: {
                m: "amouse_tel",
                state: "tab"
            },
            success: function(e) {
                if (e.data && e.data.data.length <= 0) {
                    s.tabbars = [ {
                        pagePath: "/amouse_tel/pages/tel/index/index",
                        text: "首页",
                        selectedColor: "#073763",
                        color: "#666",
                        iconPath: "/amouse_tel/resource/images/tabbar/dianhua.png",
                        selectedIconPath: "/amouse_tel/resource/images/tabbar/dianhua-in.png"
                    }, {
                        pagePath: "/amouse_tel/pages/tel/all/allService",
                        text: "电话簿",
                        selectedColor: "#073763",
                        color: "#666",
                        iconPath: "/amouse_tel/resource/images/tabbar/fenlei-2.png",
                        selectedIconPath: "/amouse_tel/resource/images/tabbar/fenlei-1.png"
                    }, {
                        pagePath: "/amouse_tel/pages/tel/enter/enter",
                        text: "入驻",
                        selectedColor: "#073763",
                        color: "#666",
                        iconPath: "/amouse_tel/resource/images/tabbar/ruzhu-2.png",
                        selectedIconPath: "/amouse_tel/resource/images/tabbar/ruzhu-1.png"
                    }, {
                        pagePath: "/amouse_tel/pages/nav/index/index",
                        text: "导航",
                        selectedColor: "#073763",
                        color: "#666",
                        iconPath: "/amouse_tel/resource/images/tabbar/xcx.png",
                        selectedIconPath: "/amouse_tel/resource/images/tabbar/xcx-in.png"
                    }, {
                        pagePath: "/amouse_tel/pages/mine/index/index",
                        text: "我的",
                        selectedColor: "#073763",
                        color: "#666",
                        iconPath: "/amouse_tel/resource/images/tabbar/my.png",
                        selectedIconPath: "/amouse_tel/resource/images/tabbar/my_in.png"
                    } ], l(s), a.globalData.navbar = s;
                } else s.tabbars = e.data.data, l(s), a.globalData.navbar = s;
            },
            fail: function(e) {
                s.tabbars = [ {
                    pagePath: "/amouse_tel/pages/tel/index/index",
                    text: "首页",
                    selectedColor: "#073763",
                    color: "#666",
                    iconPath: "/amouse_tel/resource/images/tabbar/dianhua.png",
                    selectedIconPath: "/amouse_tel/resource/images/tabbar/dianhua-in.png"
                }, {
                    pagePath: "/amouse_tel/pages/tel/all/allService",
                    text: "电话簿",
                    selectedColor: "#073763",
                    color: "#666",
                    iconPath: "/amouse_tel/resource/images/tabbar/fenlei-2.png",
                    selectedIconPath: "/amouse_tel/resource/images/tabbar/fenlei-1.png"
                }, {
                    pagePath: "/amouse_tel/pages/tel/enter/enter",
                    text: "入驻",
                    selectedColor: "#073763",
                    color: "#666",
                    iconPath: "/amouse_tel/resource/images/tabbar/ruzhu-2.png",
                    selectedIconPath: "/amouse_tel/resource/images/tabbar/ruzhu-1.png"
                }, {
                    pagePath: "/amouse_tel/pages/nav/index/index",
                    text: "导航",
                    selectedColor: "#073763",
                    color: "#666",
                    iconPath: "/amouse_tel/resource/images/tabbar/xcx.png",
                    selectedIconPath: "/amouse_tel/resource/images/tabbar/xcx-in.png"
                }, {
                    pagePath: "/amouse_tel/pages/mine/index/index",
                    text: "我的",
                    selectedColor: "#073763",
                    color: "#666",
                    iconPath: "/amouse_tel/resource/images/tabbar/my.png",
                    selectedIconPath: "/amouse_tel/resource/images/tabbar/my_in.png"
                } ], l(s), a.globalData.navbar = s;
            }
        });
    },
    siteInfo: require("siteinfo.js")
});