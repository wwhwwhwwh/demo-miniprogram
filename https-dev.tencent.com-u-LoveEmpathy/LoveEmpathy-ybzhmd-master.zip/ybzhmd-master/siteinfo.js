module.exports = {
    name: "壹佰智慧门店",
    uniacid: "版本号",
    acid: "版本号",
    multiid: "0",
    version: "1.0",
    siteroot: "https://域名/app/index.php",
    design_method: "3"
};