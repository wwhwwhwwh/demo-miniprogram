var app = getApp(), a = app.requirejs("core"), info = app.getCache("userinfo"), s = app.requirejs("wxParse/wxParse");

module.exports = {
    to_url: function(t, e) {
        var o = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "", i = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : "", n = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : "", r = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : "", s = 6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : "", l = 7 < arguments.length && void 0 !== arguments[7] ? arguments[7] : "";
        if (1 == t) e && 0 < e.length && a.jump(e); else if (2 == t) wx.navigateToMiniProgram({
            appId: o,
            path: i,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function(t) {
                console.log("打开成功");
            },
            fail: function(t) {
                a.alert("请绑定小程序");
            }
        }); else if (3 == t) a.jump(e, 1); else if (4 == t) r ? wx.makePhoneCall({
            phoneNumber: r
        }) : a.alert("电话不能为空"); else {
            if (5 != t) return;
            s && l ? a.tx_map(s, l, n) : a.alert("请完善位置信息");
        }
    },
    getArea: function() {
        a.get("area/GetArea", {}, function(t) {
            app.globalData.areas = t.areas;
        });
    },
    article_list: function(t, e, o, i, n) {
        var r = {};
        a.get("Article/Article", {
            page: e,
            ident: t,
            class_id: o
        }, function(t) {
            0 == t.code ? (t.info.info ? (0 < t.info.info.length && (r.page = e + 1, r.list = i.data.list.concat(t.info.info), 
            t.info.info.length < 10 && (r.loaded = !0)), 0 == t.info.info.length && (r.loaded = !0)) : r.loaded = !0, 
            r.show = !0, wx.setNavigationBarTitle({
                title: t.info.article_name ? decodeURIComponent(t.info.article_name) : "列表"
            }), r.class_style = t.info.class_style) : a.alert(t.msg, function() {}), "function" == typeof n && n(r);
        }, !0);
    },
    ArticleInfo: function(t, e, o, i) {
        var n = {};
        a.get("Article/ArticleInfo", {
            article_id: e,
            ident: t
        }, function(t) {
            wx.setNavigationBarTitle({
                title: t.info.title ? decodeURIComponent(t.info.title) : "详情"
            }), 0 == t.code ? (s.wxParse("wxParseData", "html", t.info.content, o, "0"), n.detail = t.info, 
            n.show = !0, "function" == typeof i && i(n)) : a.alert(t.msg);
        }, !0);
    },
    indexList: function(o) {
        var i = {}, n = 372, t = app.getCache("indexList");
        if (t) "function" == typeof o && o(t); else {
            n = wx.getSystemInfoSync().windowWidth;
            a.get("index/index", {}, function(t) {
                if (0 == t.code) {
                    var e = t.info.advert_position_list;
                    e[2].advert_position.forEach(function(t) {
                        t.high = n * t.height / t.width;
                    }), i.advert_position = e[2].advert_position, i.navigation = t.info.advert_position_list[1], 
                    i.adv = t.info.advert_position_list[0], i.GoodsList = t.info.goods_list, i.adv_height = "undefined" != t.info.advert_height ? t.info.advert_height : "188", 
                    i.show = !0, app.setCache("indexList", i, 10), "function" == typeof o && o(i);
                } else a.alert(t.msg);
            }, !0);
        }
    },
    ImageInfo: function(t, e, o, i, n) {
        var r = {};
        a.get("Album/Album", {
            page: e,
            ident: t,
            group_id: o
        }, function(t) {
            0 == t.code ? (t.info.info ? (0 < t.info.info.length && (r.page = e + 1, r.list = i.data.list.concat(t.info.info), 
            t.info.info.length < 10 && (r.loaded = !0)), 0 == t.info.info.length && (r.loaded = !0)) : r.loaded = !0, 
            r.show = !0, wx.setNavigationBarTitle({
                title: t.info.group_name ? t.info.group_name : "相册"
            })) : a.alert(t.msg, function() {}), "function" == typeof n && n(r);
        }, !0);
    },
    indexMod: function(o, e) {
        var i = this, n = {}, r = wx.getSystemInfoSync().windowWidth, t = app.getCache("indexMod");
        if (t) "function" == typeof e && e(t); else {
            r = wx.getSystemInfoSync().windowWidth;
            a.get("index/modindex", {}, function(t) {
                "string" == typeof t && (t = a.json_parse(t)), console.log(t), 0 == t.code ? (t.info.all_data.forEach(function(t, e) {
                    "advert" == t.type && (t.high = r * t.ly_height / t.ly_width), "banner" == t.type && (t.high = r * t.ly_height / 10), 
                    "position" == t.type && 2 == t.is_display && o.setData({
                        "markers[0].latitude": t.latitude,
                        "markers[0].longitude": t.longitude,
                        "markers[0].title": t.position_name
                    }), "rich_text" == t.type && (s.wxParse("wxParseData_" + t.time_key, "html", t.content, o, "0"), 
                    t.wxParseData = o.data["wxParseData_" + t.time_key].nodes), "edit_piclist" == t.type && (t.arr = a.str(t.list)), 
                    t.type, "miaosha" == t.type && i.miaosha(o, t.list, e), "comment" == t.type && i.comment(o, t.is_display), 
                    "edit_music" == t.type && i.play_music(t.name, t.author, t.imgurl, t.url), "edit_form" == t.type && t.param && "" != t.param && 0 != t.param && (i.get_form_list(2, t.param, o), 
                    n.id = t.param);
                }), n.index = t.info.all_data, n.show = !0, app.setCache("indexMod", n, 1), "function" == typeof e && e(n)) : a.alert(t.msg ? t.msg : "数据异常");
            }, !0);
        }
    },
    power: function(t, o, e) {
        var i = this, n = {}, r = wx.getSystemInfoSync().windowWidth;
        a.get("index/power", {
            id: t
        }, function(t) {
            0 == t.code ? (wx.setNavigationBarTitle({
                title: t.info.name ? t.info.name : "万能页面"
            }), t.info.all_data.forEach(function(t, e) {
                "advert" == t.type && (t.high = r * t.ly_height / t.ly_width), "banner" == t.type && (t.high = r * t.ly_height / 10), 
                "position" == t.type && 2 == t.is_display && o.setData({
                    "markers[0].latitude": t.latitude,
                    "markers[0].longitude": t.longitude,
                    "markers[0].title": t.position_name
                }), "rich_text" == t.type && (s.wxParse("wxParseData_" + t.time_key, "html", t.content, o, "0"), 
                t.wxParseData = o.data["wxParseData_" + t.time_key].nodes), "edit_piclist" == t.type && (t.arr = a.str(t.list)), 
                t.type, "miaosha" == t.type && i.miaosha(o, t.list, e), "comment" == t.type && i.comment(o, t.is_display), 
                "edit_music" == t.type && i.play_music(t.name, t.author, t.imgurl, t.url), "edit_form" == t.type && t.param && "" != t.param && 0 != t.param && (i.get_form_list(3, t.param, o), 
                n.id = t.param);
            }), n.index = t.info.all_data, n.show = !0, n.page = t.info.page, "function" == typeof e && e(n)) : a.alert(t.msg);
        }, !0);
    },
    play_music: function(t, a, e, o) {
        if (o && "" != o) {
            var i = wx.getBackgroundAudioManager();
            i.title = t, i.singer = a, i.coverImgUrl = e, i.src = o;
        }
    },
    comment: function(o, t) {
        a.get("Index/CommentList", {
            num: t
        }, function(t) {
            if (0 == t.code) {
                var a = {
                    sroce: t.info.sroce,
                    count: t.info.count
                };
                a.commentlist = t.info.info, o.setData(a);
            } else e.alert(t.msg);
        });
    },
    miaosha: function(i, t, n) {
        var o = [], e = "";
        0 < t.length && (t.forEach(function(t, a) {
            e = e + t.param + ",";
        }), e = e.substr(0, e.length - 1), a.get("Miaosha/msGoodsmodel", {
            ids: e
        }, function(t) {
            if (0 == t.code) {
                0 < t.info.length && (o = t.info, t.info.forEach(function(t, e) {
                    if (0 < t.status) {
                        if (2 == t.status) var o = t.etime; else if (1 == t.status) o = t.stime;
                        a.Countdown(o, function(t) {
                            var a = i.data.mscountDownList ? i.data.mscountDownList : {};
                            a[n] || (a[n] = []), a[n][e] = t, i.setData({
                                mscountDownList: a
                            });
                        });
                    }
                }));
                var e = i.data.miaoshalist ? i.data.miaoshalist : {};
                e[n] || (e[n] = []), e[n] = o, i.setData({
                    miaoshalist: e
                });
            }
        }));
    },
    Article_Class: function(t, e) {
        var o = {};
        wx.getSystemInfo({
            success: function(t) {
                var a = .5 * (t.windowWidth - 20) * .9;
                e.setData({
                    height: a
                });
            }
        }), a.get("Article/ArticleClass", {
            ident_class: t
        }, function(t) {
            0 == t.code ? t.info && (o.list = t.info, o.show = !0, e.setData(o)) : a.alert(t.msg);
        }, !0);
    },
    Album_Class: function(t, e) {
        var o = {};
        wx.getSystemInfo({
            success: function(t) {
                var a = .5 * (t.windowWidth - 20) * .9;
                e.setData({
                    height: a
                });
            }
        }), a.get("Album/AlbumImages", {
            ident_class: t
        }, function(t) {
            0 == t.code ? t.info && (o.list = t.info, o.show = !0, e.setData(o)) : a.alert(t.msg);
        }, !0);
    },
    formSubmit: function(o, t) {
        console.log(t);
        var e = this, i = t.detail.value, n = i.id + "";
        console.log(n), console.log(o.data.power_form[n + ""]);
        var r = o.data.power_form[n + ""].form;
        delete i.id, e.validate(i, r, function(t) {
            0 == t && (i = JSON.stringify(e.to_str(i, r)), a.loading("正在提交中..."), a.post("index/submitform", {
                data: i,
                form: JSON.stringify(r),
                bus_form_id: n,
                user_id: app.getCache("userinfo").uid
            }, function(t) {
                if (a.hideLoading(), 0 == t.code) {
                    var e = o.data.power_form;
                    e[n].form = r, o.setData({
                        power_form: e,
                        form_data: {}
                    }), a.success("提交成功");
                } else a.alert(t.msg);
            }));
        });
    },
    bindPickerChange: function(t, a) {
        console.log(a);
        var e = a.target.id, o = t.data.form_data ? t.data.form_data : {};
        if ("region" == a.currentTarget.dataset.type) {
            var i = "";
            a.detail.value.forEach(function(t) {
                "" == i ? i = t : i += " " + t;
            }), o[e] = i;
        } else o[e] = a.detail.value;
        t.setData({
            form_data: o
        }), console.log(t.data.form_data);
    },
    listen_time_two: function(t, e) {
        console.log(e);
        var o = e.target.id, i = e.currentTarget.dataset.key, n = t.data.form_data ? t.data.form_data : {};
        if (n[o + "_" + i] = e.detail.value, 2 == i && n[o + "_1"] && n[o + "_2"]) {
            if (a.time_str(n[o + "_1"]) >= a.time_str(n[o + "_2"])) return void a.error("不小于开始时间");
            n[o] = n[o + "_1"] + "," + n[o + "_2"];
        }
        t.setData({
            form_data: n
        });
    },
    Image_del: function(e, t) {
        var o = a.pdata(t).index, i = a.pdata(t).key, n = e.data.form_data;
        a.removeByValue(n[i], o, function(t) {
            n[i] = t, e.setData({
                form_data: n
            });
        });
    },
    get_form_list: function(i, n, r) {
        var s = {}, l = "提交";
        a.get("index/form", {
            id: n
        }, function(t) {
            var e = t.info.list;
            if (0 == t.code) {
                if (1 == i && (wx.setNavigationBarTitle({
                    title: t.info.title ? decodeURIComponent(t.info.title) : "万能表单"
                }), 0 == e.length)) return void a.alert("表单内容为空");
                e.forEach(function(t) {
                    "picker" == t.module && (s[t.name] = 0), "time_one" == t.module && (s[t.name] = t.default), 
                    "time_two" == t.module && (s[t.name + "_1"] = t.default1, s[t.name + "_2"] = t.default2, 
                    t.default1 && t.default2 ? s[t.name] = t.default1 + "," + t.default2 : s[t.name] = ""), 
                    "pic_arr" == t.module && (s[t.name] = []), "region" == t.module && (s[t.name] = t.default, 
                    s[t.name + "_multi"] = [ 0, 0, 0 ]), "button" == t.module && (l = t.title);
                }), 1 == i && r.setData({
                    show: !0
                }), console.log("-------------------"), console.log(r.data);
                var o = r.data.power_form ? r.data.power_form : {};
                o[n + ""] = {
                    data: s,
                    button_name: l,
                    form: e,
                    form_id: n
                }, console.log(o), r.setData({
                    power_form: o
                });
            } else a.alert(t.msg);
        }, !0);
    },
    to_str: function(e, o) {
        var t = [];
        for (var i in e) t.push({
            name: i,
            value: e[i]
        });
        return 0 < t.length ? (t.forEach(function(t) {
            for (var a = 0; a < o.length; a++) t.name == o[a].name && "checkbox" == o[a].module && (e[t.name] = e[t.name].join(","));
        }), e) : void a.error("表单不能为空");
    },
    validate: function(t, e, o) {
        var i = [], n = 0;
        for (var r in t) i.push({
            name: r,
            value: t[r]
        });
        if (0 < i.length) {
            for (var s = 0; s < i.length; s++) {
                var l = this.in_array(i[s].name, i[s].value, e);
                if (1 == l.code) {
                    n++, a.alert(l.msg);
                    break;
                }
            }
            "function" == typeof o && o(n);
        } else a.alert("表单不能为空");
    },
    in_array: function(a, e, t) {
        var o = {
            code: 0
        };
        return t.forEach(function(t) {
            if (t.name == a && t.empty && (!e || 0 == e.length)) return o.code = 1, o.msg = t.title + "不能为空", 
            o;
        }), o;
    },
    upload: function(a, e, o) {
        var i = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : 0, n = this;
        wx.showActionSheet({
            itemList: [ "从相册中选择", "拍照" ],
            itemColor: "#f7982a",
            success: function(t) {
                t.cancel || (0 == t.tapIndex ? n.chooseWxImage("album", a, e, o, i) : 1 == t.tapIndex && n.chooseWxImage("camera", a, e, o, i));
            }
        });
    },
    chooseWxImage: function(t, e, o, i, n) {
        var r = getApp().siteInfo, s = e.data.form_data ? e.data.form_data : {}, l = r.siteroot + "?i=" + r.uniacid + "&t=undefined&v=" + r.version + "&from=wxapp&c=entry&a=wxapp&do=index_uploadFile&path=" + i + "&m=yb_shop&sign=5201314";
        s[o] = s[o] ? s[o] : [], wx.chooseImage({
            sizeType: [ "original", "compressed" ],
            sourceType: [ t ],
            success: function(t) {
                0 == n ? t.tempFilePaths.forEach(function(t) {
                    wx.uploadFile({
                        url: l,
                        filePath: t,
                        name: "file_upload",
                        success: function(t) {
                            console.log(t.data), null != t.data && "" != t.data ? (s[o] = s[o].concat(t.data), 
                            e.setData({
                                form_data: s
                            })) : a.error(data.msg);
                        }
                    });
                }) : wx.uploadFile({
                    url: l,
                    filePath: t.tempFilePaths[0],
                    name: "file_upload",
                    success: function(t) {
                        null != t.data && "" != t.data ? (console.log(t.data), s[o] = t.data, e.setData({
                            form_data: s
                        })) : a.error("上传失败，请重试");
                    }
                });
            }
        });
    },
    versionfunegt: function(t, a) {
        var e = t.replace(".", ""), o = a.replace(".", "");
        return !(parseFloat(e) < parseFloat(o));
    }
};