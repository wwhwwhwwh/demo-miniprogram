var barcode = require("./barcode");

function convert_length(e) {
    return Math.round(wx.getSystemInfoSync().windowWidth * e / 750);
}

function barc(e, t, n, r) {
    barcode.code128(wx.createCanvasContext(e), t, convert_length(n), convert_length(r));
}

function qrc(e, t, n, r) {
    qrcode.api.draw(t, {
        ctx: wx.createCanvasContext(e),
        width: convert_length(n),
        height: convert_length(r)
    });
}

module.exports = {
    barcode: barc
};