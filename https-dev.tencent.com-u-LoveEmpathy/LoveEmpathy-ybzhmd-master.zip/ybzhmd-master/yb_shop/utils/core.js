var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, t = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(t) {
    return void 0 === t ? "undefined" : _typeof(t);
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : _typeof(t);
}, e = require("./check");

module.exports = {
    toQueryPair: function(t, e) {
        return void 0 === e ? t : t + "=" + encodeURIComponent(null === e ? "" : String(e));
    },
    getUrl: function(o, n) {
        o = o.replace(/\//gi, "/");
        var i = getApp().globalData.api + "api/" + o;
        return n && ("object" == (void 0 === n ? "undefined" : t(n)) ? i += "?app_id=" + getApp().globalData.appid + "&" + e.param(n) : "string" == typeof n && (i += "&" + n)), 
        i;
    },
    json: function(t, o, n, i, a, r) {
        var s = getApp(), u = (s.getCache("userinfo"), s.requirejs("core"));
        i && u.loading();
        var c = {
            url: a ? this.getUrl(t) : this.getUrl(t, o),
            method: a ? "POST" : "GET",
            header: {
                "Content-type": a ? "application/x-www-form-urlencoded" : "application/json"
            }
        };
        a && (c.data = e.param(o)), n && (c.success = function(t) {
            if (i && u.hideLoading(), "request:ok" == t.errMsg) {
                if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void u.error("服务器错误！");
                n(t.data);
            } else this.alert(t.errMsg);
        }), c.fail = function(t) {
            that.alert(t.errMsg);
        }, wx.request(c), console.log(c);
    },
    post: function(t, e, o, n) {
        var i = this, a = t.split("/");
        a = a[0] + "_" + a[1], n && i.loading(), getApp().util.request({
            url: "entry/wxapp/" + a,
            data: e,
            method: "POST",
            success: function(t) {
                if (n && i.hideLoading(), "request:ok" == t.errMsg) {
                    if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void i.error("请求错误002");
                    if ("" == t.data) return void console.log("请求异常！");
                    var e = t.data;
                    "string" == typeof e && (console.log(void 0 === e ? "undefined" : _typeof(e)), e = i.json_parse(e)), 
                    o(e);
                } else i.alert(t.errMsg);
            },
            fail: function(t) {
                i.alert(t.errMsg);
            }
        });
    },
    get: function(t, e, o, n) {
        var i = this, a = t.split("/");
        a = a[0] + "_" + a[1], n && i.loading(), getApp().util.request({
            url: "entry/wxapp/" + a,
            data: e,
            success: function(t) {
                if (n && i.hideLoading(), "request:ok" == t.errMsg) {
                    if ("string" == typeof t.data && 0 <= t.data.indexOf("html") && 0 <= t.data.indexOf("head") && 0 <= t.data.indexOf("body")) return void i.error("请求错误001");
                    if ("" == t.data) return void console.log("请求异常！");
                    var e = t.data;
                    "string" == typeof e && (console.log(void 0 === e ? "undefined" : _typeof(e)), e = i.json_parse(e)), 
                    o(e);
                } else i.alert(t.errMsg);
            },
            fail: function(t) {
                n && i.hideLoading(), i.alert(t.errMsg);
            }
        });
    },
    alert: function(e, o) {
        "object" === (void 0 === e ? "undefined" : t(e)) && (e = JSON.stringify(e)), wx.showModal({
            title: "提示",
            content: e,
            showCancel: !1,
            success: function(t) {
                t.confirm && "function" == typeof o && o();
            }
        });
    },
    confirm: function(e, o, n) {
        "object" === (void 0 === e ? "undefined" : t(e)) && (e = JSON.stringify(e)), wx.showModal({
            title: "提示",
            content: e,
            showCancel: !0,
            success: function(t) {
                t.confirm ? "function" == typeof o && o() : "function" == typeof n && n();
            }
        });
    },
    loading: function(t) {
        void 0 !== t && "" != t || (t = "加载中"), wx.showToast({
            title: t,
            icon: "loading",
            duration: 5e6
        });
    },
    hideLoading: function() {
        wx.hideToast();
    },
    toast: function(t, e) {
        e || (e = "loading"), wx.showToast({
            title: t,
            icon: e,
            duration: 1e3
        });
    },
    warning: function(t) {
        wx.showToast({
            title: t,
            image: "/yb_shop/static/images/icon-warning.png",
            duration: 2e3
        });
    },
    error: function(t) {
        wx.showToast({
            title: t,
            icon: "success",
            image: "/yb_shop/static/images/x.png",
            duration: 2e3
        });
    },
    success: function(t) {
        wx.showToast({
            title: t,
            icon: "success",
            duration: 1e3
        });
    },
    pdata: function(t) {
        return t.currentTarget.dataset;
    },
    data: function(t) {
        return t.target.dataset;
    },
    phone: function(t) {
        var e = this.pdata(t).phone;
        wx.makePhoneCall({
            phoneNumber: e
        });
    },
    time_format: function(t) {
        var e = new Date(1e3 * t);
        return e.getFullYear() + "-" + (e.getMonth() + 1) + "-" + e.getDate() + " " + e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds();
    },
    time_str: function(t) {
        return t = (t = t.substring(0, 19)).replace(/-/g, "/"), new Date(t).getTime() / 1e3;
    },
    Countdown: function(t, u) {
        var e = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 0, c = {}, l = "interval" + e, f = t - Date.parse(new Date()) / 1e3;
        f <= 0 && (c.show_time = !1, u(c)), l = setInterval(function() {
            var t = f, e = Math.floor(t / 3600 / 24), o = e.toString();
            1 == o.length && (o = "0" + o);
            var n = Math.floor((t - 3600 * e * 24) / 3600), i = n.toString();
            1 == i.length && (i = "0" + i);
            var a = Math.floor((t - 3600 * e * 24 - 3600 * n) / 60), r = a.toString();
            1 == r.length && (r = "0" + r);
            var s = (t - 3600 * e * 24 - 3600 * n - 60 * a).toString();
            1 == s.length && (s = "0" + s), c.countDownDay = o, c.countDownHour = i, c.countDownMinute = r, 
            c.countDownSecond = s, "function" == typeof u && u(c), --f < 0 && (clearInterval(l), 
            wx.showToast({
                title: "活动已结束"
            }), c.countDownDay = "0", c.countDownHour = "0", c.countDownMinute = "0", c.countDownSecond = "0", 
            c.show_time = !1, "function" == typeof u && u(c));
        }.bind(this), 1e3);
    },
    json_parse: function(t) {
        var e = t;
        if ("object" != (void 0 === (e = e.replace(" ", "")) ? "undefined" : _typeof(e))) return e = e.replace(/\ufeff/g, ""), 
        JSON.parse(e);
    },
    str: function(t) {
        return JSON.stringify(t);
    },
    tx_map: function(e, o, n) {
        e = parseFloat(e), o = parseFloat(o);
        var t = this;
        getApp().getCache("map") ? wx.openLocation({
            latitude: e,
            longitude: o,
            scale: 28,
            name: n
        }) : wx.getLocation({
            type: "wgs84",
            success: function(t) {
                console.log(t), getApp().setCache("map", t, 1200);
                t.latitude, t.longitude;
                wx.openLocation({
                    latitude: e,
                    longitude: o,
                    scale: 28,
                    name: n
                });
            },
            fail: function() {
                t.alert("未授权位置信息");
            }
        });
    },
    previewImage: function(t, e, o) {
        var n = [];
        (e = JSON.parse(e)).forEach(function(t, e) {
            n[e] = t[o];
        }), wx.previewImage({
            current: t,
            urls: n
        });
    },
    Clipboard: function(t) {
        wx.setClipboardData({
            data: t,
            success: function(t) {
                wx.getClipboardData({
                    success: function(t) {}
                });
            }
        });
    },
    jump: function(e, t) {
        console.log(e), t = t && "" != t ? t : 1, 1 == (t = "/yb_shop/pages/index/index" === e ? 3 : t) ? wx.navigateTo({
            url: e,
            fail: function(t) {
                0 <= t.errMsg.indexOf("tabbar") && wx.switchTab({
                    url: e
                });
            }
        }) : 2 == t ? wx.redirectTo({
            url: e
        }) : 3 == t ? wx.reLaunch({
            url: e
        }) : 4 == t ? wx.switchTab({
            url: e
        }) : 5 == t && wx.navigateBack();
    },
    ReName: function(t) {
        wx.setNavigationBarTitle({
            title: t || ""
        });
    },
    removeByValue: function(t, e, o) {
        for (var n = -1, i = 0; i < t.length; i++) if (console.log(t[i]), t[i] == e) {
            n = i;
            break;
        }
        t.splice(n, 1), "function" == typeof o && o(t);
    },
    setting: function() {
        wx.setNavigationBarColor({
            frontColor: getApp().page.text_color,
            backgroundColor: getApp().page.nv_color,
            animation: {
                duration: 0,
                timingFunc: "easeIn"
            }
        }), getApp().check_is_tabbar();
    },
    compatible_phonex: function(e) {
        wx.getSystemInfo({
            success: function(t) {
                "iphonrx" == t.model && e.setData({
                    isIphoneX: !0
                });
            }
        });
    },
    menu_url: function(t) {
        var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1, o = this, n = o.pdata(t), i = (t = n.key, 
        n.url ? n.url : ""), a = n.appid ? n.appid : "", r = n.path ? n.path : "", s = n.title ? n.title : "", u = n.phone ? n.phone : "", c = n.lat ? n.lat : "", l = n.lng ? n.lng : "";
        if (console.log(n), 1 == t) i && 0 < i.length && o.jump(i, e); else if (2 == t) wx.navigateToMiniProgram({
            appId: a,
            path: r,
            extraData: {
                foo: "bar"
            },
            envVersion: "release",
            success: function(t) {
                console.log("打开成功");
            },
            fail: function(t) {
                o.alert("请绑定小程序");
            }
        }); else if (3 == t) o.jump(i, 1); else if (4 == t) u ? wx.makePhoneCall({
            phoneNumber: u
        }) : o.alert("电话不能为空"); else {
            if (5 != t) return;
            c && l ? o.tx_map(c, l, s) : o.alert("请完善位置信息");
        }
    }
};