var app = getApp(), a = app.requirejs("core");

Page({
    data: {
        addressData: {},
        address: !1,
        show: !1,
        freight: 0,
        totalPrice: 0
    },
    onLoad: function(o) {
        wx.showLoading({
            title: "正在加载",
            mask: !0
        }), this.setData({
            address: app.goodsInfo.address,
            goodsNum: app.goodsInfo.num,
            goodsInfo: app.goodsInfo,
            goodsPrice: app.goodsInfo.goodsPrice,
            totalPrice: app.goodsInfo.goodsPrice * app.goodsInfo.num,
            show: !0
        }), wx.hideLoading();
    },
    onShow: function(o) {
        wx.showLoading({
            title: "正在加载",
            mask: !0
        });
        var a = app.getCache("orderAddress");
        a && (a.userName = a.consigner, a.telNumber = a.phone, this.setData({
            address: a
        })), wx.hideLoading();
    },
    showAddressList: function() {
        wx.navigateTo({
            url: "/yb_shop/pages/member/address/select"
        });
    },
    goToPay: function() {
        var o = this;
        if (!this.data.address) return app.showToast(this, "请选择地址"), !1;
        var e = {
            pid: o.data.goodsInfo.groupPid,
            isGroup: o.data.goodsInfo.buyType,
            gid: o.data.goodsInfo.id,
            goodsNum: o.data.goodsNum,
            limitTime: o.data.goodsInfo.limitTime,
            address: JSON.stringify(o.data.address),
            totalPrice: o.data.goodsInfo.goodsPrice * o.data.goodsNum + parseFloat(o.data.freight),
            uid: app.getCache("userinfo").uid
        };
        this.data.oid || (wx.showLoading({
            title: "正在提交",
            mask: !0
        }), a.get("Pintuan/ptCreateOrder", e, function(s) {
            wx.hideLoading(), 0 == s.code ? (o.setData({
                oid: s.info
            }), a.get("Pintuan/ptPay", {
                oid: s.info,
                openid: getApp().getCache("userinfo").openid
            }, function(o) {
                0 == o.code ? wx.requestPayment({
                    timeStamp: o.info.timeStamp,
                    nonceStr: o.info.nonceStr,
                    package: o.info.package,
                    signType: "MD5",
                    paySign: o.info.paySign,
                    success: function(o) {
                        console.log(o), 1 == e.isGroup ? wx.redirectTo({
                            url: "/yb_shop/pages/pintuan/pages/group/detail?id=" + s.info
                        }) : wx.redirectTo({
                            url: "/yb_shop/pages/pintuan/pages/orders/index"
                        });
                    },
                    fail: function(o) {
                        a.alert("您已取消了支付", function() {
                            wx.redirectTo({
                                url: "/yb_shop/pages/pintuan/pages/orders/index"
                            });
                        });
                    }
                }) : a.alert(o.msg, function() {
                    wx.redirectTo({
                        url: "/yb_shop/pages/pintuan/pages/orders/index"
                    });
                });
            })) : a.alert(s.msg);
        }));
    },
    minus: function() {
        var o = 1 < this.data.goodsNum ? --this.data.goodsNum : 1, a = this.data.goodsPrice * o;
        this.setData({
            goodsNum: o,
            totalPrice: a.toFixed(2)
        });
    },
    plus: function() {
        var o = ++this.data.goodsNum, a = this.data.goodsPrice * o;
        this.setData({
            goodsNum: o,
            totalPrice: a.toFixed(2)
        });
    }
});