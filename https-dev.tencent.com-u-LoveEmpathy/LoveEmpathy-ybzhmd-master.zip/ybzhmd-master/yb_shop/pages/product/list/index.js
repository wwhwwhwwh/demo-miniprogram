var t = getApp(), c = t.requirejs("api/index"), a = t.requirejs("core");

Page({
    data: {
        route: "find",
        menu: t.tabBar,
        menu_show: !1,
        loaded: !1,
        list: [],
        page: 1,
        class_id: "0",
        cate_index: "",
        cate: [],
        class_style: 2
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    onLoad: function(t) {
        a.compatible_phonex(this), a.setting(), null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), this.setData({
            menu: getApp().tabBar,
            class_id: t.id ? t.id : "0"
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        }), this.getlist(), this.initCategory();
    },
    cate_select: function(t) {
        console.log(t);
        var e = this, i = (e.data.cate, a.pdata(t)), n = {};
        console.log(i), n.cate_index = i.index, n.class_id = i.id + "", n.list = [], n.page = 1, 
        n.loaded = !1, console.log(n), e.setData(n), e.getlist();
    },
    initCategory: function() {
        var e = this;
        a.get("product/productClass", {}, function(t) {
            e.setData({
                cate: t.info
            });
        });
    },
    getlist: function() {
        var e = this, t = e.data.class_id, i = e.data.page, n = {};
        a.get("product/product_list", {
            page: i,
            class_id: t
        }, function(t) {
            0 == t.code ? (t.info ? (0 < t.info.length && (n.page = i + 1, n.list = e.data.list.concat(t.info), 
            t.info.length < 10 && (n.loaded = !0)), 0 == t.info.length && (n.loaded = !0)) : n.loaded = !0, 
            n.show = !0, wx.setNavigationBarTitle({
                title: t.info.class_name ? decodeURIComponent(t.info.class_name) : "产品列表"
            }), e.setData(n)) : a.alert(t.msg, function() {});
        }, !0);
    },
    onPullDownRefresh: function() {
        this.setData({
            list: [],
            page: 1,
            loaded: !1
        }), this.getlist(), this.initCategory(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {
        console.log("加载更多"), this.data.loaded || this.getlist();
    },
    to_url: function(t) {
        var e = a.pdata(t), i = "";
        i = e.link ? "/yb_shop/pages/web/index?url=" + escape(e.link) + "&name=" + e.name : "/yb_shop/pages/find_info/index?id=" + e.id, 
        a.jump(i);
    },
    onShareAppMessage: function() {}
});