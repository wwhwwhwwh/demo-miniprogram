var t = getApp(), e = t.requirejs("api/index"), core = t.requirejs("core"), wxParse = t.requirejs("wxParse/wxParse");

Page({
    data: {
        route: "find_info",
        menu: t.tabBar,
        menu_show: !1,
        show: !1,
        use_wxParse: !0
    },
    menu_url: function(t) {
        core.menu_url(t, 2);
    },
    onLoad: function(e) {
        null != e && null != e && this.setData({
            tabbar_index: e.tabbar_index ? e.tabbar_index : -1
        }), core.setting(), this.setData({
            menu: getApp().tabBar
        }), t.isInArray(getApp().tabBar.list, this.data.route) && this.setData({
            menu_show: !0
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        });
        this.setData({
            id: e.id
        }), this.getinfo();
    },
    getinfo: function() {
        var e = this, t = e.data.id, a = {};
        core.get("product/product_info", {
            id: t
        }, function(t) {
            if (wx.setNavigationBarTitle({
                title: t.info.title ? decodeURIComponent(t.info.title) : "产品详情"
            }), 0 == t.code) {
                try {
                    wxParse.wxParse("wxParseData", "html", t.info.content, e, "0"), a.use_wxParse = !0, 
                    console.log("use wxParse !!!");
                } catch (t) {
                    a.use_wxParse = !1, console.log("not use wxParse !!!");
                }
                a.detail = t.info, a.show = !0, e.setData(a);
            } else core.alert(t.msg);
        }, !0);
    },
    onShow: function() {},
    onPullDownRefresh: function() {
        this.getinfo(), wx.stopPullDownRefresh();
    },
    onShareAppMessage: function() {
        return {
            title: this.data.detail.title,
            path: "/yb_shop/pages/product/info/index?id=" + this.data.detail.id
        };
    }
});