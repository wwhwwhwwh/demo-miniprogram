var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, t = getApp(), a = t.requirejs("core"), c = t.requirejs("api/index"), e = (t.requirejs("icons"), 
t.requirejs("wxParse/wxParse"));

Page({
    data: {
        official_account: wx.canIUse("official-account"),
        route: "index",
        menu: t.tabBar,
        menu_show: !1,
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 500,
        circular: !0,
        icons: t.requirejs("icons"),
        total: 0,
        page: 1,
        show: !1,
        display: !0,
        hotimg: "/yb_shop/static/images/hotdot.jpg",
        notification: "/yb_shop/static/images/notification.png",
        page_bg_img: "",
        page_bg_color: "",
        showtabbar: !1,
        tabbar_index: 0,
        markers: [ {
            iconPath: "/yb_shop/static/images/red_position_icon.png",
            title: "地理位置",
            latitude: 34.62845,
            longitude: 112.42821,
            width: 50,
            height: 50
        } ],
        video: !1,
        config: t.config,
        page_config: t.page,
        is_copyright: !1,
        bookData: {},
        default_pic: "/yb_shop/static/images/add_pic.jpg",
        form: [],
        data: {},
        version: t.version,
        openImg: !1
    },
    openImg_show: function() {
        this.setData({
            openImg: !1
        }), t.setCache("OpenImgShowed", !0, 86400);
        var e = this.data.showtabbar;
        this.setData({
            showtabbar: !1
        });
        var a = this;
        setTimeout(function() {
            a.setData({
                showtabbar: e
            });
        }, 30);
    },
    onGotUserInfo: function(e) {
        console.log(e);
        var a = this, o = t.getCache("userinfo");
        a.setData({
            display: !1
        }), o || t.getUserInfo(e.detail.userInfo, function(t) {
            1e3 != t ? null != getApp().page.open_img.imgurl && null != getApp().page.open_img.imgurl && 0 < getApp().page.open_img.imgurl.length && a.setData({
                openImg: !0
            }) : a.setData({
                display: !0
            });
        }, e.detail.encryptedData, e.detail.iv);
    },
    formSubmit: function(t) {
        var e = {
            currentTarget: {
                dataset: {}
            }
        }, o = t.detail.value;
        e.currentTarget.dataset = o, a.menu_url(e, 1);
        var i = {};
        i.formid = t.detail.formId, i.openid = getApp().getCache("userinfo").openid, i.username = getApp().getCache("userinfo").nickName, 
        a.get("Market/getFormid", i, function(t) {
            console.log(t);
        });
    },
    to_url: function(t) {
        a.menu_url(t, 1);
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    onLoad: function(e) {
        if (a.compatible_phonex(this), e && e.pid) {
            t.get_user_name(e.pid, this);
            this.setData({
                pid: e.pid
            }), t.set_share_pid(e.pid), t.setCache("pid", e.pid);
        }
        var n = this;
        getApp().getExtC(function() {
            getApp().get_menu(function(e) {
                n.setData({
                    menu: getApp().tabBar,
                    page_config: getApp().page
                }), wx.setNavigationBarTitle({
                    title: getApp().page.name ? decodeURIComponent(getApp().page.name) : "首页"
                }), wx.setBackgroundColor && wx.setBackgroundColor({
                    backgroundColor: getApp().page.bg_color ? getApp().page.bg_color : "#f2f3f4"
                }), n.setData({
                    page_bg_img: getApp().page.bg_img ? getApp().page.bg_img : "",
                    page_bg_color: getApp().page.bg_color ? getApp().page.bg_color : ""
                }), c.getArea(), n.getList(), a.setting(), t.getCache("userinfo") && n.setData({
                    display: !1
                });
                var o = t.getCache("OpenImgShowed"), i = void 0 === o ? "undefined" : _typeof(o);
                n.data.display || "string" != i && "undefined" != i ? n.setData({
                    openImg: !1
                }) : null != getApp().page.open_img.imgurl && null != getApp().page.open_img.imgurl && 0 < getApp().page.open_img.imgurl.length && n.setData({
                    openImg: !0
                });
            });
        });
    },
    formBook: function(t) {
        var e = this, o = t.detail.value;
        "" != o.name ? 11 == o.phone.length ? (o.user_id = getApp().getCache("userinfo").uid, 
        a.get("Index/WriteBook", o, function(t) {
            0 == t.code ? (e.setData({
                bookData: {}
            }), a.success("提交成功")) : a.alert(t.msg);
        })) : a.error("手机号格式不正确") : a.error("姓名不能为空");
    },
    listenerTime: function(t) {
        this.setData({
            "bookData.book_time": t.detail.value
        });
    },
    onShow: function() {},
    getList: function() {
        var e = this;
        c.indexMod(e, function(t) {
            e.setData(t);
        });
    },
    onPullDownRefresh: function() {
        this.onLoad(), wx.stopPullDownRefresh();
    },
    navigate: function(t) {
        var e = a.pdata(t);
        e.name && e.lat && e.lng ? a.tx_map(e.lat, e.lng, e.name) : a.toast("不能获取到该位置");
    },
    phone: function(t) {
        a.phone(t);
    },
    formPower: function(t) {
        c.formSubmit(this, t);
    },
    bindPickerChange: function(t) {
        c.bindPickerChange(this, t);
    },
    listen_time_two: function(t) {
        c.listen_time_two(this, t);
    },
    chooseImageTap1: function(t) {
        var e = a.pdata(t).id;
        c.upload(this, e, "form_pic", 1);
    },
    chooseImageTap2: function(t) {
        var e = a.pdata(t).id;
        c.upload(this, e, "form_pic", 0);
    },
    Image_del: function(t) {
        c.Image_del(this, t);
    },
    previewImage: function(t) {
        var e = a.pdata(t).url, o = a.pdata(t).arr;
        a.previewImage(e, o, "imgurl");
    },
    copyright: function() {
        var t = this.data.is_copyright;
        this.setData({
            is_copyright: !t
        });
    },
    onShareAppMessage: function(t) {
        this.data;
        return {
            path: "/yb_shop/pages/index/index?pid=" + (getApp().getCache("userinfo").uid ? getApp().getCache("userinfo").uid : 0),
            success: function(t) {},
            fail: function(t) {}
        };
    },
    official_account_load: function(t) {
        console.log("official_account_load"), console.log(t);
    },
    official_account_err: function(t) {
        console.log("official_account_err"), console.log(t);
    }
});