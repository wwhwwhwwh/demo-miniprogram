var t = getApp(), a = t.requirejs("core"), c = t.requirejs("api/index"), e = (t.requirejs("icons"), 
t.requirejs("wxParse/wxParse"));

Page({
    data: {
        route: "power",
        menu: t.tabBar,
        menu_show: !1,
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 500,
        circular: !0,
        icons: t.requirejs("icons"),
        show: !1,
        display: !0,
        hotimg: "/yb_shop/static/images/hotdot.jpg",
        notification: "/yb_shop/static/images/notification.png",
        default_pic: "/yb_shop/static/images/add_pic.jpg",
        background: t.config.background,
        showtabbar: !1,
        markers: [ {
            iconPath: "/yb_shop/static/images/red_position_icon.png",
            title: "地理位置",
            latitude: 34.62845,
            longitude: 112.42821,
            width: 50,
            height: 50
        } ],
        video: !1,
        config: t.config,
        id: "0",
        bookData: {}
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    formSubmit: function(t) {
        var e = {
            currentTarget: {
                dataset: {}
            }
        }, o = t.detail.value;
        e.currentTarget.dataset = o, a.menu_url(e, 1);
        var i = {};
        i.formid = t.detail.formId, i.openid = getApp().getCache("userinfo").openid, i.username = getApp().getCache("userinfo").nickName, 
        a.get("Market/getFormid", i, function(a) {
            console.log(a);
        });
    },
    to_url: function(t) {
        a.menu_url(t, 1);
    },
    onLoad: function(t) {
        console.log(t);
        var e = this;
        null != t && null != t && e.setData({
            id: t.id,
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), getApp().get_menu(function(t) {
            e.setData({
                menu: getApp().tabBar
            }), 0 <= e.data.tabbar_index && e.setData({
                showtabbar: !!getApp().tabBar.IsDiDis && getApp().tabBar.IsDiDis
            }), e.getList(), a.setting();
        });
    },
    formBook: function(t) {
        var e = this, o = t.detail.value, i = getApp().getCache("userinfo").uid;
        if ("" != o.name) return null == i ? (a.error("请先登录"), void setTimeout(function() {
            a.jump("/yb_shop/pages/index/index", 2);
        }, 1e3)) : void (11 == o.phone.length ? (o.user_id = i, a.get("Index/WriteBook", o, function(t) {
            0 == t.code ? (e.setData({
                bookData: {}
            }), a.success("提交成功")) : a.alert(t.msg);
        })) : a.error("手机号格式不正确"));
        a.error("姓名不能为空");
    },
    onShow: function() {},
    getList: function() {
        var t = this, a = t.data.id;
        c.power(a, t, function(a) {
            console.log(a), t.setData({
                index: a.index,
                show: a.show,
                page: a.page
            }), wx.setNavigationBarColor({
                frontColor: a.page.text_color,
                backgroundColor: a.page.nv_color,
                animation: {
                    duration: 0,
                    timingFunc: "easeIn"
                }
            }), wx.setBackgroundColor && wx.setBackgroundColor({
                backgroundColor: a.page.bg_color ? a.page.bg_color : "#f2f3f4"
            });
        });
    },
    onPullDownRefresh: function() {
        this.onLoad(), wx.stopPullDownRefresh();
    },
    navigate: function(t) {
        var e = a.pdata(t);
        e.name && e.lat && e.lng ? a.tx_map(e.lat, e.lng, e.name) : a.toast("不能获取到该位置");
    },
    phone: function(t) {
        a.phone(t);
    },
    formPower: function(a) {
        c.formSubmit(this, a);
    },
    bindPickerChange: function(a) {
        c.bindPickerChange(this, a);
    },
    listen_time_two: function(a) {
        c.listen_time_two(this, a);
    },
    chooseImageTap1: function(t) {
        var e = a.pdata(t).id;
        c.upload(this, e, "form_pic", 1);
    },
    chooseImageTap2: function(t) {
        var e = a.pdata(t).id;
        c.upload(this, e, "form_pic", 0);
    },
    Image_del: function(a) {
        c.Image_del(this, a);
    },
    previewImage: function(t) {
        var e = a.pdata(t).url, o = a.pdata(t).arr;
        a.previewImage(e, o, "imgurl");
    },
    listenerTime: function(a) {
        this.setData({
            "bookData.book_time": a.detail.value
        });
    },
    onShareAppMessage: function() {
        return a.onShareAppMessage();
    }
});