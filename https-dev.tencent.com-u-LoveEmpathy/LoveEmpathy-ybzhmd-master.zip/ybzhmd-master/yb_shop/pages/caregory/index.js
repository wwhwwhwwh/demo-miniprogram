var app = getApp(), core = app.requirejs("core");

Page({
    data: {
        route: "caregory",
        menu: app.tabBar,
        menu_show: !1,
        curHdIndex: 0,
        category: {},
        cate_type: 0,
        toView: "inToView0"
    },
    menu_url: function(t) {
        core.menu_url(t, 2);
    },
    onPullDownRefresh: function() {
        this.getCategory(), wx.stopPullDownRefresh();
    },
    tabFun: function(t) {
        console.log(t);
        var e = core.data(t).id;
        console.log(e), this.setData({
            curHdIndex: e,
            toView: "inToView" + e
        });
    },
    scroll: function(t) {
        for (var e = this, o = 0, a = t.detail.scrollTop, n = e.data.category, c = 0; c < n.length && (0 == e.data.cate_type ? n[c].num = Math.ceil(n[c].cate.length / 3) : n[c].num = Math.ceil(n[c].goods_list.length / 3), 
        !(a < (o += 40 + 80 * n[c].num))); c++) ;
        e.setData({
            scrollTop: a,
            curHdIndex: c
        });
    },
    scrollToViewFn: function(t) {
        var e = t.target.dataset.id;
        this.setData({
            toView: "inToView" + e
        });
    },
    getCategory: function() {
        var e = this, o = [];
        core.get("goods/GetCate", {}, function(t) {
            0 == t.code ? (t.info.forEach(function(t) {
                t.cate && 0 != t.cate.length && o.push(t.cate_id);
            }), e.setData({
                cate_type: 1
            }), core.get("goods/CateGoods", {}, function(t) {
                0 == t.code ? (console.log(22), e.setData({
                    category: t.info
                })) : core.alert(t.msg);
            })) : core.alert(t.msg);
        });
    },
    onLoad: function(t) {
        core.compatible_phonex(this), null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), this.setData({
            menu: getApp().tabBar
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        }), core.setting(), this.getCategory();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return core.onShareAppMessage();
    }
});