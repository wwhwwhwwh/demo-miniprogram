var e = getApp(), c = e.requirejs("api/index"), r = e.requirejs("core");

Page({
    data: {
        menu: e.tabBar,
        menu_show: !1,
        showtabbar_back: !1,
        member: {},
        haslogin: !1,
        dobuy: !1,
        now_sku: {},
        num: 1,
        nowprice: 0,
        skus: [],
        isinputing: !1
    },
    menu_url: function(e) {
        r.menu_url(e, 2);
    },
    formSubmit: function(e) {
        var t = {
            currentTarget: {
                dataset: {}
            }
        }, n = e.detail.value;
        t.currentTarget.dataset = n, r.menu_url(t, 1);
        var a = {};
        a.formid = e.detail.formId, a.openid = getApp().getCache("userinfo").openid, a.username = getApp().getCache("userinfo").nickName, 
        r.get("Market/getFormid", a, function(e) {
            console.log(e);
        });
    },
    to_url: function(e) {
        r.menu_url(e, 1);
    },
    onLoad: function(e) {
        null != e && null != e && this.setData({
            tabbar_index: e.tabbar_index ? e.tabbar_index : -1
        });
        var t = 0 <= this.data.tabbar_index;
        this.setData({
            menu: getApp().tabBar,
            showtabbar: t,
            showtabbar_back: t
        });
    },
    onGotUserInfo: function(t) {
        console.log(t);
        var n = this;
        if (!(a = e.getCache("userinfo"))) {
            var a = t.detail.userInfo, o = {};
            o.haslogin = !!a, a && (o.member = a), console.log(o), n.setData({
                dd: o
            }), e.getUserInfo(t.detail.userInfo, function(e) {
                console.log("tt !!!!!!!!!!!!!"), console.log(e), n.getInfo();
            }, t.detail.encryptedData, t.detail.iv);
        }
    },
    getInfo: function() {
        var n = this, e = getApp().getCache("userinfo");
        e && (n.setData({
            member: e,
            haslogin: !0
        }), r.get("paycontent/uinfo", {
            uid: e.uid
        }, function(e) {
            if (console.log(e), 1 == e.code) {
                var t = n.data.member;
                t.expire_day = e.info.expire_day, t.isvip = e.info.isvip, console.log(t), n.setData({
                    member: t
                });
            }
        }));
    },
    getallprice: function() {
        var t = this, n = (t.data.id, {});
        r.get("paycontent/allprice", {}, function(e) {
            0 == e.code ? 0 < e.info.length && (n.skus = e.info, n.now_sku = e.info[0], n.nowprice = e.info[0].price, 
            t.setData(n)) : r.alert(e.msg);
        }, !0);
    },
    inputing: function(e) {
        console.log(e);
        var t = this.data.isinputing;
        console.log(t), this.setData({
            isinputing: !t
        });
    },
    dobuy: function(e) {
        0 < this.data.skus.length ? this.setData({
            dobuy: !0,
            showtabbar: !1
        }) : core.alert("未添加资费,暂不可购买");
    },
    hidebuy: function(e) {
        this.data.isinputing || this.setData({
            dobuy: !1,
            showtabbar: this.data.showtabbar_back
        });
    },
    choose_sku: function(e) {
        console.log(e);
        var t = e.currentTarget.dataset.index, n = this.data.skus[t], a = (n.price * this.data.num).toFixed(2);
        this.setData({
            now_sku: n,
            nowprice: a
        });
    },
    num_change: function(e) {
        console.log(e);
        var t = e.detail.value, n = (this.data.now_sku.price * t).toFixed(2);
        this.setData({
            num: t,
            nowprice: n
        });
    },
    tobuy: function(e) {
        if (this.data.num <= 0) r.error("购买数量必须大于0"); else {
            var t = this;
            this.setData({
                dobuy: !1,
                showtabbar: t.data.showtabbar_back
            }), r.loading("支付中...");
            var n = {};
            n.price_id = this.data.now_sku.id, n.num = this.data.num, n.uid = getApp().getCache("userinfo").uid, 
            n.openid = getApp().getCache("userinfo").openid, r.get("paycontent/createOrder", n, function(e) {
                0 == e.code ? wx.requestPayment({
                    timeStamp: e.info.timeStamp,
                    nonceStr: e.info.nonceStr,
                    package: e.info.package,
                    signType: "MD5",
                    paySign: e.info.paySign,
                    success: function(e) {
                        console.log(e), "requestPayment:ok" == e.errMsg ? (wx.showToast({
                            title: "支付成功！",
                            icon: "success",
                            duration: 2e3
                        }), setTimeout(function() {
                            t.getInfo(), t.getallprice();
                        }, 2e3)) : r.error("支付失败！");
                    },
                    fail: function(e) {
                        r.error("您已经取消支付！");
                    }
                }) : r.error(e.msg);
            });
        }
    },
    onShow: function() {
        this.getInfo(), this.getallprice();
    },
    relogin: function() {
        var n = this;
        wx.getSetting({
            success: function(t) {
                t.authSetting["scope.userInfo"] || wx.openSetting({
                    success: function(t) {
                        t.authSetting["scope.userInfo"] && (e.getUserInfo(), setTimeout(function() {
                            n.getInfo();
                        }, 1e3));
                    }
                });
            }
        });
    }
});