var t = getApp(), e = t.requirejs("api/index"), core = t.requirejs("core"), wxParse = t.requirejs("wxParse/wxParse");

Page({
    data: {
        route: "find_info",
        menu: t.tabBar,
        menu_show: !1,
        show: !1,
        use_wxParse: !0,
        dobuy: !1,
        page: 1,
        now_sku: {},
        num: 1,
        nowprice: 0,
        skus: [],
        isinputing: !1,
        isvip: !0,
        samegroup: [],
        loaded: !1,
        liked: !1,
        isplay: !1,
        duration: 0,
        currecttime: 0,
        timechanging: !1,
        nowtime: "00:00",
        endtime: "00:00"
    },
    menu_url: function(t) {
        core.menu_url(t, 2);
    },
    onLoad: function(e) {
        null != e && null != e && this.setData({
            tabbar_index: e.tabbar_index ? e.tabbar_index : -1
        }), core.setting(), this.setData({
            menu: getApp().tabBar
        }), t.isInArray(getApp().tabBar.list, this.data.route) && this.setData({
            menu_show: !0
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        });
        this.setData({
            id: e.id
        }), this.getinfo(), this.getlist(), this.getallprice();
    },
    inputing: function(t) {
        console.log(t);
        var e = this.data.isinputing;
        console.log(e), this.setData({
            isinputing: !e
        });
    },
    dobuy: function(t) {
        0 < this.data.skus.length ? this.setData({
            dobuy: !0
        }) : core.alert("未添加资费,暂不可购买");
    },
    hidebuy: function(t) {
        this.data.isinputing || this.setData({
            dobuy: !1
        });
    },
    choose_sku: function(t) {
        console.log(t);
        var e = t.currentTarget.dataset.index, a = this.data.skus[e], i = (a.price * this.data.num).toFixed(2);
        this.setData({
            now_sku: a,
            nowprice: i
        });
    },
    num_change: function(t) {
        console.log(t);
        var e = t.detail.value, a = (this.data.now_sku.price * e).toFixed(2);
        this.setData({
            num: e,
            nowprice: a
        });
    },
    tobuy: function(e) {
        if (this.data.num <= 0) core.error("购买数量必须大于0"); else {
            this.setData({
                dobuy: !1
            }), core.loading("支付中...");
            var a = this, i = {};
            i.content_id = this.data.detail.id, i.price_id = this.data.now_sku.id, i.num = this.data.num, 
            i.uid = t.getCache("userinfo").uid, i.openid = t.getCache("userinfo").openid, core.get("paycontent/createOrder", i, function(t) {
                0 == t.code ? wx.requestPayment({
                    timeStamp: t.info.timeStamp,
                    nonceStr: t.info.nonceStr,
                    package: t.info.package,
                    signType: "MD5",
                    paySign: t.info.paySign,
                    success: function(t) {
                        console.log(t), "requestPayment:ok" == t.errMsg ? (wx.showToast({
                            title: "支付成功！",
                            icon: "success",
                            duration: 2e3
                        }), a.setData({
                            page: 1
                        }), setTimeout(function() {
                            a.getinfo(), a.getlist(), a.getallprice();
                        }, 2e3)) : core.error("支付失败！");
                    },
                    fail: function(t) {
                        core.error("您已经取消支付！");
                    }
                }) : core.error(t.msg);
            });
        }
    },
    play_music: function() {
        var e = this, t = this.data.detail.title, a = this.data.detail.image, i = this.data.detail.audio_url;
        if (i && "" != i) {
            var n = wx.getBackgroundAudioManager();
            n.title = t, n.coverImgUrl = a, n.src = i, this.setData({
                isplay: !0
            }), n.onCanplay(function(t) {
                console.log("onCanplay !!!!!!!!!"), e.setData({
                    duration: parseInt(n.duration),
                    endtime: e.timeformat(parseInt(n.duration))
                });
            }), n.onPlay(function(t) {
                console.log("onPlay !!!!!!!!!"), e.setData({
                    duration: parseInt(n.duration),
                    endtime: e.timeformat(parseInt(n.duration))
                }), e.startAnimationInterval();
            }), n.onEnded(function(t) {
                console.log("onEnded !!!!!!!!!"), e.setData({
                    currecttime: 0,
                    isplay: !1,
                    nowtime: "00:00"
                });
            }), n.onPause(function(t) {
                console.log("onPause !!!!!!!!!"), e.setData({
                    isplay: !1
                });
            }), n.onTimeUpdate(function(t) {
                console.log("onTimeUpdate !!!!!!!!!"), e.data.timechanging || e.setData({
                    currecttime: parseInt(n.currentTime),
                    nowtime: e.timeformat(parseInt(n.currentTime))
                });
            });
        }
    },
    timeformat: function(t) {
        var e = parseInt(t / 60), a = t % 60;
        return (e = e < 10 ? "0" + e : "" + e) + ":" + (a = a < 10 ? "0" + a : "" + a);
    },
    timechanging: function(t) {
        this.setData({
            timechanging: !0
        });
    },
    timechange: function(t) {
        console.log("timechange !!!!!!!!");
        var e = t.detail.value;
        wx.getBackgroundAudioManager().seek(e), this.setData({
            currecttime: e,
            timechanging: !1
        });
    },
    play_status_change: function() {
        this.data.isplay ? (wx.getBackgroundAudioManager().pause(), this.setData({
            isplay: !1
        })) : (wx.getBackgroundAudioManager().play(), this.setData({
            isplay: !0
        }));
    },
    onShow: function() {
        this.checkuser();
    },
    checkuser: function() {
        var e = this, i = {};
        core.get("paycontent/checkuser", {
            uid: t.getCache("userinfo").uid
        }, function(t) {
            0 == t.code ? (i.isvip = t.info, e.setData(i)) : a.alert(t.msg);
        }, !0);
    },
    dolike: function() {
        var e = this, i = {};
        core.get("paycontent/dolike", {
            id: e.data.detail.id,
            uid: t.getCache("userinfo").uid
        }, function(t) {
            1 == t.code ? (i.liked = !e.data.liked, e.setData(i)) : a.alert("收藏失败");
        }, !0);
    },
    getinfo: function() {
        var e = this, a = e.data.id, i = {};
        core.get("paycontent/paycontent_info", {
            id: a,
            uid: t.getCache("userinfo").uid
        }, function(t) {
            if (wx.setNavigationBarTitle({
                title: t.info.title ? decodeURIComponent(t.info.title) : "产品详情"
            }), 0 == t.code) {
                try {
                    wxParse.wxParse("wxParseData", "html", t.info.content, e, "0"), i.use_wxParse = !0, 
                    console.log("use wxParse !!!");
                } catch (t) {
                    i.use_wxParse = !1, console.log("not use wxParse !!!");
                }
                i.detail = t.info, i.liked = t.info.liked, i.show = !0, e.setData(i), 1 == t.info.paycontent_type && e.play_music();
            } else core.alert(t.msg);
        }, !0);
    },
    getlist: function() {
        var e = this, t = e.data.id, a = {};
        core.get("paycontent/samegroup", {
            id: t,
            page: e.data.page
        }, function(t) {
            0 == t.code ? (0 < t.info.length ? (1 == e.data.page ? a.samegroup = t.info : a.samegroup = e.data.samegroup.concat(t.info), 
            a.page = e.data.page + 1) : a.loaded = !0, e.setData(a)) : core.alert(t.msg);
        }, !0);
    },
    getallprice: function() {
        var e = this, t = e.data.id, a = {};
        core.get("paycontent/allprice", {
            id: t
        }, function(t) {
            0 == t.code ? 0 < t.info.length && (a.skus = t.info, a.now_sku = t.info[0], a.nowprice = t.info[0].price, 
            e.setData(a)) : core.alert(t.msg);
        }, !0);
    },
    onPullDownRefresh: function() {
        this.getinfo(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {
        console.log("加载更多"), this.data.loaded || this.getlist();
    },
    onShareAppMessage: function() {
        return {
            title: this.data.detail.title,
            path: "/yb_shop/pages/paycontent/info/index?id=" + this.data.detail.id
        };
    }
});