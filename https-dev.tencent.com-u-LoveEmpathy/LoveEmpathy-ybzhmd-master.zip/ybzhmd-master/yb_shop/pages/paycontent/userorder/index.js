var app = getApp(), api = app.requirejs("api/index"), core = app.requirejs("core");

Page({
    data: {
        list: [],
        page: 1,
        end: !1
    },
    onLoad: function(n) {
        var a = this, e = {};
        core.get("paycontent/order", {
            uid: app.getCache("userinfo").uid
        }, function(n) {
            1 == n.code ? 0 < n.info.length ? (1 == a.data.page ? e.list = n.info : e.list = a.data.list.concat(n.info), 
            e.page = a.data.page + 1, a.setData(e)) : a.setData({
                end: !0
            }) : core.alert(n.msg);
        }, !0);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.end || this.onLoad(null);
    },
    onShareAppMessage: function() {}
});