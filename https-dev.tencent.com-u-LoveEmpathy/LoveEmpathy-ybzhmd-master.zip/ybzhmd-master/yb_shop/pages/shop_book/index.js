var t = getApp(), a = t.requirejs("core");

Page({
    data: {
        route: "shop_book",
        menu: t.tabBar,
        menu_show: !1
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    onLoad: function(t) {
        null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), a.setting(), this.setData({
            menu: getApp().tabBar
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        });
    },
    formBook: function(t) {
        var e = this, n = t.detail.value;
        "" != n.name ? 11 == n.phone.length ? "" != n.booktime ? (n.user_id = 1, a.get("Index/WriteBook", n, function(t) {
            0 == t.code ? (e.setData({
                bookData: {}
            }), a.success("提交成功")) : a.alert(t.msg);
        })) : a.error("预约时间不能为空") : a.error("手机号格式不正确") : a.error("姓名不能为空");
    },
    listenerTime: function(t) {
        this.setData({
            "bookData.book_time": t.detail.value
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});