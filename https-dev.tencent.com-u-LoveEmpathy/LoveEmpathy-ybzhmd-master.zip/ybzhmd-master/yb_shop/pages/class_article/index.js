var t = getApp(), c = t.requirejs("api/index"), a = t.requirejs("core");

Page({
    data: {
        route: "class_article",
        menu: t.tabBar,
        menu_show: !1,
        show: !1,
        default_img: "http://ddfwz.sssvip.net/asmce/yigou/class_icon.png",
        height: 160
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    onLoad: function(t) {
        a.compatible_phonex(this), null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), this.setData({
            menu: getApp().tabBar
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        }), a.setting(), this.getlist();
    },
    getlist: function() {
        var e = this;
        t.get_menu(function(t) {
            c.Article_Class("class_article_1", e);
        });
    },
    onPullDownRefresh: function() {
        this.getlist(), wx.stopPullDownRefresh();
    },
    onShareAppMessage: function() {}
});