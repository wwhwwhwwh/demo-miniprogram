var t = getApp(), core = t.requirejs("core"), e = t.requirejs("check");

Page({
    data: {
        route: "goods_index",
        menu: t.tabBar,
        menu_show: !1,
        icons: t.requirejs("icons"),
        page: 1,
        list: [],
        defaults: {
            keywords: "",
            isrecommand: "",
            ishot: "",
            isnew: "",
            cate_id: "",
            order: "",
            by: "desc"
        },
        listmode: "block",
        fromsearch: !1,
        isFilterShow: !1,
        params: []
    },
    menu_url: function(t) {
        core.menu_url(t, 2);
    },
    onLoad: function(t) {
        null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), core.setting(), this.setData({
            menu: getApp().tabBar
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        });
        var a = this.data.defaults;
        a.keywords = t.key || "", a.cate_id = t.cate || "", this.setData({
            filterBtns: t,
            fromsearch: t.fromsearch || !1,
            defaults: t
        }), this.initCategory(), this.data.fromsearch || this.getList();
    },
    onShow: function() {},
    onPullDownRefresh: function() {
        this.setData({
            list: [],
            page: 1,
            loaded: !1
        }), this.getList(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {
        this.data.loaded || this.getList();
    },
    initCategory: function() {
        var a = this;
        core.get("goods/GetCate", {}, function(t) {
            console.log(t), a.setData({
                category: t.info
            });
        });
    },
    getList: function() {
        var e = this;
        e.setData({
            loading: !0
        }), e.data.defaults.page = e.data.page, core.get("goods/GoodsList", e.data.defaults, function(t) {
            if (0 == t.code) {
                if (0 == t.info.length) return e.setData({
                    loading: !1
                }), !1;
                var a = {
                    loading: !1
                };
                0 < t.info.length && (a.page = e.data.page + 1, a.list = e.data.list.concat(t.info), 
                t.info.length < 10 && (a.loaded = !0)), e.setData(a);
            } else core.alert(t.msg);
        });
    },
    bindSearch: function(t) {
        this.setData({
            list: [],
            loading: !0
        });
        var a = e.trim(t.detail.value), s = this.data.defaults;
        s.keywords = "" != a ? a : "", this.setData({
            page: 1,
            defaults: s,
            fromsearch: !1
        }), this.getList();
    },
    bindFilterSubmit: function() {
        var t = this.data.params, a = this.data.filterBtns;
        for (var s in a) t[s] = a[s];
        e.isEmptyObject(a) && (t = this.data.defaults), t.cate = this.data.category_selected, 
        this.setData({
            page: 1,
            params: t,
            isFilterShow: !1,
            filterBtns: a,
            list: [],
            loading: !0
        }), this.getList();
    },
    bindSort: function(t) {
        var a = core.pdata(t).order, e = this.data.defaults;
        if ("" == a) {
            if (e.order == a) return;
            e.order = "";
        } else if ("price" == a) e.order == a ? "desc" == e.by ? e.by = "asc" : e.by = "desc" : e.by = "asc", 
        e.order = a; else if ("sales" == a) {
            if (e.order == a) return;
            e.order = "sales", e.by = "desc";
        }
        this.setData({
            defaults: e,
            page: 1,
            list: [],
            loading: !0
        }), this.getList();
    },
    bindCategoryEvents: function(t) {
        var a = t.target.dataset.id;
        this.setData({
            "defaults.cate_id": a
        });
    },
    btnFilterBtns: function(t) {
        var a = t.target.dataset.type, e = this.data.defaults;
        a && (e.hasOwnProperty(a) || (e[a] = ""), e[a] ? e[a] = "" : e[a] = 1, this.setData({
            defaults: e
        }));
    },
    bindFilterCancel: function() {
        this.setData({
            isFilterShow: !1
        });
    },
    showFilter: function() {
        this.setData({
            isFilterShow: !this.data.isFilterShow
        });
    },
    bindback: function() {
        wx.navigateBack();
    }
});