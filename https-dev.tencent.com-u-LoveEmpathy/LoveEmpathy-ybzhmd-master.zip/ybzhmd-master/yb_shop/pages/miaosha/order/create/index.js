var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, t = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(t) {
    return void 0 === t ? "undefined" : _typeof(t);
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : _typeof(t);
}, e = getApp(), a = e.requirejs("core"), r = e.requirejs("check");

Page({
    data: {
        icons: e.requirejs("icons"),
        list: {},
        data: [],
        showPicker: !1,
        pvalOld: [ 0, 0, 0 ],
        pval: [ 0, 0, 0 ],
        areas: [],
        noArea: !0,
        submit: !0,
        button_color: e.config.button_color
    },
    onLoad: function(o) {
        a.setting();
        var i = this;
        this.data;
        this.setData({
            options: o,
            button_color: getApp().config.button_color
        }), a.get("Area/UserAddress", {
            uid: getApp().getCache("userinfo").uid
        }, function(t) {
            if (0 == t.code) {
                i.setData({
                    address: t.info.address
                });
                var e = {
                    bargain_name: o.name,
                    original_price: o.current_price,
                    pic: o.pic,
                    goods_id: o.goods_id
                };
                i.setData({
                    list: e,
                    show: !0
                }), i.caculate();
            } else a.alert(t.msg);
        });
    },
    onShow: function() {
        var t = e.getCache("orderAddress");
        t && (this.setData({
            address: t
        }), this.caculate());
    },
    toggle: function(t) {
        var e = a.pdata(t), o = e.id, i = {};
        i[e.type] = 0 == o || void 0 === o ? 1 : 0, this.setData(i);
    },
    phone: function(t) {
        a.phone(t);
    },
    caculate: function() {
        var t = this, e = t.data.address;
        e.order_money = t.data.options.current_price, e.pay_money = t.data.options.current_price, 
        e.total = t.data.options.total, e.user_name = getApp().getCache("userinfo").nickName, 
        e.buyer_id = getApp().getCache("userinfo").uid, e.activity_order_type = t.data.options.activity_order_type ? t.data.options.activity_order_type : 0, 
        e.bargain_id = t.data.options.bargain_id, t.setData({
            data: e
        });
    },
    submit: function() {
        var e = this, t = this.data;
        if (t.submit) {
            if (!t.address.phone || "" == t.address.province) return a.alert("请选择收货地址！"), !1;
            a.get("Miaosha/CreateOrder", t.data, function(t) {
                0 == t.code ? (e.setData({
                    submit: !1,
                    order_id: t.info
                }), wx.navigateTo({
                    url: "/yb_shop/pages/miaosha/order/pay/index?id=" + t.info
                })) : a.alert(t.msg);
            });
        } else wx.navigateTo({
            url: "/yb_shop/pages/miaosha/order/pay/index?id=" + e.data.order_id
        });
    },
    dataChange: function(t) {
        var e = this.data.data;
        this.data.list;
        switch (t.target.id) {
          case "buyer_message":
            e.buyer_message = t.detail.value;
        }
        this.setData({
            data: e
        });
    },
    radioChange: function(t) {
        this.setData({
            data: t
        });
    },
    url: function(t) {
        var e = a.pdata(t).url;
        wx.redirectTo({
            url: e
        });
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    }
});