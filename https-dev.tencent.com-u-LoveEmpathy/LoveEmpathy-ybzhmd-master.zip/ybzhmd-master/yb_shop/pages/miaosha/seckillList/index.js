var t = getApp(), a = t.requirejs("core");

Page({
    data: {
        currentTab: 1,
        page: 0,
        pageList: [],
        countDownList: [],
        loading: !0
    },
    onLoad: function(t) {
        this.setCurrentData();
    },
    onShow: function() {},
    setCurrentData: function() {
        var s = this;
        s.setData({
            loading: !0
        }), a.get("Miaosha/msGoodsList", {
            page: s.data.page,
            ms_type: s.data.currentTab
        }, function(t) {
            0 == t.code ? (0 < t.info.length && t.info.forEach(function(t, e) {
                var n = t.etime;
                a.Countdown(n, function(t) {
                    var a = s.data.countDownList;
                    0 != t.show_time && (t.show_time = !0), a[e] = t, s.setData({
                        countDownList: a
                    });
                });
            }), console.log(t), s.setData({
                loading: !1,
                show: !0
            }), 0 < t.info.length && s.setData({
                page: s.data.page + 1,
                pageList: s.data.pageList.concat(t.info)
            }), t.info.length < 10 && s.setData({
                loaded: !0
            })) : a.alert(t.msg);
        }, !0);
    },
    changeList: function(t) {
        this.data.currentTab != t.currentTarget.dataset.list && (this.setData({
            currentTab: t.currentTarget.dataset.list
        }), this.setData({
            pageList: [],
            page: 1,
            loaded: !1
        }), this.setCurrentData());
    },
    onPullDownRefresh: function() {
        this.setData({
            pageList: [],
            page: 1,
            loaded: !1
        }), this.setCurrentData(), wx.stopPullDownRefresh();
    },
    onShareAppMessage: function() {}
});