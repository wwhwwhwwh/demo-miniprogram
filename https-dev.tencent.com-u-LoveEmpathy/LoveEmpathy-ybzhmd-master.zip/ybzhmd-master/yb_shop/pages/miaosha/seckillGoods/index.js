var t = getApp(), a = t.requirejs("core"), s = t.requirejs("wxParse/wxParse");

Page({
    data: {
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 1e3,
        countDownDay: 0,
        countDownHour: 0,
        countDownMinute: 0,
        countDownSecond: 0,
        show_time: !0,
        advWidth: 0,
        icons: t.requirejs("icons")
    },
    onLoad: function(t) {
        var a = this;
        this.setData(t), this.detail(), wx.getSystemInfo({
            success: function(t) {
                console.log(t), a.setData({
                    advWidth: t.windowWidth
                });
            }
        });
    },
    detail: function() {
        var o = this, t = o.data.id;
        a.get("Miaosha/msGoodsDetail", {
            id: t
        }, function(t) {
            if (console.log(t), 0 == t.code) {
                if (o.setData({
                    info: t.info
                }), wx.setNavigationBarTitle({
                    title: t.info.name || "活动详情"
                }), t.info.description && s.wxParse("wxParseData", "html", t.info.description, o, "0"), 
                0 < t.info.status) {
                    if (2 == t.info.status) var i = t.info.etime; else if (1 == t.info.status) i = t.info.stime;
                    a.Countdown(i, function(t) {
                        o.setData(t);
                    });
                }
            } else a.alert(t.msg, function() {});
        }, !0);
    },
    onPullDownRefresh: function() {
        this.detail(), wx.stopPullDownRefresh();
    },
    navigate: function() {
        var t = this.data.about_info;
        t.name && t.lat && t.lng ? a.tx_map(t.lat, t.lng, t.name) : a.toast("获取位置失败");
    },
    shoping: function(t) {
        var i = this;
        a.pdata(t);
        return i.data.show_time ? i.data.info.rest_sell < 1 ? (a.alert("库存不足"), !1) : void wx.navigateTo({
            url: "/yb_shop/pages/miaosha/order/create/index?bargain_id=" + i.data.info.id + "&total=1&uid=" + getApp().getCache("userinfo").uid + "&activity_order_type=3&current_price=" + i.data.info.nprice + "&pic=" + i.data.info.pic + "&name=" + i.data.info.name + "&goods_id=" + i.data.info.goods_id
        }) : (a.alert("该活动已经结束"), !1);
    },
    phone: function(t) {
        a.phone(t);
    }
});