var _slicedToArray = function(e, t) {
    if (Array.isArray(e)) return e;
    if (Symbol.iterator in Object(e)) return function(e, t) {
        var o = [], a = !0, n = !1, i = void 0;
        try {
            for (var l, r = e[Symbol.iterator](); !(a = (l = r.next()).done) && (o.push(l.value), 
            !t || o.length !== t); a = !0) ;
        } catch (e) {
            n = !0, i = e;
        } finally {
            try {
                !a && r.return && r.return();
            } finally {
                if (n) throw i;
            }
        }
        return o;
    }(e, t);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, app = getApp(), wechat = require("../..//utils/wechat.js"), core = require("../..//utils/core.js");

Page({
    data: {
        src: "",
        paths: {
            goods: "yb_shop/pages/goods/detail/index",
            kanjia: "yb_shop/pages/kanjia/goods_info/index",
            pintuan: "yb_shop/pages/pintuan/pages/goods/detail"
        }
    },
    dosave: function() {
        0 < this.data.src.length ? (wx.showLoading({
            title: "保存中..."
        }), wechat.saveImageToPhotosAlbum(this.data.src).then(function(e) {
            wx.hideLoading(), core.alert("海报保存成功");
        }).catch(function(e) {
            wx.hideLoading(), core.alert("海报保存失败,请重试");
        })) : core.alert("海报正在生成,请稍候");
    },
    onLoad: function(e) {
        console.log(e);
        var t = this.data.paths[e.share_type], o = e.id, a = app.util.makeurl({
            url: "entry/wxapp/net_img",
            data: {
                url: encodeURIComponent(e.img)
            }
        });
        e.img = a, console.log(a), core.loading("海报生成中");
        var n = wx.createCanvasContext("poster");
        n.clearRect(0, 0, 0, 0), n.setFillStyle("#ffffff"), n.fillRect(0, 0, 750, 1030);
        var i = this.textByteLength(e.title, 34), l = _slicedToArray(i, 3), r = (l[0], l[1]);
        l[2];
        n.setTextAlign("left"), n.setFontSize(28), n.setFillStyle("#333333");
        for (var s = 0; s < r.length; s++) n.fillText(r[s], 12, 805 + 35 * s);
        var c = "原价￥" + e.original_price;
        n.setFontSize(22), n.setFillStyle("#818181"), n.fillText(c, 12, 920);
        var h = n.measureText(c);
        n.setFontSize(22), n.setFillStyle("#333333"), n.fillText("优惠价￥", 12, 990), n.setFontSize(48), 
        n.setFillStyle("#d92d20"), n.fillText(e.price, 100, 993), n.setStrokeStyle("#818181"), 
        n.beginPath(), n.setLineWidth(1), n.moveTo(12, 911), n.lineTo(h.width + 12, 911), 
        n.stroke();
        var d = app.util.makeurl({
            url: "entry/wxapp/qr_code",
            data: {
                path: t,
                scene: o,
                pid: app.getCache("userinfo").uid
            }
        });
        console.log(d);
        var u = app.util.md5("share_type=" + e.share_type + "&id=" + e.id), p = app.getCache(u);
        console.log(p);
        var g = this;
        "" != p ? (console.log("has save !!!!!!!"), n.drawImage(p, 490, 765, 236, 236), 
        wechat.downloadFile(e.img).then(function(e) {
            console.log(e), n.drawImage(e.tempFilePath, 0, 0, 750, 750), n.draw(!1, function() {
                wx.canvasToTempFilePath({
                    destWidth: 750,
                    destHeight: 1030,
                    canvasId: "poster",
                    success: function(e) {
                        core.hideLoading(), console.log(e.tempFilePath), g.setData({
                            src: e.tempFilePath
                        });
                    }
                });
            });
        }).catch(function(e) {
            core.alert("商品图片无法下载,海报生成失败");
        })) : (console.log("not save !!!!!!!"), wechat.downloadFile(e.img).then(function(e) {
            return console.log(e), n.drawImage(e.tempFilePath, 0, 0, 750, 750), wechat.downloadFile(d);
        }).then(function(e) {
            return console.log(e), wechat.saveFile(e.tempFilePath);
        }).then(function(e) {
            console.log(e);
            var t = e.savedFilePath;
            app.setCache(u, t), n.drawImage(t, 490, 765, 236, 236), n.draw(!1, function() {
                wx.canvasToTempFilePath({
                    destWidth: 750,
                    destHeight: 1030,
                    canvasId: "poster",
                    success: function(e) {
                        console.log(e), core.hideLoading(), g.setData({
                            src: e.tempFilePath
                        });
                    }
                });
            });
        }).catch(function(e) {
            core.alert("商品图片无法下载,海报生成失败");
        }));
    },
    textByteLength: function(e, t) {
        for (var o = 0, a = 1, n = 0, i = [], l = 0; l < e.length; l++) 255 < e.charCodeAt(l) ? a * t < (o += 2) && (o++, 
        i.push(e.slice(n, l)), n = l, a++) : a * t < ++o && (i.push(e.slice(n, l)), n = l, 
        a++);
        return i.push(e.slice(n, e.length)), [ o, i, a ];
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});