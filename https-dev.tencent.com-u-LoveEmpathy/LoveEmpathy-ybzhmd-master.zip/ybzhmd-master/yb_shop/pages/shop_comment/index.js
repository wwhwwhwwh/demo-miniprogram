var t = getApp(), a = t.requirejs("core");

Page({
    data: {
        page: 1,
        list: [],
        loaded: !1,
        show: !0
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    onLoad: function(t) {
        this.comment();
    },
    comment: function() {
        var n = this;
        a.get("Catering/CommentList", {
            page: n.data.page
        }, function(t) {
            if (0 == t.code) {
                var o = {
                    sroce: t.info.sroce,
                    count: t.info.count,
                    show: !0
                };
                t.info.info.length < 10 && (o.loaded = !0), 0 < t.info.info.length && (o.page = n.data.page + 1, 
                o.list = n.data.list.concat(t.info.info)), o.list = t.info.info, n.setData(o);
            } else e.alert(t.msg);
        }, !0);
    },
    onPullDownRefresh: function() {
        this.setData({
            list: [],
            page: 1,
            loaded: !1
        }), this.comment();
    },
    onReachBottom: function() {
        this.data.loaded || this.comment();
    },
    onShareAppMessage: function() {}
});