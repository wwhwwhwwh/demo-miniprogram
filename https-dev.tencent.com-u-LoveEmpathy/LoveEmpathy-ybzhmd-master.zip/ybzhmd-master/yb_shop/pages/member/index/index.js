var e = getApp(), c = e.requirejs("api/index"), r = e.requirejs("core");

Page({
    data: {
        route: "member_index",
        menu: e.tabBar,
        menu_show: !1,
        icons: e.requirejs("icons"),
        member: {},
        page: {},
        show: !1,
        config: e.config,
        background: e.config.background,
        default_pic: "/yb_shop/static/images/add_pic.jpg"
    },
    menu_url: function(e) {
        r.menu_url(e, 2);
    },
    formSubmit: function(e) {
        var t = {
            currentTarget: {
                dataset: {}
            }
        }, a = e.detail.value;
        t.currentTarget.dataset = a, r.menu_url(t, 1);
        var n = {};
        n.formid = e.detail.formId, n.openid = getApp().getCache("userinfo").openid, n.username = getApp().getCache("userinfo").nickName, 
        r.get("Market/getFormid", n, function(e) {
            console.log(e);
        });
    },
    to_url: function(e) {
        r.menu_url(e, 1);
    },
    onLoad: function(t) {
        r.compatible_phonex(this), null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        });
        var a = getApp().getCache("user_center_page");
        "" != a && (this.setData({
            page: a
        }), this.initpage()), "" == e.getCache("userinfo") && (r.toast("您还没登录呢"), setTimeout(function() {
            wx.redirectTo({
                url: "/yb_shop/pages/index/index"
            });
        }, 2e3));
        var n = this;
        getApp().get_menu(function(e) {
            n.setData({
                menu: getApp().tabBar
            }), getApp().check_is_tabbar(), r.get("Distribe/shareSetting", {}, function(e) {
                0 == e.code && n.setData({
                    shareSetting: e.info
                });
            }), n.get_candan();
        });
    },
    initpage: function() {
        var e = this;
        wx.setNavigationBarColor({
            frontColor: e.data.page.text_color,
            backgroundColor: e.data.page.nv_color,
            animation: {
                duration: 0,
                timingFunc: "easeIn"
            }
        }), wx.setNavigationBarTitle({
            title: e.data.page.name ? decodeURIComponent(e.data.page.name) : "首页"
        }), wx.setBackgroundColor && wx.setBackgroundColor({
            backgroundColor: e.data.page.bg_color ? e.data.page.bg_color : "#f2f3f4"
        });
    },
    get_candan: function() {
        var o = this, i = wx.getSystemInfoSync().windowWidth;
        r.get("Index/ucenter", {}, function(n) {
            if ("string" == typeof t) n = r.json_parse(n);
            o.setData({
                page: n.page
            }), getApp().setCache("user_center_page", n.page), o.initpage(), n.all_data.forEach(function(t) {
                "advert" == t.type && (t.high = i * t.ly_height / t.ly_width), "banner" == t.type && (t.high = i * t.ly_height / 10), 
                "position" == t.type && 2 == t.is_display && o.setData({
                    "markers[0].latitude": t.latitude,
                    "markers[0].longitude": t.longitude,
                    "markers[0].title": t.position_name
                }), "rich_text" == t.type && (s.wxParse("wxParseData_" + t.time_key, "html", t.content, o, "0"), 
                t.wxParseData = o.data["wxParseData_" + t.time_key].nodes), "edit_piclist" == t.type && (t.arr = a.str(t.list)), 
                "comment" == t.type && o.comment(o, t.is_display), "edit_music" == t.type && o.play_music(t.name, t.author, t.imgurl, t.url), 
                "edit_form" == t.type && t.param && "" != t.param && 0 != t.param && (o.get_form_list(2, t.param, o), 
                e.id = t.param);
            }), o.setData({
                list: n.all_data,
                show: !0
            }), o.getInfo();
        }, !0);
    },
    get_form_list: function(n, o, i) {
        var s = {}, u = "提交";
        r.get("index/form", {
            id: o
        }, function(e) {
            var t = e.info.list;
            if (0 == e.code) {
                if (1 == n && (wx.setNavigationBarTitle({
                    title: e.info.title ? decodeURIComponent(e.info.title) : "万能表单"
                }), 0 == t.length)) return void r.alert("表单内容为空");
                t.forEach(function(e) {
                    "picker" == e.module && (s[e.name] = 0), "time_one" == e.module && (s[e.name] = e.default), 
                    "time_two" == e.module && (s[e.name + "_1"] = e.default1, s[e.name + "_2"] = e.default2, 
                    e.default1 && e.default2 ? s[e.name] = e.default1 + "," + e.default2 : s[e.name] = ""), 
                    "pic_arr" == e.module && (s[e.name] = []), "region" == e.module && (s[e.name] = e.default, 
                    s[e.name + "_multi"] = [ 0, 0, 0 ]), "button" == e.module && (u = e.title);
                }), 1 == n && i.setData({
                    show: !0
                }), console.log("-------------------"), console.log(i.data);
                var a = i.data.power_form ? i.data.power_form : {};
                a[o + ""] = {
                    data: s,
                    button_name: u,
                    form: t,
                    form_id: o
                }, console.log(a), i.setData({
                    power_form: a
                });
            } else r.alert(e.msg);
        }, !0);
    },
    play_music: function(e, t, a, n) {
        if (n && "" != n) {
            var o = wx.getBackgroundAudioManager();
            o.title = e || "音乐标题", o.singer = t, o.coverImgUrl = a, o.src = n;
        }
    },
    comment: function(n, e) {
        a.get("Index/CommentList", {
            num: e
        }, function(e) {
            if (0 == e.code) {
                var t = {
                    sroce: e.info.sroce,
                    count: e.info.count
                };
                t.commentlist = e.info.info, n.setData(t);
            } else r.alert(e.msg);
        });
    },
    formBook: function(e) {
        var t = this, a = e.detail.value, n = getApp().getCache("userinfo").uid;
        if ("" != a.name) return null == n ? (r.error("请先登录"), void setTimeout(function() {
            r.jump("/yb_shop/pages/index/index", 2);
        }, 1e3)) : void (11 == a.phone.length ? (a.user_id = n, r.get("Index/WriteBook", a, function(e) {
            0 == e.code ? (t.setData({
                bookData: {}
            }), r.success("提交成功")) : r.alert(e.msg);
        })) : r.error("手机号格式不正确"));
        r.error("姓名不能为空");
    },
    onPullDownRefresh: function() {},
    getInfo: function() {
        var t = this;
        t.setData({
            background: getApp().config.background,
            font_color: getApp().config.font_color
        }), r.get("user/Index", {
            uid: getApp().getCache("userinfo").uid
        }, function(e) {
            console.log(e), e.info.nickName = getApp().getCache("userinfo").nickName, e.info.avatarUrl = getApp().getCache("userinfo").avatarUrl, 
            console.log(e), t.setData({
                member: e.info
            });
        });
    },
    fail: function() {
        wx.redirectTo({
            url: "/yb_shop/pages/message/auth/index"
        });
    },
    onShow: function() {
        this.getInfo();
    },
    relogin: function() {
        var a = this;
        wx.getSetting({
            success: function(t) {
                t.authSetting["scope.userInfo"] || wx.openSetting({
                    success: function(t) {
                        t.authSetting["scope.userInfo"] && (e.getUserInfo(), setTimeout(function() {
                            a.getInfo();
                        }, 1e3));
                    }
                });
            }
        });
    },
    navigate: function(e) {
        var t = a.pdata(e);
        t.name && t.lat && t.lng ? a.tx_map(t.lat, t.lng, t.name) : a.toast("不能获取到该位置");
    },
    phone: function(e) {
        r.phone(e);
    },
    formPower: function(e) {
        c.formSubmit(this, e);
    },
    bindPickerChange: function(e) {
        c.bindPickerChange(this, e);
    },
    listen_time_two: function(e) {
        c.listen_time_two(this, e);
    },
    chooseImageTap1: function(e) {
        var t = r.pdata(e).id;
        c.upload(this, t, "form_pic", 1);
    },
    chooseImageTap2: function(e) {
        var t = r.pdata(e).id;
        c.upload(this, t, "form_pic", 0);
    },
    Image_del: function(e) {
        c.Image_del(this, e);
    },
    previewImage: function(e) {
        var t = a.pdata(e).url, n = a.pdata(e).arr;
        r.previewImage(t, n, "imgurl");
    }
});