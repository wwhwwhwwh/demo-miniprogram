var t = getApp(), e = t.requirejs("core"), i = t.requirejs("check"), running = !1;

Page({
    data: {
        id: "",
        posting: !1,
        subtext: "保存地址",
        detail: {
            consigner: "",
            phone: "",
            area: "",
            address: "",
            areaid: ""
        },
        showPicker: !1,
        pvalOld: [ 0, 0, 0 ],
        pval: [ 0, 0, 0 ],
        areas: [],
        street: [],
        streetIndex: 0,
        noArea: !1
    },
    get_wx_address: function() {
        var r = this, n = r.data.detail;
        wx.chooseAddress({
            success: function(a) {
                n.consigner = a.userName, n.phone = a.telNumber, n.address = a.detailInfo, n.province = a.provinceName, 
                n.city = a.cityName, n.area = a.countyName;
                var t = n.province + " " + n.city + " " + n.area, i = r.getIndex(t, r.data.areas);
                n.areaid = r.getareaid(t, r.data.areas), null == n.areaid ? e.alert("该地址无法自动获取,请手动选择") : r.setData({
                    pvalOld: i,
                    pval: i,
                    detail: n
                });
            }
        });
    },
    onLoad: function(a) {
        e.setting(), this.setData({
            id: a.id,
            type: a.type,
            order: a.order,
            config: getApp().config
        }), this.getDetail(), a.id || wx.setNavigationBarTitle({
            title: "添加收货地址"
        });
        var t = this;
        e.get("area/GetArea", {}, function(e) {
            t.setData({
                areas: e.areas,
                type: a.type
            });
        });
    },
    getDetail: function() {
        var n = this, a = n.data.id;
        e.get("user/SingleAddress", {
            id: a,
            uid: getApp().getCache("userinfo").uid
        }, function(e) {
            var a = {
                show: !0
            };
            if (!i.isEmptyObject(e.info)) {
                wx.setNavigationBarTitle({
                    title: "编辑收货地址"
                });
                var t = e.info.province + " " + e.info.city + " " + e.info.district, r = n.getIndex(t, n.data.areas);
                a.pval = r, a.pvalOld = r, a.detail = e.info, a.detail.area = e.info.district;
            }
            n.setData(a);
        });
    },
    submit: function(a) {
        var t = this, i = this.data.id, r = e.pdata(a).type, n = t.data.detail;
        if (!running) {
            if (running = !0, n.uid = getApp().getCache("userinfo").uid, "" == n.consigner || !n.consigner) return e.toast("请填写收件人"), 
            !1;
            if ("" == n.phone || !n.phone) return e.toast("请填写联系电话"), !1;
            if ("" == n.city || !n.city) return e.toast("请选择所在地区"), !1;
            if ("" == n.address || !n.address) return e.toast("请填写详细地址"), !1;
            t.setData({
                posting: !0
            }), "add" == r ? (console.log(n), e.get("user/CreateAddress", n, function(a) {
                if (0 != a.code) return t.setData({
                    posting: !1
                }), void e.alert(a.msg);
                running = !0, e.success("添加成功！"), setTimeout(function() {
                    "add" == t.data.type && 1 == t.data.order ? wx.redirectTo({
                        url: "/yb_shop/pages/member/address/select"
                    }) : wx.navigateBack();
                }, 1e3);
            })) : (n.id = i, e.get("user/UpdateAddress", n, function(a) {
                if (0 != a.code) return t.setData({
                    posting: !1
                }), void e.alert(a.msg);
                e.success("修改成功！"), running = !0, setTimeout(function() {
                    "member" == t.data.type && 2 == t.data.order ? wx.redirectTo({
                        url: "/yb_shop/pages/member/address/select"
                    }) : wx.navigateBack();
                }, 1e3);
            }));
        }
    },
    onChange: function(e) {
        var a = this.data.detail, t = e.currentTarget.dataset.type, r = i.trim(e.detail.value);
        a[t] = r, this.setData({
            detail: a
        });
    },
    selectArea: function(e) {
        var a = e.currentTarget.dataset.area, t = this.getIndex(a, this.data.areas);
        this.setData({
            pval: t,
            pvalOld: t,
            showPicker: !0
        });
    },
    getStreet: function(e, a) {
        if (e && a) {
            if (this.data.detail.province && this.data.detail.city && this.data.openstreet) e[a[0]].city[a[1]].code, 
            e[a[0]].city[a[1]].area[a[2]].code;
        }
    },
    bindChange: function(e) {
        var a = this.data.pvalOld, t = e.detail.value;
        a[0] != t[0] && (t[1] = 0), a[1] != t[1] && (t[2] = 0), this.setData({
            pval: t,
            pvalOld: t
        });
    },
    onCancel: function(e) {
        this.setData({
            showPicker: !1
        });
    },
    onConfirm: function(e) {
        var a = this.data.pval, t = this.data.areas, i = this.data.detail;
        i.province = t[a[0]].name, i.city = t[a[0]].city[a[1]].name, i.areaid = t[a[0]].city[a[1]].area[a[2]].id, 
        i.datavalue = t[a[0]].code + " " + t[a[0]].city[a[1]].code, t[a[0]].city[a[1]].area && 0 < t[a[0]].city[a[1]].area.length ? (i.area = t[a[0]].city[a[1]].area[a[2]].name, 
        i.datavalue += " " + t[a[0]].city[a[1]].area[a[2]].code, this.getStreet(t, a)) : i.area = "", 
        i.street = "", this.setData({
            detail: i,
            streetIndex: 0,
            showPicker: !1
        });
    },
    getIndex: function(e, a) {
        if ("" == i.trim(e) || !i.isArray(a)) return [ 0, 0, 0 ];
        var t = e.split(" "), r = [ 0, 0, 0 ];
        for (var n in a) if (a[n].name == t[0]) {
            for (var s in r[0] = Number(n), a[n].city) if (a[n].city[s].name == t[1]) {
                for (var d in r[1] = Number(s), a[n].city[s].area) if (a[n].city[s].area[d].name == t[2]) {
                    r[2] = Number(d);
                    break;
                }
                break;
            }
            break;
        }
        return console.log(r), r;
    },
    getareaid: function(e, a) {
        var t = null;
        if ("" == i.trim(e) || !i.isArray(a)) return t;
        var r = e.split(" ");
        for (var n in console.log(a), a) if (a[n].name == r[0]) {
            for (var s in a[n].city) if (a[n].city[s].name == r[1]) {
                for (var d in a[n].city[s].area) if (a[n].city[s].area[d].name == r[2]) {
                    console.log(a[n].city[s].area[d]), t = a[n].city[s].area[d].id;
                    break;
                }
                break;
            }
            break;
        }
        return console.log(t), t;
    }
});