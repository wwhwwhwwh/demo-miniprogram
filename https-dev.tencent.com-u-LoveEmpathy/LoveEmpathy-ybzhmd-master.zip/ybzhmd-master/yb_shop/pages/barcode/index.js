var t = getApp(), a = t.requirejs("core"), wxbarcode = t.requirejs("barindex");

Page({
    data: {
        code: ""
    },
    onLoad: function(e) {
        e && e.code ? (this.setData({
            code: e.code
        }), wxbarcode.barcode("barcode", e.code, 680, 200)) : a.jump("", 5);
    }
});