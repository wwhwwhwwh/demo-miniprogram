var app = getApp(), a = app.requirejs("core"), b = app.requirejs("api/kjb");

Page({
    data: {
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 1e3,
        countDownDay: 0,
        countDownHour: 0,
        countDownMinute: 0,
        countDownSecond: 0,
        list: [],
        show_time: !0
    },
    onLoad: function(t) {
        a.setting(), this.setData(t), this.detail(), this.goodslist();
    },
    detail: function() {
        var i = this, a = i.data.id;
        b.kj_detail(a, i, function(a) {
            if (i.setData(a), a.bargain_info.end_time) {
                var t = a.bargain_info.end_time;
                wx.setNavigationBarTitle({
                    title: a.bargain_info.bargain_name || "活动详情"
                }), b.Countdown(t, function(a) {
                    i.setData(a);
                });
            }
        });
    },
    goodslist: function() {
        var t = this;
        b.kj_list("", 1, 1, t, function(a) {
            t.setData(a);
        });
    },
    onPullDownRefresh: function() {
        this.setData({
            list: []
        }), this.detail(), this.goodslist(), wx.stopPullDownRefresh();
    },
    navigate: function() {
        var t = this.data.about_info;
        t.name && t.lat && t.lng ? a.tx_map(t.lat, t.lng, t.name) : a.toast("获取位置失败");
    },
    url: function(t) {
        var i = a.pdata(t);
        wx.navigateTo({
            url: "/yb_shop/pages/kanjia/goods_info/index?id=" + i.id
        });
    },
    shoping: function(t) {
        var i = this;
        a.pdata(t);
        return i.data.show_time ? i.data.bargain_info.bargain_inventory < 1 ? (a.alert("库存不足"), 
        !1) : void wx.navigateTo({
            url: "/yb_shop/pages/kanjia/order/create/index?bargain_id=" + i.data.bargain_info.id + "&total=1&uid=" + getApp().getCache("userinfo").uid + "&activity_order_type=0&current_price=" + i.data.bargain_info.original_price
        }) : (a.alert("该活动已经结束"), !1);
    },
    formSubmit: function(t) {
        var i = t.detail.formId, n = t.detail.value.id;
        a.pdata(t);
        return this.data.show_time ? this.data.bargain_info.bargain_inventory < 1 ? (a.alert("库存不足"), 
        !1) : void wx.navigateTo({
            url: "/yb_shop/pages/kanjia/discount_info/index?id=" + n + "&form_id=" + i
        }) : (a.alert("该活动已经结束"), !1);
    },
    phone: function(t) {
        a.phone(t);
    }
});