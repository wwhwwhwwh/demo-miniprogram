var app = getApp(), a = app.requirejs("core");

Page({
    data: {
        show: !1,
        total_price: 0,
        price: 0,
        cash_price: 0,
        total_cash: 0,
        team_count: 0,
        order_money: 0
    },
    menu_url: function(t) {
        a.menu_url(t, 2);
    },
    onLoad: function(t) {
        t.title = t.title ? t.title : "分销中心", a.ReName(t.title), a.setting(), null != t && null != t && this.setData({
            tabbar_index: t.tabbar_index ? t.tabbar_index : -1
        }), this.setData({
            menu: getApp().tabBar,
            class_id: t.id ? t.id : "",
            class_id1: t.id ? t.id : "",
            class_style: t.class_style ? t.class_style : 2
        }), 0 <= this.data.tabbar_index && this.setData({
            showtabbar: !0
        });
        this.getInfo();
    },
    getInfo: function() {
        var e = this;
        a.get("Distribe/shareSetting", {}, function(t) {
            0 == t.code && (app.setCache("shareSetting", t.info), e.setData({
                shareSetting: t.info
            }));
        }), a.get("Distribe/userinfo", {
            uid: app.getCache("userinfo").uid
        }, function(t) {
            0 == t.code ? (app.setCache("share_userinfo", t.info), e.setData({
                user_info: t.info,
                show: !0
            })) : a.alert(t.msg, function() {
                a.jump("", 5);
            });
        }, !0);
    },
    onReady: function() {},
    onShow: function() {},
    onPullDownRefresh: function() {
        this.getInfo(), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {},
    apply: function(t) {
        a.jump("../add-share/index?title=申请" + this.data.shareSetting.other[13]);
    },
    home: function(t) {
        a.jump("/yb_shop/pages/index/index", 2);
    }
});